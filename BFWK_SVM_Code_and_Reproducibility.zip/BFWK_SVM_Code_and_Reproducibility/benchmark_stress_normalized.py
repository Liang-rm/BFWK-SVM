import importlib.util, pathlib, sys
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.metrics import balanced_accuracy_score

BASE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bfwkbase', BASE/'benchmark_bfwk.py')
b=importlib.util.module_from_spec(spec); sys.modules['bfwkbase']=b; spec.loader.exec_module(b)
spec2=importlib.util.spec_from_file_location('bfwkn', BASE/'benchmark_bfwk_normalized.py')
bn=importlib.util.module_from_spec(spec2); sys.modules['bfwkn']=bn; spec2.loader.exec_module(bn)
OUT=BASE/'benchmark_results_final'; OUT.mkdir(exist_ok=True)
RR=[(l,r,t) for l in (.04,.10) for r in (.10,.30) for t in (.20,.50)]

def tune_rr_aug(X,y,C,gamma,seed):
    sp=StratifiedShuffleSplit(n_splits=1,test_size=.25,random_state=seed)
    tr,va=next(sp.split(X,y)); vals=[]
    for rr in RR:
        m=bn.fit_bfwk_normalized(X[tr],y[tr],C,gamma,*rr,max_outer=6,eps_alpha=2e-4,eps_J=2e-5)
        score=b.predict_kernel(m,X[va])
        vals.append(balanced_accuracy_score(y[va],np.where(score>=0,1,-1)))
    return RR[int(np.argmax(vals))]

rows=[]
for ds in b.make_datasets():
    if ds.name not in {'WDBC','KR-vs-KP'}: continue
    Xdf,y=b.stratified_subsample(ds.X,ds.y,max_n=1000,seed=b.SEED)
    cv=StratifiedKFold(5,shuffle=True,random_state=b.SEED)
    for fold,(tr,te) in enumerate(cv.split(Xdf,y),1):
        (C,gamma),_=b.tune_C_gamma(Xdf,y,tr,b.SEED+fold)
        pre=b.make_preprocessor(Xdf.iloc[tr]); Xtr=pre.fit_transform(Xdf.iloc[tr]); Xte=pre.transform(Xdf.iloc[te])
        keep=Xtr.std(0)>1e-10; Xtr=Xtr[:,keep]; Xte=Xte[:,keep]
        original_d=Xtr.shape[1]
        Xtr,Xte,_=b.augment_correlated_noise(Xtr,Xte,b.SEED+1000*fold,redundant_fraction=1.0,noise_fraction=1.0)
        rr=tune_rr_aug(Xtr,y[tr],C,gamma,b.SEED+100+fold)
        m=bn.fit_bfwk_normalized(Xtr,y[tr],C,gamma,*rr,max_outer=12)
        s=b.predict_kernel(m,Xte); ba_b=balanced_accuracy_score(y[te],np.where(s>=0,1,-1))
        a=np.full(Xtr.shape[1],1/Xtr.shape[1]); mr=b.fit_fixed_weight(Xtr,y[tr],C,gamma,a)
        sr=b.predict_kernel(mr,Xte); ba_r=balanced_accuracy_score(y[te],np.where(sr>=0,1,-1))
        for method,ba in [('BFWK-SVM-N',ba_b),('RBF-SVM',ba_r)]:
            rows.append({'dataset':ds.name,'fold':fold,'method':method,'BalancedAccuracy':ba,'original_d':original_d,'augmented_d':Xtr.shape[1],'C':C,'gamma':gamma,'lambda':rr[0],'rho':rr[1],'tau':rr[2]})
        pd.DataFrame(rows).to_csv(OUT/'stress_fold_results.csv',index=False)
        print(ds.name, fold, rr, ba_b, ba_r, flush=True)

df=pd.DataFrame(rows)
summary=df.groupby(['dataset','method']).BalancedAccuracy.agg(['mean','std']).reset_index()
summary.to_csv(OUT/'stress_summary.csv',index=False)
print(summary.to_string(index=False))
