BFWK-SVM 最新修订代码与复现包
更新日期：2026-10-21
公开代码网址：https://github.com/Liang-rm/BFWK-SVM

本包从当前已交付的修订包中提取，代码与对应结果文件逐字节保持一致。

内容：
- revision_core.py：修订版 BFWK-SVM 核心实现。
- revision_*.py：全因子敏感性、jitter、六数据集压力测试、学习曲线、复杂度、PercePiano 数据处理/模型/验证/绘图程序。
- benchmark_*.py、BFWK_SVM_complete_demo_fixed.R：保留的原始基线程序和 R 演示。
- requirements_revision.txt：本次修订运行环境版本；requirements.txt 为原始依赖说明。
- results/：原始公开 benchmark 结果。
- results_revision/：新增公开数据实验结果、配置与运行记录。
- results_percepiano/：处理后特征、目标、分组划分、保存模型、置换与 bootstrap 结果。
- source_data/：固定版本的官方 PercePiano 源压缩包、许可和来源记录。
- README_Revision_Core.md：算法约定及复现实验说明。
- MANIFEST_SHA256.csv：本包文件校验值（不含清单自身）。

使用 Python 3.12，先安装 requirements_revision.txt 中的依赖，然后在解压后的代码根目录运行下方命令。
依赖软件未打包；安装依赖需要可用的软件源。PercePiano 源压缩包已附带，解压阶段无需下载。
请在副本中运行，以保留本包已有结果。部分程序支持断点续跑；重算前按下方说明移开已有运行记录。
未包含论文、审稿回复、LaTeX 和生成的图像；绘图脚本可根据已有结果重新生成图像。
revision_group_mass_plot.py 为旧案例图示的保留脚本，不用于最新版 PercePiano 分析。
本次仅整理代码包，没有重新运行或更改实验。

Numerical conventions and reproduction commands
==============================================

All added BFWK experiments use J_N=V_epsilon/n+R and absolute kernel jitter 1e-6, except the declared jitter sweep. J_N differs from J/n at equal coefficients; equivalence requires raw coefficients n times the normalized coefficients. Fitting, dual values and intercepts use the same jittered Gram matrix, while held-out prediction uses the base cross-kernel. The archived original public Python driver uses zero explicit jitter; the original R demonstration uses 1e-10. The former PercePiano jitter is undocumented and is not assigned a retrospective value.

Finite solver caps and stopping causes are preserved. Of 80 new PercePiano BFWK fits, 73 stop by relative-objective tolerance, five by projected-gradient tolerance and two at the outer cap. All 240 final outer model SVC statuses are successful. A small objective change is not a certificate of stationarity. See README_Revision_Core.md for details.

## Reproduction

Use Python 3.12 and the measured dependency versions in requirements_revision.txt. Dependencies are not bundled. Run from this directory in a fresh copy to preserve the packaged evidence. The PercePiano source archive is bundled, so its extraction does not require a network connection:

```text
python -m pip install -r requirements_revision.txt
python revision_percepiano_download.py
python revision_percepiano_ratings.py --source source_data/PercePiano/labels/total_2rounds.csv --output results_percepiano
python revision_percepiano_features.py --input source_data/PercePiano/virtuoso/data/all_2rounds --output results_percepiano
python revision_percepiano_analysis.py --phase all --workers 3
python revision_percepiano_validate.py
python revision_percepiano_data_plots.py
python revision_percepiano_result_plots.py
```

The model driver resumes existing completed records. For a full numerical rerun, preserve a copy of the supplied results and relocate results_percepiano/fit_records and bootstrap_records before running the analysis; keep the generated ratings/features. Seeds, split IDs and finite budgets are recorded in analysis_protocol.json. The saved model arrays retain the training IDs and preprocessing parameters; training matrices are reconstructed from features.csv. Runtime and last-bit floating-point differences can vary by machine.

To reproduce the added public-data studies:

```text
python revision_factorial_jitter.py
python revision_inner_retry_and_traces.py
python revision_sensitivity_audit.py
python revision_scaling_diagnostic.py
python revision_stress_properties.py
python revision_publication_plots.py
python revision_public_plots.py
```

The public data used by the new drivers come with the pinned scikit-learn/statsmodels versions. The archived historical driver can require separate OpenML downloads. revision_group_mass_plot.py and its corresponding result files reproduce an earlier archived case-study display and are not used in the revised PercePiano section.

