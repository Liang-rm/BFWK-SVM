import argparse, importlib.util, pathlib, sys, time, re
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.metrics import balanced_accuracy_score
from sklearn.svm import LinearSVC
from scipy import stats

BASE=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('bfwkbase',BASE/'benchmark_bfwk.py')
b=importlib.util.module_from_spec(spec); sys.modules['bfwkbase']=b; spec.loader.exec_module(b)
OUT=BASE/'benchmark_results_tuned'; OUT.mkdir(exist_ok=True)
SEED=b.SEED
RR_GRID=[(l,r,t) for l in (0.04,0.10) for r in (0.10,0.30) for t in (0.20,0.50)]

def split_regularizer_validation(Xdf,y,train_idx,seed):
    idx=np.asarray(train_idx)
    splitter=StratifiedShuffleSplit(n_splits=1,test_size=0.25,random_state=seed)
    a,bidx=next(splitter.split(np.zeros(len(idx)),y[idx]))
    return idx[a],idx[bidx]

def tune_rr(Xdf,y,train_idx,C,gamma,seed,method='BFWK'):
    tr,va=split_regularizer_validation(Xdf,y,train_idx,seed)
    pre=b.make_preprocessor(Xdf.iloc[tr]); Xa=pre.fit_transform(Xdf.iloc[tr]); Xv=pre.transform(Xdf.iloc[va])
    keep=np.std(Xa,axis=0)>1e-10; Xa=Xa[:,keep];Xv=Xv[:,keep]; ya=y[tr]; yv=y[va]
    q,M=b.compute_q_M(Xa,ya)
    vals=[]
    for lam,rho,tau in RR_GRID:
        if method=='BFWK':
            m=b.fit_bfwk(Xa,ya,C,gamma,lam=lam,rho=rho,tau=tau,max_outer=5,eps_alpha=2e-4,eps_J=2e-5)
        else:
            alpha=b.two_stage_alpha(q,M,lam=lam,rho=rho,tau=tau)
            m=b.fit_fixed_weight(Xa,ya,C,gamma,alpha)
        s=b.predict_kernel(m,Xv)
        vals.append(balanced_accuracy_score(yv,np.where(s>=0,1,-1)))
    best=int(np.argmax(vals))
    return RR_GRID[best],float(vals[best])

def evaluate(ds,max_n=1000):
    Xdf,y=b.stratified_subsample(ds.X,ds.y,max_n=max_n,seed=SEED)
    k=min(5,int(min(np.sum(y==1),np.sum(y==-1))))
    cv=StratifiedKFold(n_splits=k,shuffle=True,random_state=SEED)
    rows=[];meta=[]
    for fold,(tr,te) in enumerate(cv.split(Xdf,y),1):
        (C,gamma),cg_score=b.tune_C_gamma(Xdf,y,tr,SEED+fold)
        rr_b,rr_b_score=tune_rr(Xdf,y,tr,C,gamma,SEED+100+fold,'BFWK')
        rr_t,rr_t_score=tune_rr(Xdf,y,tr,C,gamma,SEED+200+fold,'TwoStage')
        pre=b.make_preprocessor(Xdf.iloc[tr]); Xtr=pre.fit_transform(Xdf.iloc[tr]);Xte=pre.transform(Xdf.iloc[te])
        keep=np.std(Xtr,axis=0)>1e-10;Xtr=Xtr[:,keep];Xte=Xte[:,keep];ytr=y[tr];yte=y[te]
        q,M=b.compute_q_M(Xtr,ytr)
        # linear
        lin=LinearSVC(C=C,class_weight='balanced',dual='auto',max_iter=10000).fit(Xtr,ytr)
        rr=b.metrics(yte,lin.decision_function(Xte));rr.update(dataset=ds.name,fold=fold,method='Linear SVM');rows.append(rr)
        # fixed kernel comparators
        fixed={
            'RBF-SVM':np.full(Xtr.shape[1],1/Xtr.shape[1]),
            'Relevance-SVM':q/(q.sum()+1e-12),
            'mRMR-SVM':b.mrmr_alpha(Xtr,ytr),
            'Two-stage RR-SVM':b.two_stage_alpha(q,M,lam=rr_t[0],rho=rr_t[1],tau=rr_t[2]),
        }
        for name,a in fixed.items():
            m=b.fit_fixed_weight(Xtr,ytr,C,gamma,a);rr=b.metrics(yte,b.predict_kernel(m,Xte));rr.update(dataset=ds.name,fold=fold,method=name);rows.append(rr)
        t0=time.time();m=b.fit_bfwk(Xtr,ytr,C,gamma,lam=rr_b[0],rho=rr_b[1],tau=rr_b[2],max_outer=12,eps_alpha=1e-4,eps_J=1e-5);elapsed=time.time()-t0
        rr=b.metrics(yte,b.predict_kernel(m,Xte));rr.update(dataset=ds.name,fold=fold,method='BFWK-SVM');rows.append(rr)
        meta.append({'dataset':ds.name,'fold':fold,'n_train':len(tr),'n_test':len(te),'d_transformed':Xtr.shape[1],
                     'C':C,'gamma':gamma,'cg_inner_BA':cg_score,
                     'lambda':rr_b[0],'rho':rr_b[1],'tau':rr_b[2],'bfwk_rr_inner_BA':rr_b_score,
                     'two_lambda':rr_t[0],'two_rho':rr_t[1],'two_tau':rr_t[2],'two_rr_inner_BA':rr_t_score,
                     'bfwk_outer_iter':len(m['history']),'bfwk_seconds':elapsed,
                     'bfwk_weight_max':float(m['alpha'].max()),
                     'bfwk_weight_entropy':float(-np.sum(m['alpha'][m['alpha']>0]*np.log(m['alpha'][m['alpha']>0])))})
        print(f"{ds.name:14s} fold {fold}/{k} C={C:g} g={gamma:g} rr={rr_b} BFWK={rows[-1]['BalancedAccuracy']:.3f}",flush=True)
    return pd.DataFrame(rows),pd.DataFrame(meta),pd.DataFrame([{'Dataset':ds.name,'N':len(y),'RawFeatures':Xdf.shape[1],
             'PositiveRate':float(np.mean(y==1)),'Source':ds.source,'TaskNote':ds.note}])

def holm(pvals):
    items=sorted(pvals.items(),key=lambda z:z[1]);m=len(items);out={};run=0
    for i,(k,p) in enumerate(items):
        run=max(run,(m-i)*p);out[k]=min(1.0,run)
    return out

def aggregate():
    fs=sorted(OUT.glob('fold_*.csv'));ms=sorted(OUT.glob('meta_*.csv'));infos=sorted(OUT.glob('info_*.csv'))
    raw=pd.concat([pd.read_csv(x) for x in fs],ignore_index=True); raw.to_csv(OUT/'benchmark_fold_results.csv',index=False)
    pd.concat([pd.read_csv(x) for x in ms],ignore_index=True).to_csv(OUT/'benchmark_fit_metadata.csv',index=False)
    info=pd.concat([pd.read_csv(x) for x in infos],ignore_index=True).drop_duplicates('Dataset');info.to_csv(OUT/'benchmark_datasets.csv',index=False)
    summary=(raw.groupby(['dataset','method'])[['BalancedAccuracy','MacroF1','AUROC','MCC']].agg(['mean','std']).reset_index())
    summary.columns=['dataset','method']+[f'{a}_{c}' for a,c in summary.columns.tolist()[2:]];summary.to_csv(OUT/'benchmark_summary.csv',index=False)
    pivot=summary.pivot(index='dataset',columns='method',values='BalancedAccuracy_mean').dropna()
    ranks=pivot.rank(axis=1,ascending=False,method='average');av=ranks.mean().sort_values()
    rdf=pd.DataFrame({'Method':av.index,'AverageRank':av.values,'MeanBalancedAccuracy':[pivot[c].mean() for c in av.index]});rdf.to_csv(OUT/'benchmark_average_ranks.csv',index=False)
    fried=stats.friedmanchisquare(*[pivot[c].values for c in pivot.columns])
    pvals={};diffs={}
    for c in pivot.columns:
        if c=='BFWK-SVM':continue
        d=pivot['BFWK-SVM']-pivot[c];diffs[c]=d.mean()
        try:pvals[c]=float(stats.wilcoxon(d,zero_method='wilcox').pvalue)
        except:pvals[c]=1.0
    adj=holm(pvals);st=[{'Comparison':'Friedman omnibus','Statistic':fried.statistic,'p_value':fried.pvalue,'Holm_p':np.nan,'Mean_BA_Difference':np.nan}]
    st += [{'Comparison':f'BFWK-SVM vs {c}','Statistic':np.nan,'p_value':pvals[c],'Holm_p':adj[c],'Mean_BA_Difference':diffs[c]} for c in sorted(pvals,key=pvals.get)]
    pd.DataFrame(st).to_csv(OUT/'benchmark_statistical_tests.csv',index=False)
    pivot.to_csv(OUT/'balanced_accuracy_matrix.csv');
    with open(OUT/'benchmark_table.tex','w') as f:f.write(pivot.to_latex(float_format=lambda x:f'{x:.3f}',escape=True))
    with open(OUT/'rank_table.tex','w') as f:f.write(rdf.to_latex(index=False,float_format=lambda x:f'{x:.3f}',escape=True))
    print('\n',rdf.to_string(index=False));print('\nFriedman',fried);print(pd.DataFrame(st).to_string(index=False))

def main():
    p=argparse.ArgumentParser();p.add_argument('--datasets',nargs='*');p.add_argument('--aggregate-only',action='store_true');a=p.parse_args()
    if a.aggregate_only:return aggregate()
    wanted=set(a.datasets) if a.datasets else None
    for ds in b.make_datasets():
        if wanted is not None and ds.name not in wanted:continue
        safe=re.sub(r'[^A-Za-z0-9]+','_',ds.name).strip('_');print('\n===',ds.name,'===',flush=True)
        r,m,i=evaluate(ds);r.to_csv(OUT/f'fold_{safe}.csv',index=False);m.to_csv(OUT/f'meta_{safe}.csv',index=False);i.to_csv(OUT/f'info_{safe}.csv',index=False)
    aggregate()
if __name__=='__main__':main()
