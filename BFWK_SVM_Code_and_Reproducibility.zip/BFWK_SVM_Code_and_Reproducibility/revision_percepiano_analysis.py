"""Reconstructed PercePiano analysis from the fixed public release.

This protocol uses observable MIDI descriptors and explicit released question
IDs. It does not reconstruct the unavailable feature matrix or the numerical
results of the original submitted case study. No released code is executed.
"""
from __future__ import annotations
import os
for _key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ[_key]='1'
from pathlib import Path
import argparse,collections,concurrent.futures,csv,functools,hashlib,json,time,warnings
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits
from revision_core import (fit_bfwk,fit_fixed_weight,predict_kernel,two_stage_alpha,
                           compute_q_M,metrics,weighted_kernel)

HERE=Path(__file__).resolve().parent
OUT=HERE/'results_percepiano'
SEED=20261020
TARGETS=['interpretation','composite_ivw_1e_4','composite_equal','composite_zmean',
         'single13','single15','single18','composite_ivw_1e_6',
         'composite_ivw_1e_2','composite_ivw_released_rows']
PARAMS={'lam':.08,'rho':.18,'tau':.35,'jitter':1e-6,'max_outer':100,
        'svc_tol':1e-7,'svc_max_iter':50000,'min_step':2**-20,
        'eps_alpha':1e-4,'eps_J':1e-8,'objective':'normalized'}

def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')

def finite(value):
    if isinstance(value,(np.integer,)):return int(value)
    if isinstance(value,(float,np.floating)):return float(value) if np.isfinite(value) else None
    if isinstance(value,np.ndarray):return [finite(v) for v in value.tolist()]
    if isinstance(value,dict):return {str(k):finite(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [finite(v) for v in value]
    return value

@functools.lru_cache(None)
def data():
    meta=pd.read_csv(OUT/'feature_metadata.csv',dtype={'segment_id':str})
    features=pd.read_csv(OUT/'features.csv')
    targets=pd.read_csv(OUT/'target_continuous.csv',dtype={'segment_id':str})
    basis=pd.read_csv(OUT/'target_basis.csv',dtype={'segment_id':str})
    assert meta.segment_id.is_unique and features.filename.is_unique
    assert targets.segment_id.is_unique and basis.segment_id.is_unique
    joined=meta.merge(features,on='filename',validate='one_to_one').merge(targets,on='segment_id',validate='one_to_one').merge(basis,on='segment_id',validate='one_to_one',suffixes=('','_basis'))
    feature_names=list(features.columns[1:])
    eligible=joined['eligible_four'].astype(str).str.lower().isin(['1','1.0','true'])
    keep=(pd.to_numeric(joined['is_control'])==0)&eligible
    for name in TARGETS:
        if name!='composite_zmean':keep&=np.isfinite(pd.to_numeric(joined[name],errors='coerce'))
    for k in [13,15,18,19]:keep&=(joined[f'n{k}']>=2)&np.isfinite(joined[f'mean{k}'])
    df=joined.loc[keep].sort_values('segment_id').reset_index(drop=True)
    assert len(df)>900 and df.segment_id.is_unique
    assert len(feature_names)==45
    groups=json.loads((OUT/'feature_groups.json').read_text(encoding='utf-8'))['groups']
    return {'df':df,'X':df[feature_names].to_numpy(float),'features':feature_names,
            'groups':groups,'joined_n':len(joined),'excluded_n':int(len(joined)-len(df))}

def score_vector(d,target,train):
    df=d['df']
    if target=='composite_zmean':
        mu=df[[f'mean{k}' for k in [13,15,18,19]]].to_numpy(float)
        center=mu[train].mean(axis=0);scale=mu[train].std(axis=0)
        scale=np.where(scale>1e-12,scale,1.)
        return ((mu-center)/scale).mean(axis=1),{'center':center.tolist(),'scale':scale.tolist()}
    return df[target].to_numpy(float),{}

def preprocessing(X,train):
    tr=X[train]
    with warnings.catch_warnings():
        warnings.simplefilter('ignore',RuntimeWarning)
        mask=(np.isfinite(tr).sum(axis=0)>=2)&(np.nanstd(tr,axis=0)>1e-12)
        med=np.nanmedian(tr[:,mask],axis=0)
    filled=np.where(np.isfinite(X[:,mask]),X[:,mask],med)
    center=filled[train].mean(axis=0);scale=filled[train].std(axis=0)
    assert np.all(scale>0)
    z=(filled-center)/scale
    return z,{'mask':mask,'median':med,'center':center,'scale':scale}

def outer_splits(d):
    result=[];df=d['df']
    for protocol,field,k in [('performer_code','performer_group',5),('work','work',3)]:
        groups=df[field].to_numpy(str)
        assert len(np.unique(groups))>=k
        for fold,(tr,te) in enumerate(GroupKFold(k).split(d['X'],groups=groups),1):
            assert not(set(groups[tr])&set(groups[te]))
            result.append({'protocol':protocol,'group_field':field,'fold':fold,
                           'train':tr.tolist(),'test':te.tolist(),
                           'train_groups':sorted(set(groups[tr])),'test_groups':sorted(set(groups[te]))})
    return result

def prepare():
    OUT.mkdir(exist_ok=True)
    d=data();splits=outer_splits(d)
    protocol={
      'version':'public-MIDI-reconstruction-1','seed':SEED,
      'data_commit':'e672299b8661f63802cd5cd73bb3c76218a13029',
      'cohort':'Human MIDI performances with at least two valid rater-level observations for each selected question; same cohort for all targets.',
      'all_release_segments_joined':d['joined_n'],'analysis_n':len(d['df']),
      'performer_code_groups':int(d['df'].performer_group.nunique()),'work_groups':int(d['df'].work.nunique()),
      'primary_target':'Official question 19: Unsatisfactory/doubtful to Convincing interpretation, mean (rating-1)/6.',
      'new_composite':'Questions 13,15,18,19; high values indicate the named Spacious/Dramatic/Imaginative/Convincing poles, not a validated general quality scale.',
      'targets':TARGETS,'target_threshold':'Training-fold median, positive if score >= median. Z-mean centers/scales fitted on training labels only.',
      'features':'45 observable MIDI descriptors; timing, velocity dynamics, articulation, CC64 pedal, normalized-time phrasing proxies. No audio timbre or score-alignment claim.',
      'preprocessing':'Drop columns with fewer than 2 finite training values or zero training nan-variance; training medians; training mean and population SD. No outcome-dependent feature selection.',
      'grouped_evaluation':'5 outer performer-code folds, with composer/cohort namespacing; 3 leave-work-out folds, merging both D960 movements and all WoO80 variations.',
      'hyperparameter_selection':'Common C/gamma selected inside each outer training fold using uniform-RBF primary-interpretation validation BA; fixed across target definitions and methods to isolate target effects. No outer-test tuning.',
      'C_grid':[.25,4,64],'gamma_grid':[.1,1,10],
      'inner_folds':'3 performer-code folds; 2 work folds within each outer training partition.',
      'methods':['BFWK-N','Uniform-RBF','Two-stage-RR'],'BFWK_parameters':PARAMS,
      'two_stage':'Regularizer-only simplex projected updates, step 1/(lambda+rho*||M||2), max300, weight-change tol1e-8, then fixed-kernel SVC.',
      'inner_retry':'If any SVC solve reaches its cap, repeat the complete fit once with cap200000; retain retry status.',
      'permutation':'Primary interpretation BFWK only; each held-out feature and each declared feature group jointly shuffled 20 times; BA decreases; repeat SD is descriptive. Correlations with weights are descriptive across features.',
      'bootstrap':'50 performer-group resamples of the first performer-code outer training fold; fixed selected hyperparameters and original training-fold target threshold; refit preprocessing, q/M and weights; original held-out set never sampled. Correlated clusters use connected components of absolute training Pearson correlation >=0.8.',
      'historical_scope':'New reconstructed analysis; does not reproduce the original unpublished feature matrix, target mapping, timings, or0.812 performance estimate.'}
    dump(OUT/'analysis_protocol.json',protocol)
    dump(OUT/'analysis_splits.json',splits)
    checks=[]
    for split in splits:
        tr=np.asarray(split['train']);te=np.asarray(split['test'])
        for name in TARGETS:
            y,_=score_vector(d,name,tr);cut=float(np.median(y[tr]))
            a=np.where(y[tr]>=cut,1,-1);b=np.where(y[te]>=cut,1,-1)
            assert len(np.unique(a))==2,(split['protocol'],split['fold'],name)
            assert len(np.unique(b))==2,(split['protocol'],split['fold'],name)
            checks.append({'protocol':split['protocol'],'fold':split['fold'],'target':name,'train_positive':int((a==1).sum()),'test_positive':int((b==1).sum()),'threshold':cut})
    pd.DataFrame(checks).to_csv(OUT/'label_split_checks.csv',index=False)
    d['df'][['segment_id','filename','performer_group','work']].to_csv(OUT/'analysis_cohort.csv',index=False)
    print(json.dumps({'cohort':len(d['df']),'features':45,'splits':len(splits),'targets':len(TARGETS)}),flush=True)

def tuning_job(split):
    with threadpool_limits(limits=1):
        d=data();tr=np.asarray(split['train']);groups=d['df'][split['group_field']].to_numpy(str)
        k=3 if split['protocol']=='performer_code' else 2
        scores=[]
        for inner,(aa,bb) in enumerate(GroupKFold(k).split(tr,groups=groups[tr]),1):
            a=tr[aa];b=tr[bb]
            X,prep=preprocessing(d['X'],a)
            target,_=score_vector(d,'interpretation',a);cut=float(np.median(target[a]));y=np.where(target>=cut,1,-1)
            for gamma in [.1,1,10]:
                for C in [.25,4,64]:
                    model,retry=fit_model(X[a],y[a],'Uniform-RBF',C,gamma)
                    m=metrics(y[b],predict_kernel(model,X[b]))
                    scores.append({'protocol':split['protocol'],'fold':split['fold'],'inner_fold':inner,'C':C,'gamma':gamma,'BA':m['BalancedAccuracy'],'dual_status':model['dual_fit_status'],'inner_retry':retry})
        tab=pd.DataFrame(scores)
        agg=tab.groupby(['C','gamma'],as_index=False).BA.mean().sort_values(['BA','C','gamma'],ascending=[False,True,True])
        choice=agg.iloc[0]
        return {'protocol':split['protocol'],'fold':split['fold'],'C':float(choice.C),'gamma':float(choice.gamma),'inner_BA':float(choice.BA),'grid':scores}

def tune(workers):
    splits=json.loads((OUT/'analysis_splits.json').read_text())
    choices=[];grid=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        fs=[pool.submit(tuning_job,s) for s in splits]
        for f in concurrent.futures.as_completed(fs):
            x=f.result();grid+=x.pop('grid');choices.append(x)
            print('tuned',x,flush=True)
    pd.DataFrame(choices).sort_values(['protocol','fold']).to_csv(OUT/'hyperparameter_choices.csv',index=False)
    pd.DataFrame(grid).sort_values(['protocol','fold','inner_fold','C','gamma']).to_csv(OUT/'inner_tuning_grid.csv',index=False)

def fit_model(X,y,method,C,gamma,cap=50000):
    retry=False
    if method=='BFWK-N':
        params={**PARAMS,'svc_max_iter':cap}
        model=fit_bfwk(X,y,C,gamma,**params)
        if model['dual_fit_status'] and cap<200000:
            model=fit_bfwk(X,y,C,gamma,**{**params,'svc_max_iter':200000});retry=True
    else:
        if method=='Uniform-RBF':alpha=np.full(X.shape[1],1/X.shape[1])
        else:
            q,M=compute_q_M(X,y);alpha=two_stage_alpha(q,M)
        # fit_fixed_weight has a fixed 50k budget; rerun its underlying solver if needed.
        model=fit_fixed_weight(X,y,C,gamma,alpha,jitter=1e-6,svc_tol=1e-7)
        if model['dual_fit_status']:
            from revision_core import fit_precomputed_svc
            clf,u,V=fit_precomputed_svc(weighted_kernel(X,X,alpha,gamma),y,C,jitter=1e-6,tol=1e-7,max_iter=200000)
            model.update(clf=clf,u=u,beta=np.abs(u),dual_value=V,intercept=float(clf.intercept_[0]),dual_fit_status=int(clf.fit_status_));retry=True
    return model,retry

def fit_job(spec):
    split,target=spec['split'],spec['target']
    key=f"{split['protocol']}_fold{split['fold']}_{target}"
    folder=OUT/'fit_records';folder.mkdir(exist_ok=True)
    path=folder/(key+'.json')
    if path.exists():return {'key':key,'cached':True}
    with threadpool_limits(limits=1):
        d=data();tr=np.asarray(split['train']);te=np.asarray(split['test'])
        X,prep=preprocessing(d['X'],tr)
        continuous,transform=score_vector(d,target,tr)
        cut=float(np.median(continuous[tr]));y=np.where(continuous>=cut,1,-1)
        base,_=score_vector(d,'composite_ivw_1e_4',tr)
        base_y=np.where(base>=np.median(base[tr]),1,-1)
        methods=[];start=time.perf_counter()
        for method in ['BFWK-N','Uniform-RBF','Two-stage-RR']:
            model,retry=fit_model(X[tr],y[tr],method,spec['C'],spec['gamma'])
            score=predict_kernel(model,X[te]);m=metrics(y[te],score)
            alpha=np.zeros(45);alpha[prep['mask']]=model['alpha']
            model_path=folder/(key+'_'+method+'.npz')
            np.savez_compressed(model_path,alpha=alpha,retained_mask=prep['mask'],median=prep['median'],center=prep['center'],scale=prep['scale'],u=model['u'],intercept=model['intercept'],gamma=spec['gamma'],C=spec['C'],train=tr,test=te,score=score,ytest=y[te],continuous_test=continuous[te],threshold=cut)
            record={'method':method,**m,'dual_fit_status':model['dual_fit_status'],'inner_retry':retry,'alpha':alpha.tolist(),
                    'termination':model.get('termination','single_SVC_fit'),'residual':model.get('projected_gradient_residual'),
                    'outer_iterations':len(model.get('history',[])),'evaluations':model.get('evaluations',1),'history':model.get('history',[]),'fit_seconds':model.get('seconds'),
                    'predictions':score.tolist(),'ytest':y[te].tolist(),'model_file':model_path.name}
            methods.append(record)
        result={'key':key,'protocol':split['protocol'],'fold':split['fold'],'target':target,'C':spec['C'],'gamma':spec['gamma'],
                'n_train':len(tr),'n_test':len(te),'d_retained':int(prep['mask'].sum()),'retained_mask':prep['mask'].tolist(),
                'threshold':cut,'target_transform':transform,'test':te.tolist(),'continuous_test':continuous[te].tolist(),
                'test_label_flip_vs_ivw':float(np.mean(y[te]!=base_y[te])),
                'target_spearman_vs_ivw':float(spearmanr(continuous[te],base[te]).statistic),
                'seconds':time.perf_counter()-start,'methods':methods}
        dump(path,finite(result))
        return {'key':key,'seconds':result['seconds'],'BFWK_BA':methods[0]['BalancedAccuracy'],'termination':methods[0]['termination']}

def fit_all(workers,limit=None):
    splits=json.loads((OUT/'analysis_splits.json').read_text())
    choice=pd.read_csv(OUT/'hyperparameter_choices.csv')
    specs=[]
    for split in splits:
        p=choice[(choice.protocol==split['protocol'])&(choice.fold==split['fold'])].iloc[0]
        for target in TARGETS:specs.append({'split':split,'target':target,'C':float(p.C),'gamma':float(p.gamma)})
    if limit:specs=specs[:limit]
    started=time.perf_counter()
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        fs=[pool.submit(fit_job,s) for s in specs]
        for i,f in enumerate(concurrent.futures.as_completed(fs),1):
            print(json.dumps({'done':i,'total':len(fs),**f.result(),'elapsed':time.perf_counter()-started}),flush=True)

def bootstrap_job(b):
    path=OUT/'bootstrap_records'/f'bootstrap_{b:03d}.json'
    path.parent.mkdir(exist_ok=True)
    if path.exists():return {'bootstrap':b,'cached':True}
    with threadpool_limits(limits=1):
        d=data();split=[s for s in json.loads((OUT/'analysis_splits.json').read_text()) if s['protocol']=='performer_code' and s['fold']==1][0]
        tr=np.asarray(split['train']);group=d['df'].performer_group.to_numpy(str)
        unique=np.unique(group[tr]);rng=np.random.default_rng(SEED+10000+b)
        sampled=rng.choice(unique,size=len(unique),replace=True)
        train=np.concatenate([tr[group[tr]==g] for g in sampled])
        X,prep=preprocessing(d['X'],train)
        target,_=score_vector(d,'interpretation',tr);cut=float(np.median(target[tr]));y=np.where(target>=cut,1,-1)
        choice=pd.read_csv(OUT/'hyperparameter_choices.csv');p=choice[(choice.protocol=='performer_code')&(choice.fold==1)].iloc[0]
        model,retry=fit_model(X[train],y[train],'BFWK-N',float(p.C),float(p.gamma))
        alpha=np.zeros(45);alpha[prep['mask']]=model['alpha']
        result={'bootstrap':b,'sampled_groups':sampled.tolist(),'n':len(train),'alpha':alpha.tolist(),'retained_mask':prep['mask'].tolist(),
                'threshold':cut,'termination':model['termination'],'residual':model['projected_gradient_residual'],
                'inner_status':model['dual_fit_status'],'inner_retry':retry,'seconds':model['seconds']}
        dump(path,finite(result));return {k:result[k] for k in ['bootstrap','n','termination','seconds']}

def bootstrap(workers,B=50):
    with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
        fs=[pool.submit(bootstrap_job,b) for b in range(B)]
        for i,f in enumerate(concurrent.futures.as_completed(fs),1):print(json.dumps({'done':i,'total':B,**f.result()}),flush=True)

def permutation():
    with threadpool_limits(limits=1):
        d=data();df=d['df'];rows=[];group_rows=[];assoc=[]
        paths=sorted((OUT/'fit_records').glob('*_interpretation.json'))
        assert len(paths)==8
        for j,path in enumerate(paths):
            record=json.loads(path.read_text());m=[x for x in record['methods'] if x['method']=='BFWK-N'][0]
            arrays=np.load(OUT/'fit_records'/m['model_file'])
            mask=arrays['retained_mask'];names=np.asarray(d['features'])[mask];fullalpha=arrays['alpha'];alpha=fullalpha[mask]
            te=arrays['test'];X=(np.where(np.isfinite(d['X'][te][:,mask]),d['X'][te][:,mask],arrays['median'])-arrays['center'])/arrays['scale']
            raw_train=d['X'][arrays['train']][:,mask]
            train=(np.where(np.isfinite(raw_train),raw_train,arrays['median'])-arrays['center'])/arrays['scale']
            u=arrays['u'];sv=np.abs(u)>0
            train=train[sv];u=u[sv];gamma=float(arrays['gamma']);bias=float(arrays['intercept']);y=arrays['ytest']
            A=X*np.sqrt(alpha);B=train*np.sqrt(alpha)
            D=np.maximum(np.sum(A*A,axis=1)[:,None]+np.sum(B*B,axis=1)[None,:]-2*A@B.T,0)
            K=np.exp(-gamma*D);score=K@u+bias
            assert np.max(np.abs(score-arrays['score']))<1e-7
            base=metrics(y,score)['BalancedAccuracy']
            rng=np.random.default_rng(SEED+20000+j);perms=[rng.permutation(len(te)) for _ in range(20)]
            def drops(indices):
                values=[]
                original=sum(alpha[k]*(X[:,k,None]-train[None,:,k])**2 for k in indices)
                for perm in perms:
                    changed=sum(alpha[k]*(X[perm,k,None]-train[None,:,k])**2 for k in indices)
                    kernel=np.exp(-gamma*np.maximum(D+changed-original,0))
                    values.append(base-metrics(y,kernel@u+bias)['BalancedAccuracy'])
                return values
            for k,name in enumerate(names):
                values=drops([k]);rows.append({'protocol':record['protocol'],'fold':record['fold'],'feature':name,'alpha':float(alpha[k]),'importance_mean':float(np.mean(values)),'importance_sd_repeats':float(np.std(values,ddof=1)),'baseline_BA':base,'repeats':20})
            for group,columns in d['groups'].items():
                indices=[k for k,name in enumerate(names) if name in columns]
                values=drops(indices) if indices else [0.]*20
                group_rows.append({'protocol':record['protocol'],'fold':record['fold'],'group':group,'retained_count':len(indices),
                                   'mass':float(sum(alpha[k] for k in indices)),'mean_weight_per_feature':float(np.mean(alpha[indices])) if indices else None,
                                   'importance_mean':float(np.mean(values)),'importance_sd_repeats':float(np.std(values,ddof=1)),'repeats':20})
            current=[r for r in group_rows if r['protocol']==record['protocol'] and r['fold']==record['fold']]
            denom=sum(r['mean_weight_per_feature'] or 0. for r in current)
            for r in current:r['renormalized_mean_weight']=(r['mean_weight_per_feature'] or 0.)/denom if denom else None
            local=pd.DataFrame([r for r in rows if r['protocol']==record['protocol'] and r['fold']==record['fold']])
            assoc.append({'protocol':record['protocol'],'fold':record['fold'],'features':len(local),'spearman_alpha_vs_permutation':float(spearmanr(local.alpha,local.importance_mean).statistic)})
            pd.DataFrame(rows).to_csv(OUT/'permutation_feature_results.csv',index=False)
            pd.DataFrame(group_rows).to_csv(OUT/'permutation_group_results.csv',index=False)
            pd.DataFrame(assoc).to_csv(OUT/'weight_permutation_associations.csv',index=False)
            print('permutation',record['protocol'],record['fold'],flush=True)

def summarize():
    d=data();foldrows=[];predrows=[];weights=[];targetrows=[]
    paths=sorted((OUT/'fit_records').glob('*.json'))
    for path in paths:
        r=json.loads(path.read_text())
        targetrows.append({k:r[k] for k in ['protocol','fold','target','test_label_flip_vs_ivw','target_spearman_vs_ivw','threshold']})
        for m in r['methods']:
            row={k:r[k] for k in ['protocol','fold','target','C','gamma','n_train','n_test','d_retained']}
            row.update({k:m[k] for k in ['method','BalancedAccuracy','Accuracy','MacroF1','AUROC','MCC','dual_fit_status','inner_retry','termination','residual','outer_iterations','evaluations','fit_seconds']})
            foldrows.append(row)
            for i,score,y,cont in zip(r['test'],m['predictions'],m['ytest'],r['continuous_test']):
                predrows.append({'protocol':r['protocol'],'fold':r['fold'],'target':r['target'],'method':m['method'],'segment_id':d['df'].iloc[i].segment_id,'score':score,'label':y,'continuous_target':cont})
            for name,a,retained in zip(d['features'],m['alpha'],r['retained_mask']):
                weights.append({'protocol':r['protocol'],'fold':r['fold'],'target':r['target'],'method':m['method'],'feature':name,'alpha':a,'retained':retained})
    folds=pd.DataFrame(foldrows)
    folds.to_csv(OUT/'model_fold_results.csv',index=False)
    pd.DataFrame(predrows).to_csv(OUT/'heldout_predictions.csv',index=False)
    pd.DataFrame(weights).to_csv(OUT/'learned_feature_weights.csv',index=False)
    pd.DataFrame(targetrows).to_csv(OUT/'target_fold_agreement.csv',index=False)
    summary=folds.groupby(['protocol','target','method'])[['BalancedAccuracy','Accuracy','MacroF1','AUROC','MCC']].agg(['mean','std'])
    summary.columns=['_'.join(c) for c in summary.columns];summary.reset_index().to_csv(OUT/'model_summary.csv',index=False)
    folds.groupby(['protocol','method','termination']).size().reset_index(name='fits').to_csv(OUT/'termination_counts.csv',index=False)
    # Every diagnostic is tied to the fixed first performer-code training fold.
    bootpaths=sorted((OUT/'bootstrap_records').glob('*.json'))
    if bootpaths:
        boot=[json.loads(p.read_text()) for p in bootpaths]
        a=np.asarray([b['alpha'] for b in boot]);norm=a/np.linalg.norm(a,axis=1)[:,None]
        pair=(norm@norm.T)[np.triu_indices(len(a),1)]
        split=[s for s in json.loads((OUT/'analysis_splits.json').read_text()) if s['protocol']=='performer_code' and s['fold']==1][0]
        X,prep=preprocessing(d['X'],np.asarray(split['train']))
        corr=np.abs(np.corrcoef(X[split['train']].T));np.fill_diagonal(corr,0)
        collin=np.zeros(45);collin[prep['mask']]=corr.max(axis=1)
        sd=a.std(axis=0,ddof=1);mean=a.mean(axis=0)
        cv=sd/np.maximum(mean,1e-6)
        retained=np.asarray([b['retained_mask'] for b in boot],dtype=bool)
        pd.DataFrame({'feature':d['features'],'mean_weight':mean,'weight_sd':sd,'weight_cv_eps1e_6':cv,'weight_q025':np.quantile(a,.025,axis=0),'weight_q975':np.quantile(a,.975,axis=0),'nonzero_weight_frequency':np.mean(a>1e-6,axis=0),'retained_frequency':retained.mean(axis=0),'max_abs_training_correlation':collin,'retained_reference':prep['mask']}).to_csv(OUT/'bootstrap_weight_stability.csv',index=False)
        pd.DataFrame([{k:v for k,v in b.items() if k not in ['alpha','retained_mask','sampled_groups']} for b in boot]).to_csv(OUT/'bootstrap_fit_diagnostics.csv',index=False)
        mask=prep['mask']
        record={'replicates':len(a),'pairwise_cosine_mean':float(pair.mean()),'pairwise_cosine_sd':float(pair.std(ddof=1)),
                'spearman_collinearity_vs_weight_sd':float(spearmanr(collin[mask],sd[mask]).statistic),
                'spearman_collinearity_vs_weight_cv':float(spearmanr(collin[mask],cv[mask]).statistic),
                'scope':'Descriptive across features, conditional on fixed hyperparameters and first performer-code outer training fold.'}
        dump(OUT/'bootstrap_stability_summary.json',finite(record))
        group=[]
        meanweight=[]
        for name,cols in d['groups'].items():
            ids=[d['features'].index(c) for c in cols]
            count=retained[:,ids].sum(axis=1)
            meanweight.append(a[:,ids].sum(axis=1)/np.maximum(count,1))
        meanweight=np.asarray(meanweight).T
        normmean=meanweight/meanweight.sum(axis=1)[:,None]
        for gi,(name,cols) in enumerate(d['groups'].items()):
            ids=[d['features'].index(c) for c in cols]
            masses=a[:,ids].sum(axis=1)
            count=retained[:,ids].sum(axis=1)
            group.append({'group':name,'declared_count':len(ids),'retained_count_min':int(count.min()),'retained_count_max':int(count.max()),'mass_mean':masses.mean(),'mass_sd':masses.std(ddof=1),'mass_q025':np.quantile(masses,.025),'mass_q975':np.quantile(masses,.975),'mean_weight_per_feature_mean':meanweight[:,gi].mean(),'renormalized_mean_weight_mean':normmean[:,gi].mean()})
        pd.DataFrame(group).to_csv(OUT/'bootstrap_group_stability.csv',index=False)
        ids=np.flatnonzero(mask);parent=list(range(len(ids)))
        def find(i):
            while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
            return i
        for i in range(len(ids)):
            for j in range(i):
                if corr[i,j]>=.8:parent[find(i)]=find(j)
        clusters=collections.defaultdict(list)
        for i,k in enumerate(ids):clusters[find(i)].append(k)
        clusterrows=[]
        for c,indices in enumerate(clusters.values(),1):
            mass=a[:,indices].sum(axis=1)
            clusterrows.append({'cluster':c,'size':len(indices),'features':'|'.join(d['features'][k] for k in indices),'mass_mean':mass.mean(),'mass_sd':mass.std(ddof=1),'mass_cv':mass.std(ddof=1)/max(mass.mean(),1e-6),'mean_individual_cv':cv[indices].mean()})
        pd.DataFrame(clusterrows).to_csv(OUT/'correlated_cluster_stability.csv',index=False)
    print('summarized',len(paths),'outer-fold target fits',flush=True)

def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['prepare','tune','fit','bootstrap','permutation','summarize','all'],default='all');p.add_argument('--workers',type=int,default=3);p.add_argument('--limit',type=int);p.add_argument('--bootstrap-replicates',type=int,default=50);args=p.parse_args()
    if args.phase in ['prepare','all']:prepare()
    if args.phase in ['tune','all']:tune(args.workers)
    if args.phase in ['fit','all']:fit_all(args.workers,args.limit)
    if args.phase in ['bootstrap','all']:bootstrap(args.workers,args.bootstrap_replicates)
    if args.phase in ['permutation','all']:permutation()
    if args.phase in ['summarize','all']:summarize()
if __name__=='__main__':main()
