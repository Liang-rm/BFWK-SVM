"""Auditable revision implementation; original benchmark drivers are unchanged.

New experiments default to epsilon_K=1e-6 (absolute, unit-diagonal Gaussian
kernel). This is a NEW default, not a reconstruction of a historical setting.
SVC trains on K+epsilon_K*I; the returned dual value and intercept use that same
matrix. New test records use the base cross-kernel, with no cross-nugget.

Raw: J=V_epsilon+R(lambda,rho,tau).
Normalized: J_N=V_epsilon/n+R(lambda_N,rho_N,tau_N), actually optimized.
Equivalence to J/n requires normalized coefficients = raw coefficients/n.
At equal numerical coefficients the two objectives are different models.
"""
from __future__ import annotations
import time
import numpy as np
from sklearn.svm import SVC
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score, matthews_corrcoef

DEFAULT_JITTER = 1e-6
CORE_VERSION = "revision-20261020-fixed-jitter-1"


def project_simplex(v):
    v = np.asarray(v, dtype=float)
    u = np.sort(v)[::-1]
    cssv = np.cumsum(u)-1
    indices = np.arange(1, len(v)+1)
    valid = u-cssv/indices > 0
    threshold = cssv[np.flatnonzero(valid)[-1]]/indices[np.flatnonzero(valid)[-1]]
    result = np.maximum(v-threshold, 0)
    return result/result.sum()


def compute_q_M(X, y, eps=1e-10):
    X = np.asarray(X, dtype=float); y = np.asarray(y, dtype=float)
    Xc = X-X.mean(axis=0); yc = y-y.mean()
    energy = np.sum(Xc*Xc, axis=0)
    q = (Xc.T@yc)**2/(energy*np.sum(yc*yc)+eps)
    q = np.maximum(q, 0)
    q = q/q.sum() if q.sum()>eps else np.full(X.shape[1], 1/X.shape[1])
    normalized = Xc/np.sqrt(energy+eps)
    corr = normalized.T@normalized
    M = corr*corr  # PSD by the Schur product theorem in exact arithmetic.
    return q, (M+M.T)/2


def weighted_kernel(X1, X2, alpha, gamma):
    sw = np.sqrt(np.maximum(np.asarray(alpha), 0))
    A = np.asarray(X1)*sw; B = np.asarray(X2)*sw
    D2 = np.sum(A*A, axis=1)[:,None]+np.sum(B*B, axis=1)[None,:]-2*A@B.T
    np.maximum(D2, 0, out=D2)
    return np.exp(-float(gamma)*D2)


def regularizer(alpha, q, M, lam, rho, tau):
    return float(.5*lam*(alpha@alpha)+.5*rho*(alpha@M@alpha)-tau*(q@alpha))


def regularizer_grad(alpha, q, M, lam, rho, tau):
    return lam*alpha+rho*(M@alpha)-tau*q


def normalized_coefficients(raw_coefficients, n):
    return tuple(float(v)/n for v in raw_coefficients)


def raw_coefficients(normalized_values, n):
    return tuple(float(v)*n for v in normalized_values)


def class_box_limits(y, C):
    y = np.asarray(y)
    return np.asarray([C*len(y)/(2*np.sum(y==label)) for label in y])


def fit_precomputed_svc(K, y, C, jitter=DEFAULT_JITTER, tol=1e-5, max_iter=50000):
    if jitter<=0 or C<=0:
        raise ValueError("C and fixed jitter must be strictly positive")
    Ktrain = np.array(K, dtype=float, copy=True)
    Ktrain.flat[::len(Ktrain)+1] += jitter
    clf = SVC(C=C, kernel="precomputed", class_weight="balanced", tol=tol,
              max_iter=max_iter, cache_size=256, shrinking=True)
    clf.fit(Ktrain, y)
    u = np.zeros(len(y)); u[clf.support_] = clf.dual_coef_.ravel()
    beta = np.abs(u)
    value = float(beta.sum()-.5*u@Ktrain@u)
    return clf, u, value


def kernel_value_gradient(X, u, K, gamma):
    A = (u[:,None]*u[None,:])*K
    return gamma*((X*X).T@A.sum(axis=1)-np.sum(X*(A@X), axis=0))


def _evaluate(X, y, alpha, C, gamma, q, M, lam, rho, tau, objective, jitter, svc_tol, svc_max_iter):
    K = weighted_kernel(X, X, alpha, gamma)
    clf, u, V = fit_precomputed_svc(K, y, C, jitter, svc_tol, svc_max_iter)
    scale = 1/len(y) if objective=="normalized" else 1.
    R = regularizer(alpha, q, M, lam, rho, tau)
    g = scale*kernel_value_gradient(X, u, K, gamma)+regularizer_grad(alpha,q,M,lam,rho,tau)
    return {"K":K,"clf":clf,"u":u,"V":V,"R":R,"J":scale*V+R,"g":g}


def fit_bfwk(X, y, C, gamma, lam=.08, rho=.18, tau=.35,
             objective="normalized", jitter=DEFAULT_JITTER, max_outer=12,
             eta=1., sigma=1e-4, zeta=.5, min_step=2**-12,
             eps_alpha=1e-4, eps_J=1e-7, svc_tol=1e-5,
             svc_max_iter=50000, q_M=None, **unused):
    """Capped projected gradient with Armijo; a cap is not convergence.

    Every trial recomputes the exact specified SVM optimization (up to svc_tol).
    history records the pre-step objective/residual and accepted step. Final
    projected_gradient_residual always refers to returned alpha.
    """
    X=np.asarray(X, dtype=float); y=np.asarray(y, dtype=int)
    if set(np.unique(y))!={-1,1}: raise ValueError("binary labels -1/+1 required")
    if objective not in ("raw","normalized"): raise ValueError("unknown objective")
    if min(lam,rho,tau)<0: raise ValueError("regularization coefficients must be nonnegative")
    if gamma<=0: raise ValueError("gamma must be positive")
    q,M=compute_q_M(X,y) if q_M is None else q_M
    a=np.full(X.shape[1],1/X.shape[1]); history=[]; evaluations=0
    termination="outer_iteration_cap"; started=time.perf_counter()
    ev=_evaluate(X,y,a,C,gamma,q,M,lam,rho,tau,objective,jitter,svc_tol,svc_max_iter); evaluations+=1
    inner_failure = bool(ev["clf"].fit_status_)
    for t in range(max_outer):
        g=ev["g"]; residual=float(np.linalg.norm(a-project_simplex(a-g)))
        p=project_simplex(a-eta*g)-a
        if residual<=eps_alpha:
            history.append({"iteration":t,"objective":ev["J"],"residual":residual,"step":0.})
            termination="projected_gradient_tolerance"; break
        directional=float(g@p); step=1.; accepted=False
        while step>=min_step:
            proposal=a+step*p
            nxt=_evaluate(X,y,proposal,C,gamma,q,M,lam,rho,tau,objective,jitter,svc_tol,svc_max_iter);evaluations+=1
            inner_failure |= bool(nxt["clf"].fit_status_)
            if nxt["J"]<=ev["J"]+sigma*step*directional+1e-10:
                accepted=True;break
            step*=zeta
        history.append({"iteration":t,"objective":ev["J"],"residual":residual,"step":step if accepted else 0.})
        if not accepted:
            termination="line_search_failed";break
        change=abs(nxt["J"]-ev["J"])/(1+abs(ev["J"]))
        a=proposal;ev=nxt
        if change<=eps_J:
            termination="relative_objective_tolerance";break
    final_residual=float(np.linalg.norm(a-project_simplex(a-ev["g"])))
    margins=y*(ev["K"]@ev["u"]+jitter*ev["u"]+float(ev["clf"].intercept_[0]))
    boxes=class_box_limits(y,C);beta=np.abs(ev["u"])
    free=(beta>1e-6)&(beta<boxes-1e-6)
    kkt_error=float(np.max(np.abs(margins[free]-1))) if np.any(free) else float("nan")
    return {"X":X,"y":y,"alpha":a,"gamma":gamma,"C":C,"q":q,"M":M,
            "clf":ev["clf"],"u":ev["u"],"beta":beta,"intercept":float(ev["clf"].intercept_[0]),
            "jitter":jitter,"objective":ev["J"],"objective_convention":objective,
            "dual_value":ev["V"],"regularizer":ev["R"],
            "equivalent_raw_objective":len(y)*ev["J"] if objective=="normalized" else ev["J"],
            "history":history,"termination":termination,"evaluations":evaluations,
            "projected_gradient_residual":final_residual,"dual_fit_status":int(inner_failure),
            "dual_equality_residual":float(abs(ev["u"].sum())),"free_sv_kkt_error":kkt_error,
            "seconds":time.perf_counter()-started,"n_support":int(len(ev["clf"].support_)),
            "coefficients":(lam,rho,tau),"core_version":CORE_VERSION}


def fit_bfwk_normalized(*args, **kwargs):
    kwargs["objective"]="normalized"
    return fit_bfwk(*args,**kwargs)


def fit_fixed_weight(X,y,C,gamma,alpha,jitter=DEFAULT_JITTER,svc_tol=1e-5):
    X=np.asarray(X,dtype=float);y=np.asarray(y)
    K=weighted_kernel(X,X,alpha,gamma)
    clf,u,V=fit_precomputed_svc(K,y,C,jitter,svc_tol)
    return {"X":X,"y":y,"alpha":np.asarray(alpha),"gamma":gamma,"C":C,
            "jitter":jitter,"clf":clf,"u":u,"beta":np.abs(u),"dual_value":V,
            "intercept":float(clf.intercept_[0]),"dual_fit_status":int(clf.fit_status_)}


def predict_kernel(model, Xtest, training_records=False):
    K=weighted_kernel(Xtest,model["X"],model["alpha"],model["gamma"])
    if training_records:
        if np.shape(Xtest)!=np.shape(model["X"]) or not np.array_equal(Xtest,model["X"]):
            raise ValueError("training_records=True requires training rows in original order")
        K.flat[::len(K)+1]+=model["jitter"]
    return model["clf"].decision_function(K)


def two_stage_alpha(q,M,lam=.08,rho=.18,tau=.35,max_iter=300,tol=1e-8):
    a=np.full(len(q),1/len(q));L=lam+rho*np.linalg.norm(M,2)
    step=1/max(L,1e-8)
    for _ in range(max_iter):
        nxt=project_simplex(a-step*regularizer_grad(a,q,M,lam,rho,tau))
        if np.linalg.norm(nxt-a)<=tol: return nxt
        a=nxt
    return a


def metrics(y,score):
    pred=np.where(np.asarray(score)>=0,1,-1)
    return {"BalancedAccuracy":float(balanced_accuracy_score(y,pred)),
            "Accuracy":float(np.mean(pred==y)),"MacroF1":float(f1_score(y,pred,average="macro")),
            "AUROC":float(roc_auc_score(np.asarray(y)==1,score)),"MCC":float(matthews_corrcoef(y,pred))}
