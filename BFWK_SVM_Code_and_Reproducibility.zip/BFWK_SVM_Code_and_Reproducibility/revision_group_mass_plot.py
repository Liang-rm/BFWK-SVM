"""Redraw the original Table 17 values with an accurate aggregate-mass axis.

This is a presentation correction, not a new bootstrap analysis. The original
PNG and all five masses and reported interval endpoints remain unchanged.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parent/'results_revision'
groups=['Timing','Phrasing','Dynamics','Articulation','Timbre']
mass=np.array([0.286,0.238,0.195,0.163,0.118])
lo=np.array([0.253,0.207,0.169,0.139,0.097])
hi=np.array([0.319,0.270,0.222,0.188,0.141])
plt.rcParams.update({'font.size':13,'axes.labelsize':14,'xtick.labelsize':12,'ytick.labelsize':13,'pdf.fonttype':42,'ps.fonttype':42})
fig,ax=plt.subplots(figsize=(8.4,4.4))
y=np.arange(len(groups))
ax.barh(y,mass,color='#2769a8',height=.61,zorder=2)
ax.errorbar(mass,y,xerr=np.vstack([mass-lo,hi-mass]),fmt='none',ecolor='#222222',elinewidth=1.3,capsize=4,zorder=3)
ax.set_yticks(y,groups)
ax.invert_yaxis()
ax.set_xlim(0,.36)
ax.set_xlabel('Aggregate group-weight mass')
ax.set_xticks(np.arange(0,.36,.05))
ax.grid(axis='x',color='#dddddd',linewidth=.6,zorder=0)
ax.spines[['top','right']].set_visible(False)
for yi,m,h in zip(y,mass,hi):
    ax.text(h+.006,yi,f'{m:.3f}',va='center',fontsize=12)
fig.tight_layout(pad=1)
fig.savefig(OUT/'group_weight_mass.pdf',bbox_inches='tight')
fig.savefig(OUT/'group_weight_mass.png',dpi=220,bbox_inches='tight')
plt.close(fig)
(OUT/'group_weight_mass_source.json').write_text(json.dumps({'source':'Original submitted Table 17; presentation-only redraw','groups':groups,'mass':mass.tolist(),'reported_interval_lower':lo.tolist(),'reported_interval_upper':hi.tolist(),'new_estimation':False},indent=2),encoding='utf-8')
print('Redrawn original aggregate masses with corrected axis; no values changed.')
