#!/usr/bin/env python3
"""Publication-size replot only: read final CSVs; never fit or alter results.

Regenerates the four six-task profile/learning figures and the 13-task
property scatter figure with fonts readable at approximately 7-in print width.
"""
from pathlib import Path
import hashlib
import json
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

BASE=Path(__file__).resolve().parent
OUT=BASE/'results_revision'
NAMES=['WDBC','Wine-01','Iris-12','Digits-35','Spector','ANES96']
METHODS=[('BFWK-SVM-N-jitter','BFWK-N','#b2182b','o'),
         ('RBF-SVM-jitter','RBF','#2166ac','s')]
STYLE={0.:'-',.5:'--',1.:':'}
CSV_FILES=['stress6_summary.csv','learning6_summary.csv',
           'original13_dataset_properties_and_gains.csv','original13_property_correlations.csv']

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12.5,
    'axes.labelsize':12.5,'axes.titlesize':14,'xtick.labelsize':11.5,
    'ytick.labelsize':11.5,'legend.fontsize':11.5,'figure.titlesize':15,
    'pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.8,
    'savefig.facecolor':'white','figure.facecolor':'white'})


def hashes():
    return {f:hashlib.sha256((OUT/f).read_bytes()).hexdigest() for f in CSV_FILES}


def save(fig,stem):
    fig.savefig(OUT/f'{stem}.pdf')
    fig.savefig(OUT/f'{stem}.png',dpi=200)
    plt.close(fig)


def stress_figures():
    df=pd.read_csv(OUT/'stress6_summary.csv')
    assert len(df)==144
    for metric in ['BalancedAccuracy','Accuracy']:
        fig,axes=plt.subplots(3,2,figsize=(9,9),sharey=True)
        fig.subplots_adjust(left=.105,right=.985,top=.925,bottom=.19,wspace=.30,hspace=.58)
        for ax,name in zip(axes.flat,NAMES):
            one=df[df.dataset==name]
            for noise,style in STYLE.items():
                for method,short,color,marker in METHODS:
                    part=one[(one.noise_fraction==noise)&(one.method==method)].sort_values('duplicate_fraction')
                    ax.plot(part.duplicate_fraction,part[f'{metric}_mean'],linestyle=style,
                            color=color,marker=marker,markersize=4,linewidth=1.7,
                            markerfacecolor='white' if noise==.5 else color,
                            markeredgewidth=1.)
            ax.set_title(name,pad=5)
            ax.set_xlabel('Noisy copies / base feature count',labelpad=4)
            ax.set_ylabel('Balanced accuracy' if metric=='BalancedAccuracy' else 'Accuracy',labelpad=5)
            ax.set_xticks([0,.5,1,2]); ax.set_xlim(-.06,2.06)
            ax.tick_params(labelleft=True)
            ax.grid(alpha=.22,linewidth=.65)
        method_handles=[Line2D([],[],color=c,marker=m,linewidth=1.8,label=s) for _,s,c,m in METHODS]
        noise_handles=[Line2D([],[],color='0.25',linestyle=sty,linewidth=1.8,label=f'Noise / base d = {noise:g}')
                       for noise,sty in STYLE.items()]
        fig.legend(handles=method_handles,loc='lower center',bbox_to_anchor=(.5,.079),
                   ncol=2,frameon=False,columnspacing=3.,handlelength=2.5)
        fig.legend(handles=noise_handles,loc='lower center',bbox_to_anchor=(.5,.034),
                   ncol=3,frameon=False,columnspacing=1.6,handlelength=2.5,fontsize=10.5)
        fig.text(.5,.015,'Three-fold means; noise severity is the appended independent-noise dimension / base d.',
                 ha='center',fontsize=9.5)
        fig.suptitle('Six-task redundancy and noise profiles',y=.983)
        save(fig,f'stress6_{metric}')


def learning_figures():
    df=pd.read_csv(OUT/'learning6_summary.csv')
    assert len(df)==48
    for metric in ['BalancedAccuracy','Accuracy']:
        fig,axes=plt.subplots(3,2,figsize=(9,9),sharey=True)
        fig.subplots_adjust(left=.105,right=.985,top=.90,bottom=.18,wspace=.30,hspace=.57)
        for ax,name in zip(axes.flat,NAMES):
            one=df[df.dataset==name]
            for method,short,color,marker in METHODS:
                part=one[one.method==method].sort_values('train_fraction')
                ax.errorbar(part.train_fraction,part[f'{metric}_mean'],yerr=part[f'{metric}_sd'],
                    color=color,marker=marker,markersize=4,linewidth=1.7,elinewidth=1.1,
                    capsize=3,capthick=1.1,label=short)
            ax.set_title(name,pad=5)
            ax.set_xlabel('Outer training fraction (nominal)',labelpad=4)
            ax.set_ylabel('Balanced accuracy' if metric=='BalancedAccuracy' else 'Accuracy',labelpad=5)
            ax.set_xticks([.25,.5,.75,1.]); ax.set_xlim(.22,1.03)
            ax.tick_params(labelleft=True)
            ax.grid(alpha=.22,linewidth=.65)
        handles,labels=axes.flat[0].get_legend_handles_labels()
        fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.5,.055),ncol=2,
                   frameon=False,columnspacing=3.,handlelength=2.5)
        fig.text(.5,.016,'Error bars: descriptive standard deviation across three folds.',ha='center',fontsize=10.5)
        fig.suptitle('Six-task training-size learning curves\nCopies / base d = 1; noise / base d = 1',y=.983,linespacing=1.35)
        save(fig,f'learning6_{metric}')


def property_figure():
    df=pd.read_csv(OUT/'original13_dataset_properties_and_gains.csv')
    stats=pd.read_csv(OUT/'original13_property_correlations.csv').set_index('property')
    properties=[('log10_N',r'$\log_{10}(n)$'),('RawFeatures','Raw feature count d'),
                ('raw_d_over_n','Raw feature / sample ratio d/n'),('imbalance','Class imbalance (0 = balanced)')]
    assert len(df)==13
    fig,axes=plt.subplots(2,2,figsize=(9,8))
    fig.subplots_adjust(left=.11,right=.985,top=.89,bottom=.20,wspace=.33,hspace=.38)
    for ax,(prop,label) in zip(axes.flat,properties):
        stat=stats.loc[prop]
        ax.scatter(df[prop],100*df.BA_gain,color='#2166ac',s=42,edgecolors='white',linewidths=.4)
        ax.axhline(0,color='0.55',lw=.8)
        ax.set_xlabel(label,labelpad=5)
        ax.set_ylabel('BFWK - RBF BA gain (pp)',labelpad=5)
        ax.set_title(f"rho = {stat.Spearman_rho:.2f}; Holm p = {stat.Holm_p_within_cohort:.3f}",fontsize=12.5,pad=7)
        ax.grid(alpha=.15,linewidth=.6)
        ax.tick_params(labelsize=11.5)
    fig.suptitle('Original 13 tasks: exploratory property associations',y=.969)
    fig.text(.5,.035,'One point per dataset; paired five-fold mean gains.\nDataset identities and exact values are in the accompanying CSV.',
             ha='center',fontsize=11,linespacing=1.4)
    save(fig,'original13_property_correlations')


def main():
    before=hashes()
    stress_figures(); learning_figures(); property_figure()
    assert before==hashes(),'Plot-only utility must not change any numerical CSV'
    summary=dict(plot_only=True,scientific_model_fits=0,csv_hashes_unchanged=before,
        six_task_dimensions_inches=[9,9],property_dimensions_inches=[9,8],
        six_task_panels='3 rows x 2 columns',base_font_pt=12.5,tick_font_pt=11.5,
        panel_title_font_pt=14,expected_fonts_at_7in_width=dict(body=12.5*7/9,ticks=11.5*7/9),
        output_png_dpi=200,
        filenames=['stress6_BalancedAccuracy','stress6_Accuracy','learning6_BalancedAccuracy',
                   'learning6_Accuracy','original13_property_correlations'])
    (OUT/'publication_plot_qa.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    main()
