"""Computational-only synthetic scaling measurements, NOT accuracy evidence.

Nine exact dense-kernel fits: n=250/500/1000, d=16/64/256. Each fit runs in a
fresh child process, with the same20-iteration cap and one BLAS thread. The
Gaussian classification data are synthetic and explicitly identified as such.
Process RSS is sampled every2ms; its sampled peak can miss shorter allocations.
It is not a hardware-independent feasible-size upper bound.
"""
import argparse, json, os, platform, subprocess, sys, threading, time
from pathlib import Path

BASE=Path(__file__).resolve().parent
OUT=BASE/"results_revision"


def worker(n,d,repeat):
    import numpy as np
    import psutil
    from sklearn.datasets import make_classification
    from sklearn.preprocessing import StandardScaler
    from threadpoolctl import threadpool_limits
    import revision_core as core
    X,y=make_classification(n_samples=n,n_features=d,n_informative=min(8,d),n_redundant=0,
                            n_repeated=0,n_clusters_per_class=2,class_sep=1.,random_state=20261020+repeat)
    X=StandardScaler().fit_transform(X);y=np.where(y==1,1,-1)
    proc=psutil.Process();baseline=proc.memory_info().rss;rss=[baseline];stop=threading.Event()
    def sampler():
        while not stop.is_set():
            rss.append(proc.memory_info().rss);stop.wait(.002)
    thread=threading.Thread(target=sampler,daemon=True);thread.start()
    with threadpool_limits(limits=1):
        t=time.perf_counter();model=core.fit_bfwk(X,y,4.,.1,.08,.18,.35,max_outer=20);elapsed=time.perf_counter()-t
    rss.append(proc.memory_info().rss);stop.set();thread.join()
    print(json.dumps({"n":n,"d":d,"repeat":repeat,"data":"synthetic make_classification; computational only",
                      "elapsed_seconds":elapsed,"baseline_process_RSS_bytes":baseline,"sampled_peak_process_RSS_bytes":max(rss),
                      "sampled_peak_increment_bytes":max(rss)-baseline,"RSS_sampling_ms":2,"outer_cap":20,
                      "outer_iterations":len(model["history"]),"evaluations":model["evaluations"],
                      "termination":model["termination"],"final_residual":model["projected_gradient_residual"],
                      "any_inner_cap":model["dual_fit_status"],"n_support":model["n_support"]}))


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--worker",action="store_true");parser.add_argument("--n",type=int);parser.add_argument("--d",type=int);parser.add_argument("--repeat",type=int,default=1);args=parser.parse_args()
    if args.worker:return worker(args.n,args.d,args.repeat)
    import numpy as np,pandas as pd,psutil,sklearn
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    OUT.mkdir(exist_ok=True);rows=[]
    for n in (250,500,1000):
        for d in (16,64,256):
            env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
            result=subprocess.run([sys.executable,"-X","utf8",str(Path(__file__).resolve()),"--worker","--n",str(n),"--d",str(d)],
                                  capture_output=True,text=True,encoding="utf-8",env=env,check=True)
            row=json.loads(result.stdout.strip().splitlines()[-1]);rows.append(row);print("SCALING",row,flush=True)
            pd.DataFrame(rows).to_csv(OUT/"computational_scaling_synthetic.csv",index=False)
    hardware={"platform":platform.platform(),"processor":platform.processor(),"machine":platform.machine(),
              "physical_CPU_cores":psutil.cpu_count(logical=False),"logical_CPU_cores":psutil.cpu_count(logical=True),
              "system_RAM_bytes":psutil.virtual_memory().total,"python":sys.version,"numpy":np.__version__,"sklearn":sklearn.__version__,
              "BLAS_threads":1,"fresh_process_per_case":True,"repetitions_per_case":1,"RSS_sampling_ms":2,
              "scope":"Synthetic computational-only measurements with outercap20; not predictive results or a practical maximum n,d"}
    (OUT/"computational_scaling_hardware.json").write_text(json.dumps(hardware,indent=2),encoding="utf-8")
    df=pd.DataFrame(rows);fig,axs=plt.subplots(1,2,figsize=(9,3.5))
    for d,g in df.groupby("d"):
        axs[0].plot(g.n,g.elapsed_seconds,"o-",label=f"d={d}")
        axs[1].plot(g.n,g.sampled_peak_process_RSS_bytes/2**20,"o-",label=f"d={d}")
    axs[0].set_ylabel("Seconds per capped fit");axs[1].set_ylabel("Sampled peak process RSS (MiB)")
    for ax in axs:ax.set_xlabel("Training n");ax.legend();ax.grid(alpha=.2)
    fig.suptitle("Synthetic computational diagnostic: exact dense kernels, outer cap20; one run per case")
    fig.tight_layout();fig.savefig(OUT/"computational_scaling_synthetic.png",dpi=180);fig.savefig(OUT/"computational_scaling_synthetic.pdf");plt.close(fig)


if __name__=="__main__":main()
