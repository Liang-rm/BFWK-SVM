#!/usr/bin/env python3
"""Public benchmark evaluation for BFWK-SVM.

The BFWK-SVM implementation follows BFWK_SVM_complete_demo_fixed.R:
- simplex-constrained nonnegative feature weights;
- normalized squared feature-label association q;
- squared-correlation redundancy matrix M;
- feature-weighted Gaussian kernel;
- SVM value-function outer objective;
- projected-gradient update with Armijo backtracking.

The lower SVM is solved by scikit-learn/libsvm for speed. Public datasets are
loaded from scikit-learn, statsmodels, and OpenML. Bundled OpenML snapshots are
used when available; otherwise the same data_id is fetched from OpenML.
"""
from __future__ import annotations

import csv
import argparse
import gzip
import json
import math
import os
import re
import shlex
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.compose import ColumnTransformer
from sklearn.datasets import load_breast_cancer, load_digits, load_iris, load_wine, fetch_openml
from sklearn.impute import SimpleImputer
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score, matthews_corrcoef
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.svm import SVC, LinearSVC
import statsmodels.api as sm
import sklearn

SEED = 2026
OUT = Path(__file__).resolve().parent / "benchmark_results"
OUT.mkdir(exist_ok=True)
OPENML_BASE = Path(sklearn.__file__).resolve().parent / "datasets" / "tests" / "data" / "openml"


@dataclass
class Dataset:
    name: str
    X: pd.DataFrame
    y: np.ndarray
    source: str
    note: str = ""


def _decode(v):
    if isinstance(v, bytes):
        return v.decode("utf-8", errors="replace")
    return v


def parse_arff_gz(path: Path) -> pd.DataFrame:
    """Small ARFF reader supporting numeric, nominal and string columns."""
    attributes = []
    data_lines = []
    in_data = False
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("%"):
                continue
            low = line.lower()
            if low.startswith("@attribute"):
                rest = line[len("@attribute"):].strip()
                # Attribute names may be quoted.
                if rest[0] in "'\"":
                    q = rest[0]
                    end = 1
                    while end < len(rest) and rest[end] != q:
                        end += 1
                    name = rest[1:end]
                    typ = rest[end+1:].strip()
                else:
                    parts = rest.split(None, 1)
                    name = parts[0]
                    typ = parts[1] if len(parts) > 1 else "string"
                attributes.append((name, typ))
            elif low == "@data":
                in_data = True
            elif in_data:
                data_lines.append(line)

    names = [a[0] for a in attributes]
    rows = []
    for line in data_lines:
        if line.startswith("{"):
            # Sparse ARFF.
            row = [0] * len(names)
            body = line.strip()[1:-1].strip()
            if body:
                for item in next(csv.reader([body], skipinitialspace=True)):
                    idx_s, val = item.strip().split(None, 1)
                    row[int(idx_s)] = val.strip().strip("'\"")
        else:
            row = next(csv.reader([line], skipinitialspace=True))
        if len(row) != len(names):
            raise ValueError(f"ARFF row length mismatch in {path}: {len(row)} vs {len(names)}")
        rows.append(row)

    df = pd.DataFrame(rows, columns=names)
    for name, typ in attributes:
        s = df[name].replace("?", np.nan)
        tl = typ.lower()
        if any(k in tl for k in ["numeric", "real", "integer"]):
            df[name] = pd.to_numeric(s, errors="coerce")
        else:
            df[name] = s.astype("object")
    return df


def load_openml_snapshot(id_: int, target: str, drop: List[str] | None = None) -> pd.DataFrame:
    """Load a bundled OpenML snapshot when available, otherwise fetch by data_id."""
    folder = OPENML_BASE / f"id_{id_}"
    files = list(folder.glob("*.arff.gz")) if folder.exists() else []
    if files:
        df = parse_arff_gz(files[0])
    else:
        bunch = fetch_openml(data_id=id_, as_frame=True, parser="auto")
        df = bunch.frame.copy()
        if target not in df.columns:
            df[target] = bunch.target
    if drop:
        for c in drop:
            if c in df:
                df = df.drop(columns=c)
    return df


def make_datasets() -> List[Dataset]:
    ds: List[Dataset] = []

    # 1. WDBC
    b = load_breast_cancer(as_frame=True)
    ds.append(Dataset("WDBC", b.data.copy(), np.where(b.target.to_numpy() == 1, 1, -1),
                      "UCI / scikit-learn", "Diagnostic breast cancer"))

    # 2. Wine: classes 0 vs 1 (standard binary restriction of multiclass data)
    w = load_wine(as_frame=True)
    m = w.target.isin([0, 1])
    ds.append(Dataset("Wine-01", w.data.loc[m].reset_index(drop=True),
                      np.where(w.target.loc[m].to_numpy() == 1, 1, -1),
                      "UCI / scikit-learn", "Wine classes 0 vs 1"))

    # 3. Iris: versicolor vs virginica
    ir = load_iris(as_frame=True)
    m = ir.target.isin([1, 2])
    ds.append(Dataset("Iris-12", ir.data.loc[m].reset_index(drop=True),
                      np.where(ir.target.loc[m].to_numpy() == 2, 1, -1),
                      "UCI / scikit-learn", "Versicolor vs virginica"))

    # 4. Digits: 3 vs 5
    dg = load_digits(as_frame=True)
    m = dg.target.isin([3, 5])
    ds.append(Dataset("Digits-35", dg.data.loc[m].reset_index(drop=True),
                      np.where(dg.target.loc[m].to_numpy() == 5, 1, -1),
                      "UCI-derived / scikit-learn", "Digits 3 vs 5"))

    # 5. Chess KR-vs-KP (categorical binary)
    ch = load_openml_snapshot(3, "class")
    y = ch.pop("class").astype(str)
    ds.append(Dataset("KR-vs-KP", ch, np.where(y.str.contains("won", case=False), 1, -1),
                      "OpenML 3", "Chess king-rook vs king-pawn"))

    # 6. Glass2 (already binary in OpenML snapshot)
    gl = load_openml_snapshot(40675, "class")
    y = gl.pop("class").astype(str)
    ds.append(Dataset("Glass2", gl, np.where(y == "1", 1, -1),
                      "OpenML 40675", "Binary glass task"))

    # 7. Titanic. Drop direct/post-outcome leakage and high-cardinality identifiers.
    ti = load_openml_snapshot(40945, "survived")
    y = pd.to_numeric(ti.pop("survived"), errors="coerce")
    keep = [c for c in ["pclass", "sex", "age", "sibsp", "parch", "fare", "embarked"] if c in ti.columns]
    ti = ti[keep]
    valid = y.notna()
    ds.append(Dataset("Titanic", ti.loc[valid].reset_index(drop=True),
                      np.where(y.loc[valid].to_numpy() > 0, 1, -1),
                      "OpenML 40945", "Leakage-prone post-outcome fields excluded"))

    # 8. Penguins: Adelie vs Gentoo, using physical/island/sex predictors.
    pg = load_openml_snapshot(42585, "species")
    y = pg.pop("species").astype(str)
    m = y.str.contains("Adelie|Gentoo", regex=True, na=False)
    keep = [c for c in pg.columns if c not in []]
    ds.append(Dataset("Penguins-AG", pg.loc[m, keep].reset_index(drop=True),
                      np.where(y.loc[m].str.contains("Gentoo").to_numpy(), 1, -1),
                      "OpenML 42585", "Adelie vs Gentoo"))

    # 9. Zoo: mammal (type 1) vs non-mammal. Drop animal identifier.
    zo = load_openml_snapshot(62, "type", drop=["animal"])
    y = zo.pop("type").astype(str)
    valid = y.notna()
    ds.append(Dataset("Zoo-mammal", zo.loc[valid].reset_index(drop=True),
                      np.where(y.loc[valid].str.lower().to_numpy() == "mammal", 1, -1),
                      "OpenML 62", "Mammal vs non-mammal"))

    # 10. Spector education binary data.
    sp = sm.datasets.spector.load_pandas()
    ds.append(Dataset("Spector", sp.exog.reset_index(drop=True),
                      np.where(sp.endog.to_numpy() > 0, 1, -1),
                      "statsmodels Spector", "Binary grade outcome"))

    # 11. ModeChoice natural binary choice data.
    mc = sm.datasets.modechoice.load_pandas()
    ds.append(Dataset("ModeChoice", mc.exog.reset_index(drop=True),
                      np.where(mc.endog.to_numpy() > 0, 1, -1),
                      "statsmodels ModeChoice", "Travel-mode choice"))

    # 12. Fair affairs: occurrence vs no occurrence.
    fa = sm.datasets.fair.load_pandas()
    ds.append(Dataset("Fair-Affair", fa.exog.reset_index(drop=True),
                      np.where(fa.endog.to_numpy() > 0, 1, -1),
                      "statsmodels Fair", "Any affair vs none"))

    # 13. ANES96: strong Democratic side (0-2) vs strong Republican side (4-6), drop centrists 3.
    an = sm.datasets.anes96.load_pandas()
    yy = an.endog.to_numpy()
    m = yy != 3
    ds.append(Dataset("ANES96", an.exog.loc[m].reset_index(drop=True),
                      np.where(yy[m] >= 4, 1, -1),
                      "statsmodels ANES96", "PID 0-2 vs 4-6; centrists excluded"))

    return ds


def stratified_subsample(X: pd.DataFrame, y: np.ndarray, max_n: int = 1000, seed: int = SEED):
    if len(y) <= max_n:
        return X.reset_index(drop=True), y.copy()
    rng = np.random.default_rng(seed)
    idxs = []
    for cls in [-1, 1]:
        ids = np.flatnonzero(y == cls)
        n_take = int(round(max_n * len(ids) / len(y)))
        n_take = min(n_take, len(ids))
        idxs.extend(rng.choice(ids, size=n_take, replace=False).tolist())
    # adjust exact size
    idxs = np.array(sorted(set(idxs)))
    if len(idxs) > max_n:
        idxs = rng.choice(idxs, size=max_n, replace=False)
    elif len(idxs) < max_n:
        remain = np.setdiff1d(np.arange(len(y)), idxs)
        add = rng.choice(remain, size=max_n-len(idxs), replace=False)
        idxs = np.r_[idxs, add]
    rng.shuffle(idxs)
    return X.iloc[idxs].reset_index(drop=True), y[idxs]


def make_preprocessor(X: pd.DataFrame):
    num_cols = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c])]
    cat_cols = [c for c in X.columns if c not in num_cols]
    transformers = []
    if num_cols:
        transformers.append(("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
        ]), num_cols))
    if cat_cols:
        transformers.append(("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]), cat_cols))
    pre = Pipeline([
        ("columns", ColumnTransformer(transformers, remainder="drop", sparse_threshold=0.0)),
        ("scale", StandardScaler()),
    ])
    return pre


def project_simplex(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, dtype=float)
    u = np.sort(v)[::-1]
    cssv = np.cumsum(u) - 1.0
    ind = np.arange(1, len(v) + 1)
    cond = u - cssv / ind > 0
    if not np.any(cond):
        return np.full_like(v, 1.0 / len(v))
    rho = ind[cond][-1]
    theta = cssv[rho - 1] / rho
    w = np.maximum(v - theta, 0.0)
    s = w.sum()
    return w / s if s > 0 else np.full_like(v, 1.0 / len(v))


def compute_q_M(X: np.ndarray, y: np.ndarray, eps: float = 1e-10):
    Xc = X - X.mean(axis=0, keepdims=True)
    yc = y - y.mean()
    x_energy = np.sum(Xc * Xc, axis=0)
    y_energy = np.sum(yc * yc)
    q = (Xc.T @ yc) ** 2 / (x_energy * y_energy + eps)
    q = np.maximum(q, 0)
    q = q / (q.sum() + eps) if q.sum() > eps else np.full(X.shape[1], 1 / X.shape[1])
    Xn = Xc / np.sqrt(x_energy + eps)
    M = Xn.T @ Xn
    M = M * M
    M = (M + M.T) / 2
    eigmin = np.linalg.eigvalsh(M).min()
    if eigmin < 0:
        M += (abs(eigmin) + 1e-10) * np.eye(M.shape[0])
    return q, M


def weighted_kernel(X1, X2, alpha, gamma):
    sw = np.sqrt(np.maximum(alpha, 0))
    A = X1 * sw
    B = X2 * sw
    D2 = np.sum(A*A, axis=1)[:, None] + np.sum(B*B, axis=1)[None, :] - 2 * A @ B.T
    np.maximum(D2, 0, out=D2)
    return np.exp(-gamma * D2)


def regularizer(alpha, q, M, lam, rho, tau):
    return 0.5 * lam * np.dot(alpha, alpha) + 0.5 * rho * alpha @ M @ alpha - tau * np.dot(q, alpha)


def regularizer_grad(alpha, q, M, lam, rho, tau):
    return lam * alpha + rho * (M @ alpha) - tau * q


def fit_precomputed_svc(K, y, C, tol=1e-5):
    clf = SVC(C=C, kernel="precomputed", class_weight="balanced", tol=tol, cache_size=1000)
    clf.fit(K, y)
    u = np.zeros(len(y), dtype=float)
    u[clf.support_] = clf.dual_coef_.ravel()  # signed beta_i y_i
    beta = np.abs(u)
    value = beta.sum() - 0.5 * (u @ K @ u)
    return clf, u, value


def outer_grad_fast(X, u, K, gamma, alpha, q, M, lam, rho, tau):
    # A_ij = u_i u_j K_ij. For each feature r:
    # 0.5 gamma sum_ij A_ij (x_ir-x_jr)^2
    A = (u[:, None] * u[None, :]) * K
    rows = A.sum(axis=1)
    term1 = (X * X).T @ rows
    AX = A @ X
    term2 = np.sum(X * AX, axis=0)
    kg = gamma * (term1 - term2)
    return kg + regularizer_grad(alpha, q, M, lam, rho, tau)


def fit_bfwk(X, y, C, gamma, lam=0.08, rho=0.18, tau=0.35,
             max_outer=8, eta=1.0, sigma=1e-4, zeta=0.5,
             min_step=1e-3, eps_alpha=1e-4, eps_J=1e-5):
    q, M = compute_q_M(X, y)
    d = X.shape[1]
    alpha = np.full(d, 1/d)
    history = []
    prev = None
    for t in range(max_outer):
        K = weighted_kernel(X, X, alpha, gamma)
        clf, u, V = fit_precomputed_svc(K, y, C)
        J = V + regularizer(alpha, q, M, lam, rho, tau)
        g = outer_grad_fast(X, u, K, gamma, alpha, q, M, lam, rho, tau)
        projected = project_simplex(alpha - eta * g)
        p = projected - alpha
        pnorm = np.linalg.norm(p)
        residual = np.linalg.norm(alpha - project_simplex(alpha - g))
        if pnorm <= eps_alpha:
            history.append((t, J, residual, 0.0))
            break
        directional = float(g @ p)
        step = 1.0
        accepted = False
        best = (clf, u, V, J, K)
        while step >= min_step:
            a2 = alpha + step * p
            K2 = weighted_kernel(X, X, a2, gamma)
            clf2, u2, V2 = fit_precomputed_svc(K2, y, C)
            J2 = V2 + regularizer(a2, q, M, lam, rho, tau)
            if J2 <= J + sigma * step * directional + 1e-8:
                accepted = True
                best = (clf2, u2, V2, J2, K2)
                break
            step *= zeta
        history.append((t, J, residual, step if accepted else 0.0))
        if not accepted:
            break
        a_new = alpha + step * p
        J_new = best[3]
        rel = abs(J_new - J) / (1 + abs(J))
        alpha = a_new
        if rel <= eps_J or (prev is not None and abs(J-prev)/(1+abs(prev)) <= eps_J):
            break
        prev = J

    K = weighted_kernel(X, X, alpha, gamma)
    clf, u, V = fit_precomputed_svc(K, y, C)
    return {"alpha": alpha, "clf": clf, "X": X, "gamma": gamma, "q": q, "M": M, "history": history,
            "objective": V + regularizer(alpha, q, M, lam, rho, tau)}


def two_stage_alpha(q, M, lam=0.08, rho=0.18, tau=0.35):
    a = np.full(len(q), 1/len(q))
    for _ in range(300):
        g = regularizer_grad(a, q, M, lam, rho, tau)
        a2 = project_simplex(a - 0.5*g)
        if np.linalg.norm(a2-a) <= 1e-8:
            a = a2; break
        a = a2
    return a


def mrmr_alpha(X, y, keep_fraction=0.5):
    q, M = compute_q_M(X, y)
    score = q - 0.25 * M.mean(axis=1)
    keep = max(1, math.ceil(X.shape[1]*keep_fraction))
    idx = np.argsort(score)[::-1][:keep]
    a = np.zeros(X.shape[1]); a[idx] = 1/keep
    return a


def fit_fixed_weight(X, y, C, gamma, alpha):
    K = weighted_kernel(X, X, alpha, gamma)
    clf, u, V = fit_precomputed_svc(K, y, C)
    return {"alpha": alpha, "clf": clf, "X": X, "gamma": gamma}


def predict_kernel(model, Xtest):
    K = weighted_kernel(Xtest, model["X"], model["alpha"], model["gamma"])
    return model["clf"].decision_function(K)


def metrics(y, score):
    pred = np.where(score >= 0, 1, -1)
    try: auc = roc_auc_score((y==1).astype(int), score)
    except Exception: auc = np.nan
    return {
        "BalancedAccuracy": balanced_accuracy_score(y, pred),
        "MacroF1": f1_score(y, pred, average="macro"),
        "AUROC": auc,
        "MCC": matthews_corrcoef(y, pred),
    }


def tune_C_gamma(Xdf, y, train_idx, seed):
    """Tune common kernel C/gamma on training only using ordinary uniform RBF SVM."""
    Xtrdf = Xdf.iloc[train_idx].reset_index(drop=True)
    ytr = y[train_idx]
    cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=seed)
    grid = [(C,g) for C in [1.0, 4.0, 16.0] for g in [0.04, 0.10, 0.25]]
    vals = []
    for C,gamma in grid:
        fs=[]
        for a,b in cv.split(Xtrdf, ytr):
            pre = make_preprocessor(Xtrdf.iloc[a])
            Xa = pre.fit_transform(Xtrdf.iloc[a])
            Xb = pre.transform(Xtrdf.iloc[b])
            # remove constant transformed columns
            keep = np.std(Xa,axis=0) > 1e-10
            Xa = Xa[:,keep]; Xb=Xb[:,keep]
            alpha=np.full(Xa.shape[1],1/Xa.shape[1])
            m=fit_fixed_weight(Xa,ytr[a],C,gamma,alpha)
            s=predict_kernel(m,Xb)
            fs.append(balanced_accuracy_score(ytr[b],np.where(s>=0,1,-1)))
        vals.append(np.mean(fs))
    best=int(np.argmax(vals))
    return grid[best], vals[best]


def augment_correlated_noise(Xtr, Xte, seed, redundant_fraction=0.5, noise_fraction=0.5):
    """Add a fixed proportion of correlated copies and pure noise features.

    The same source columns define redundant variables in train/test, while the
    pure-noise variables are independently sampled from N(0,1). The augmented
    columns are standardized using training statistics only.
    """
    rng=np.random.default_rng(seed)
    d=Xtr.shape[1]
    nr=max(2,int(round(d*redundant_fraction)))
    nn=max(2,int(round(d*noise_fraction)))
    src=rng.choice(d,size=nr,replace=True)
    red_tr=Xtr[:,src] + rng.normal(0,0.10,size=(Xtr.shape[0],nr))
    red_te=Xte[:,src] + rng.normal(0,0.10,size=(Xte.shape[0],nr))
    noi_tr=rng.normal(0,1,size=(Xtr.shape[0],nn))
    noi_te=rng.normal(0,1,size=(Xte.shape[0],nn))
    Atr=np.c_[Xtr,red_tr,noi_tr]
    Ate=np.c_[Xte,red_te,noi_te]
    mu=Atr.mean(axis=0); sd=Atr.std(axis=0); sd[sd<1e-10]=1
    return (Atr-mu)/sd,(Ate-mu)/sd,{'original_d':d,'redundant_d':nr,'noise_d':nn}


def evaluate_dataset_stress(ds: Dataset, max_n=1000, n_splits=5):
    Xdf,y = stratified_subsample(ds.X, ds.y, max_n=max_n, seed=SEED)
    min_class=min(np.sum(y==1),np.sum(y==-1)); k=min(n_splits,int(min_class))
    cv=StratifiedKFold(n_splits=k,shuffle=True,random_state=SEED)
    rows=[]; meta=[]
    for fold,(tr,te) in enumerate(cv.split(Xdf,y),1):
        # Hyperparameters are selected from the uncontaminated training data and
        # then frozen. This makes the stress test a robustness evaluation rather
        # than a second opportunity for re-tuning after artificial contamination.
        (C,gamma),inner_score=tune_C_gamma(Xdf,y,tr,SEED+fold)
        pre=make_preprocessor(Xdf.iloc[tr])
        Xtr=pre.fit_transform(Xdf.iloc[tr]); Xte=pre.transform(Xdf.iloc[te])
        keep=np.std(Xtr,axis=0)>1e-10; Xtr=Xtr[:,keep]; Xte=Xte[:,keep]
        Xtr,Xte,aug=augment_correlated_noise(Xtr,Xte,SEED+1000*fold)
        ytr=y[tr];yte=y[te]
        q,M=compute_q_M(Xtr,ytr)
        alphas={
            'RBF-SVM':np.full(Xtr.shape[1],1/Xtr.shape[1]),
            'Relevance-SVM':q/(q.sum()+1e-12),
            'mRMR-SVM':mrmr_alpha(Xtr,ytr),
            'Two-stage RR-SVM':two_stage_alpha(q,M),
        }
        lin=LinearSVC(C=C,class_weight='balanced',dual='auto',max_iter=10000).fit(Xtr,ytr)
        rr=metrics(yte,lin.decision_function(Xte));rr.update(dataset=ds.name,fold=fold,method='Linear SVM',C=C,gamma=gamma);rows.append(rr)
        for name,a in alphas.items():
            model=fit_fixed_weight(Xtr,ytr,C,gamma,a)
            rr=metrics(yte,predict_kernel(model,Xte));rr.update(dataset=ds.name,fold=fold,method=name,C=C,gamma=gamma);rows.append(rr)
        t0=time.time();bfwk=fit_bfwk(Xtr,ytr,C,gamma);elapsed=time.time()-t0
        rr=metrics(yte,predict_kernel(bfwk,Xte));rr.update(dataset=ds.name,fold=fold,method='BFWK-SVM',C=C,gamma=gamma);rows.append(rr)
        meta.append({'dataset':ds.name,'fold':fold,**aug,'C':C,'gamma':gamma,'bfwk_outer_iter':len(bfwk['history']),'bfwk_seconds':elapsed})
        print(f"STRESS {ds.name:14s} fold {fold}/{k} d={Xtr.shape[1]} BFWK_BA={rr['BalancedAccuracy']:.3f}",flush=True)
    return pd.DataFrame(rows),pd.DataFrame(meta)

def evaluate_dataset(ds: Dataset, max_n=1000, n_splits=5):
    Xdf,y = stratified_subsample(ds.X, ds.y, max_n=max_n, seed=SEED)
    min_class = min(np.sum(y==1), np.sum(y==-1))
    k = min(n_splits, int(min_class))
    if k < 2:
        raise ValueError(f"Too few minority samples in {ds.name}")
    cv=StratifiedKFold(n_splits=k,shuffle=True,random_state=SEED)
    rows=[]; meta=[]
    for fold,(tr,te) in enumerate(cv.split(Xdf,y),1):
        (C,gamma), inner_score=tune_C_gamma(Xdf,y,tr,SEED+fold)
        pre=make_preprocessor(Xdf.iloc[tr])
        Xtr=pre.fit_transform(Xdf.iloc[tr]); Xte=pre.transform(Xdf.iloc[te])
        keep=np.std(Xtr,axis=0)>1e-10
        Xtr=Xtr[:,keep]; Xte=Xte[:,keep]
        ytr=y[tr]; yte=y[te]
        q,M=compute_q_M(Xtr,ytr)
        alphas={
            "RBF-SVM":np.full(Xtr.shape[1],1/Xtr.shape[1]),
            "Relevance-SVM":q/(q.sum()+1e-12),
            "mRMR-SVM":mrmr_alpha(Xtr,ytr),
            "Two-stage RR-SVM":two_stage_alpha(q,M),
        }
        models={}
        for name,a in alphas.items():
            models[name]=fit_fixed_weight(Xtr,ytr,C,gamma,a)
        # linear SVM on standardized encoded predictors
        lin=LinearSVC(C=C,class_weight="balanced",dual="auto",max_iter=10000)
        lin.fit(Xtr,ytr)
        score=lin.decision_function(Xte)
        rr=metrics(yte,score); rr.update(dataset=ds.name,fold=fold,method="Linear SVM",C=C,gamma=gamma)
        rows.append(rr)
        for name,m in models.items():
            score=predict_kernel(m,Xte)
            rr=metrics(yte,score); rr.update(dataset=ds.name,fold=fold,method=name,C=C,gamma=gamma)
            rows.append(rr)
        t0=time.time()
        bfwk=fit_bfwk(Xtr,ytr,C,gamma)
        elapsed=time.time()-t0
        score=predict_kernel(bfwk,Xte)
        rr=metrics(yte,score); rr.update(dataset=ds.name,fold=fold,method="BFWK-SVM",C=C,gamma=gamma)
        rows.append(rr)
        meta.append({"dataset":ds.name,"fold":fold,"n_train":len(tr),"n_test":len(te),"d_transformed":Xtr.shape[1],
                     "C":C,"gamma":gamma,"inner_BA":inner_score,"bfwk_outer_iter":len(bfwk["history"]),
                     "bfwk_seconds":elapsed,"bfwk_weight_max":float(bfwk["alpha"].max()),
                     "bfwk_weight_entropy":float(-np.sum(bfwk["alpha"][bfwk["alpha"]>0]*np.log(bfwk["alpha"][bfwk["alpha"]>0])))})
        print(f"{ds.name:14s} fold {fold}/{k} C={C:g} g={gamma:g} d={Xtr.shape[1]} BFWK_BA={rr['BalancedAccuracy']:.3f} sec={elapsed:.2f}",flush=True)
    return pd.DataFrame(rows),pd.DataFrame(meta),Xdf,y


def holm(pvals: Dict[str,float]):
    items=sorted(pvals.items(),key=lambda kv: kv[1])
    m=len(items); out={}
    running=0
    adjusted=[]
    for i,(name,p) in enumerate(items):
        adj=min(1.0,(m-i)*p)
        running=max(running,adj)
        adjusted.append((name,running))
    return dict(adjusted)


def aggregate_results(datasets):
    raw_files=sorted(OUT.glob('fold_*.csv'))
    meta_files=sorted(OUT.glob('meta_*.csv'))
    info_files=sorted(OUT.glob('info_*.csv'))
    if not raw_files:
        return
    raw=pd.concat([pd.read_csv(f) for f in raw_files],ignore_index=True)
    meta=pd.concat([pd.read_csv(f) for f in meta_files],ignore_index=True) if meta_files else pd.DataFrame()
    info=pd.concat([pd.read_csv(f) for f in info_files],ignore_index=True) if info_files else pd.DataFrame()
    raw.to_csv(OUT/'benchmark_fold_results.csv',index=False)
    if len(meta): meta.to_csv(OUT/'benchmark_fit_metadata.csv',index=False)
    if len(info): info.drop_duplicates('Dataset').to_csv(OUT/'benchmark_datasets.csv',index=False)

    summary=(raw.groupby(['dataset','method'])[['BalancedAccuracy','MacroF1','AUROC','MCC']]
             .agg(['mean','std']).reset_index())
    summary.columns=['dataset','method']+[f'{a}_{b}' for a,b in summary.columns.tolist()[2:]]
    summary.to_csv(OUT/'benchmark_summary.csv',index=False)

    pivot=summary.pivot(index='dataset',columns='method',values='BalancedAccuracy_mean').dropna()
    ranks=pivot.rank(axis=1,ascending=False,method='average')
    avg_rank=ranks.mean(axis=0).sort_values()
    rank_df=pd.DataFrame({'Method':avg_rank.index,'AverageRank':avg_rank.values,
                          'MeanBalancedAccuracy':[pivot[c].mean() for c in avg_rank.index]})
    rank_df.to_csv(OUT/'benchmark_average_ranks.csv',index=False)

    method_order=list(pivot.columns)
    fried=stats.friedmanchisquare(*[pivot[c].values for c in method_order]) if len(pivot)>=2 else None
    pvals={}; effects={}
    if 'BFWK-SVM' in pivot:
        for c in method_order:
            if c=='BFWK-SVM':continue
            diff=pivot['BFWK-SVM']-pivot[c]
            try:
                w=stats.wilcoxon(diff,alternative='two-sided',zero_method='wilcox')
                p=float(w.pvalue)
            except Exception:
                p=1.0
            pvals[c]=p; effects[c]=float(diff.mean())
    adj=holm(pvals) if pvals else {}
    stat_rows=[]
    if fried is not None:
        stat_rows.append({'Comparison':'Friedman omnibus','Statistic':float(fried.statistic),'p_value':float(fried.pvalue),'Holm_p':np.nan,'Mean_BA_Difference':np.nan})
    for c in sorted(pvals,key=pvals.get):
        stat_rows.append({'Comparison':f'BFWK-SVM vs {c}','Statistic':np.nan,'p_value':pvals[c],'Holm_p':adj[c],'Mean_BA_Difference':effects[c]})
    pd.DataFrame(stat_rows).to_csv(OUT/'benchmark_statistical_tests.csv',index=False)
    with open(OUT/'benchmark_table.tex','w') as f:
        f.write(pivot.to_latex(float_format=lambda x:f'{x:.3f}',escape=True))
    with open(OUT/'rank_table.tex','w') as f:
        f.write(rank_df.to_latex(index=False,float_format=lambda x:f'{x:.3f}',escape=True))
    if len(info):
        with open(OUT/'dataset_table.tex','w') as f:
            f.write(info.drop_duplicates('Dataset').to_latex(index=False,float_format=lambda x:f'{x:.3f}',escape=True))
    print('\n=== Average ranks ===')
    print(rank_df.to_string(index=False))
    if fried is not None: print('\nFriedman:',fried)
    if stat_rows: print(pd.DataFrame(stat_rows).to_string(index=False))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--datasets', nargs='*', default=None, help='Dataset names to run; default all')
    parser.add_argument('--aggregate-only', action='store_true')
    parser.add_argument('--stress', action='store_true')
    args=parser.parse_args()
    datasets=make_datasets()
    if args.aggregate_only:
        aggregate_results(datasets); return
    selected=set(args.datasets) if args.datasets else None
    for ds in datasets:
        if selected is not None and ds.name not in selected:
            continue
        X,y=stratified_subsample(ds.X,ds.y,max_n=1000,seed=SEED)
        info=pd.DataFrame([{'Dataset':ds.name,'N':len(y),'RawFeatures':X.shape[1],'PositiveRate':float(np.mean(y==1)),'Source':ds.source,'TaskNote':ds.note}])
        safe=re.sub(r'[^A-Za-z0-9]+','_',ds.name).strip('_')
        print(f'\n=== {ds.name} ===',flush=True)
        if args.stress:
            r,m=evaluate_dataset_stress(ds,max_n=1000,n_splits=5)
            r.to_csv(OUT/f'stress_fold_{safe}.csv',index=False)
            m.to_csv(OUT/f'stress_meta_{safe}.csv',index=False)
        else:
            r,m,_,_=evaluate_dataset(ds,max_n=1000,n_splits=5)
            r.to_csv(OUT/f'fold_{safe}.csv',index=False)
            m.to_csv(OUT/f'meta_{safe}.csv',index=False)
            info.to_csv(OUT/f'info_{safe}.csv',index=False)
    aggregate_results(datasets)

if __name__=='__main__':
    main()
