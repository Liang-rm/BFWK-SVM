# New numerical implementation and sensitivity experiments

These files supplement the supplied original submission. They preserve the original benchmark drivers and result CSVs. The new public PercePiano study replaces the former case-study tables and figures in the revised manuscript.

## Corrected model convention

`revision_core.py` uses a fixed, strictly positive training-kernel diagonal jitter. The new default is `epsilon_K = 1e-6`, in the absolute scale of the Gaussian kernel whose diagonal is one. This is a newly declared default. It is not a recovered value for any historical table. The original Python driver's `fit_precomputed_svc` trains directly on the base kernel without an explicit added diagonal; the supplied R demonstration includes a separate numerical ridge. The configuration responsible for an individual historical table must be traced before assigning it a value.

Each new SVC fit uses `K_train + epsilon_K I`, with class-balanced actual box limits `C_i = C n/(2 n_class(i))`. The reported lower-level value is `sum(beta) - (1/2) u^T (K_train+epsilon_K I) u`, where `u_i=beta_i y_i`. The SVC intercept consequently corresponds to the same jittered kernel. This is an exact model modification, not just a change in numerical linear algebra.

For previously unseen test records, `predict_kernel(model,Xtest)` uses the base cross-kernel. No diagonal is added merely because two feature vectors are numerically identical. For evaluations at the exact training record identities and order, use `predict_kernel(model,model['X'],training_records=True)`. This explicit switch implements the record-identity nugget convention.

Two outer objectives are exposed:

* Raw: `J = V_epsilon + R(lambda,rho,tau)`.
* Normalized: `J_N = V_epsilon/n + R(lambda_N,rho_N,tau_N)`.

Equivalence to `J/n` requires normalized coefficients equal to the raw coefficients divided by `n`. At equal numerical coefficients these objectives differ. `normalized_coefficients` and `raw_coefficients` provide the mapping. New sensitivity and stress runs use the normalized convention, with explicitly normalized coefficients. The linear relevance term adds no curvature when `q` is fixed.

`fit_bfwk` returns the fitted weights, signed/unsigned dual coefficients, objective components, final projected-gradient residual, termination cause, SVC status, free-support-vector KKT diagnostic, equality residual, line-search evaluation count and elapsed time. An outer cap or small relative objective change is not a certificate of stationarity. The implemented Armijo solves are approximate at the recorded SVC tolerance; exact-inner convergence theorems must not be described as numerical guarantees for every capped run.

The new two-stage helper minimizes the training-only relevance–redundancy regularizer on the simplex, freezes its weights, and trains the jittered weighted SVM. Its projected-gradient step uses a spectral-norm bound. It is an explicit implementation convention; historical comparator results are not silently recomputed or attributed to it.

## Reproduction

Use Python 3.12 with NumPy, pandas, SciPy, scikit-learn, matplotlib and threadpoolctl. The local run used the versions written into `results_revision/factorial_jitter_protocol.json`. Limit BLAS threads to one for the recorded settings.

```text
python revision_factorial_jitter.py --pilot
python revision_factorial_jitter.py
python revision_inner_retry_and_traces.py
python revision_sensitivity_audit.py
python revision_publication_plots.py
```

The pilot measures a real WDBC fit and checks the envelope gradient against a central difference on a Wine-01 training partition. The numerical check is not a predictive benchmark. It also verifies the raw/normalized coefficient mapping.

The main driver runs a complete `3^5=243` Cartesian grid on each of Wine-01 and WDBC, using a prespecified training/validation/test partition and all 486 configurations. The five ranges include four orders of magnitude for each normalized regularization coefficient. Validation selects one configuration per task; only that selected configuration is refitted for independent test evaluation. The distinct jitter sweep evaluates seven fixed jitter values over three paired partitions per task at prespecified coefficients. These exploratory two-task runs are not the original 13-task nested evaluation.

Raw CSV rows, exact source sample indices, random seeds, parameter levels, dataset-array hashes, source-code hashes, software versions, caps and tolerances are stored alongside plots. Shading in the factorial plots is the range over joint configurations, not a confidence interval. Standard deviation across repeated jitter splits is descriptive because the splits overlap. No universal superiority, convergence, or robust parameter region is inferred from these plots.

The driver appends completed configuration records to support resumption. Delete or relocate the named new sensitivity CSVs before changing its protocol; mixing runs with different settings in one CSV is invalid. Original `results/` files must remain untouched.

`revision_inner_retry_and_traces.py` implements the uniformly applied retry rule for any factorial configuration with a capped inner solve: rerun that entire configuration from uniform feature weights at an inner cap of 200,000, retaining the outer cap of 80 and all other settings. Initial records are preserved in `results_revision/pilot_inner_cap50k`. Four WDBC configurations triggered the rule and all four resolved their inner caps; validation performance and chosen configurations were unchanged to floating-point precision. The script then refits the recorded jitter cases to export their complete iteration histories and verifies their held-out scores against the original measured records. Neither retry nor trace export uses independent test scores for selection.

`revision_scaling_diagnostic.py` separately measures nine computational-only fits on explicitly synthetic Gaussian classification data (n=250/500/1000; d=16/64/256). It uses one fresh process per case and a 20-iteration cap, records elapsed time and process RSS sampled every 2 ms, and reports the actual machine information. Each case has only one timing repetition; sampled RSS may miss shorter peaks. These diagnostics are not predictive experiments, do not establish convergence, and do not identify a universal maximum problem size.

`revision_sensitivity_audit.py` checks deterministic selected-model refits, exports their held-out scores, counts termination causes, and evaluates a conservative sufficient outer-gradient Lipschitz bound for the actual normalized objective. Extremely large analytic upper bounds must not be called estimated true Lipschitz constants.

`revision_publication_plots.py` reads the completed CSVs only. It creates separate five-factor figures for Wine-01 and WDBC using a two-row layout, and regenerates the jitter sensitivity and iteration-trace figures with fonts suitable for printing at approximately seven inches wide. It does not rerun or alter experiments. Run it after the experiment and retry drivers to retain the publication layout.

## Completed PercePiano study

The official public ratings and MIDI files at commit e672299b8661f63802cd5cd73bb3c76218a13029 are now included as a fixed source archive with license and provenance. revision_percepiano_download.py verifies its SHA-256 and safely extracts it without executing repository code. revision_percepiano_ratings.py removes invalid records and exact rater/segment rating-vector duplicates, then averages distinct repeated assessments within rater before calculating segment means and ddof=1 sample variances. revision_percepiano_features.py pairs MIDI events with tempo conversion and computes 45 observable descriptors; the constant pedal-presence column is removed inside every human-cohort outer fit.

revision_percepiano_analysis.py uses the same 1,073 human segments for ten target definitions and both grouped protocols. In each outer training fold, uniform-RBF primary-target validation selects common C/gamma values; preprocessing, relevance and dependence estimates are trained locally. Primary target: official question 19. Composite: explicit questions 13, 15, 18 and 19; IVW stabilizers 1e-6, 1e-4 and 1e-2; equal and training-standardized means; other individual questions; and an all-valid-record aggregation comparison. Training-fold medians set all binary thresholds. The common-parameter protocol isolates target effects and is not independent optimal tuning of each method/target.

The driver completes 240 outer-fold fits. BFWK uses normalized coefficients (lambda,rho,tau)=(0.08,0.18,0.35), epsilon_K=1e-6, outer cap100, SVC tolerance1e-7 and cap50,000 with a once-only full-fit retry at200,000. Its projected-residual threshold is1e-4 and objective-change threshold1e-8. Final statuses and residuals remain saved. The new two-stage comparator uses step1/(lambda+rho*norm(M,2)), cap300 and weight-change threshold1e-8 before its frozen-metric SVC.

Primary-target importance uses20 permutations per feature and per group on each of8 held-out folds. A group is shuffled jointly with one row permutation. Importance is the decrease in balanced accuracy; zero and negative values remain. The50 bootstrap resamples draw performer-code groups from the first outer training partition, keeping its selected parameters and original target threshold fixed, while refitting preprocessing/q/M/weights. Collinearity associations, cosine similarities and percentile ranges are descriptive. Correlation clusters use connected components at absolute Pearson correlation>=0.8.

revision_percepiano_validate.py independently reconstructs all240 decision functions from features, training IDs, preprocessing arrays and fitted parameters, and checks group separation, thresholds and normalization. The measured maximum score discrepancy is2.8e-12. The main README contains full commands; plotting scripts read completed CSV/model summaries. This new MIDI analysis does not reconstruct the historical feature matrix, audio timbre, ambiguous old composite or0.812 estimate.

