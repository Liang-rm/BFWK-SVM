#!/usr/bin/env python3
"""Publication figures from completed, saved PercePiano results only.

Reads the result tables/fit histories; does not fit models, change source data,
or compute significance tests. Error bars in model/group plots are fold SD,
not confidence intervals. Bootstrap figures describe the fixed reference fold.
Run with --dependency-dir /path/to/local/python_packages when necessary.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
GROUPS = ["Timing", "Dynamics", "Articulation", "Pedal", "Phrasing"]
GROUP_COLORS = dict(zip(GROUPS, ["#4477AA", "#EE6677", "#228833", "#CC9900", "#AA3377"]))
PROTOCOLS = [("performer_code", "Performer-code holdout", 5), ("work", "Work holdout", 3)]
METHODS = ["BFWK-N", "Uniform-RBF", "Two-stage-RR"]
METHOD_STYLE = {"BFWK-N": ("#0072B2", "o"), "Uniform-RBF": ("#666666", "s"), "Two-stage-RR": ("#D55E00", "^")}
TARGETS = ["interpretation", "composite_ivw_1e_4", "composite_equal", "composite_zmean",
           "single13", "single15", "single18", "composite_ivw_1e_6", "composite_ivw_1e_2", "composite_ivw_released_rows"]
TARGET_LABELS = ["Q19: interpretation", r"IVW ($\delta=10^{-4}$)", "Equal mean", "Training z-mean",
                 "Q13: spacious", "Q15: dramatic", "Q18: imaginative",
                 r"IVW ($\delta=10^{-6}$)", r"IVW ($\delta=10^{-2}$)", "IVW: released rows"]


def setup():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12,
        "axes.labelsize": 13, "axes.titlesize": 13, "xtick.labelsize": 12,
        "ytick.labelsize": 12, "legend.fontsize": 12, "figure.titlesize": 15,
        "axes.linewidth": .8, "lines.linewidth": 1.6, "pdf.fonttype": 42,
        "ps.fonttype": 42, "savefig.dpi": 300, "axes.spines.top": False,
        "axes.spines.right": False})


def save(fig, folder, name):
    # Fixed canvas sizes keep all visible text at the declared point sizes.
    fig.savefig(folder/(name+".pdf"), facecolor="white")
    fig.savefig(folder/(name+".png"), dpi=300, facecolor="white")
    import matplotlib.pyplot as plt
    plt.close(fig)


def style(ax, axis="x"):
    ax.grid(axis=axis, color="#DDDDDD", linewidth=.7, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=3)


def panel(ax, label):
    ax.text(-.03, 1.045, label, transform=ax.transAxes, fontsize=13, fontweight="bold", va="bottom")


def profiles(folder):
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    frame = pd.read_csv(folder/"model_summary.csv")
    assert set(frame.target)==set(TARGETS)
    fig, axes = plt.subplots(1, 2, figsize=(9.8, 7.8), sharey=True)
    fig.subplots_adjust(left=.265, right=.98, bottom=.21, top=.90, wspace=.14)
    y=np.arange(len(TARGETS))
    xmin=float((frame.BalancedAccuracy_mean-frame.BalancedAccuracy_std).min())
    xmax=float((frame.BalancedAccuracy_mean+frame.BalancedAccuracy_std).max())
    lo=max(0, min(.48, xmin-.025)); hi=min(1, max(.85, xmax+.025))
    for pi,(protocol,title,k) in enumerate(PROTOCOLS):
        ax=axes[pi]
        for mi,method in enumerate(METHODS):
            d=frame[(frame.protocol==protocol)&(frame.method==method)].set_index("target").loc[TARGETS]
            color,marker=METHOD_STYLE[method]
            ax.errorbar(d.BalancedAccuracy_mean, y+(mi-1)*.20,
                xerr=d.BalancedAccuracy_std, fmt=marker, color=color,
                markersize=5, elinewidth=1.15, capsize=2.5, linestyle="none", zorder=3)
        ax.axvline(.5,color="#888888",linestyle="--",linewidth=1)
        ax.set_xlim(lo,hi);ax.set_ylim(len(TARGETS)-.5,-.5)
        ax.set_yticks(y);ax.set_yticklabels(TARGET_LABELS)
        ax.set_xlabel("Balanced accuracy")
        ax.set_title(f"{title}\n({k} folds)",pad=13)
        style(ax);panel(ax,chr(65+pi))
    handles=[Line2D([],[],marker=METHOD_STYLE[m][1],color=METHOD_STYLE[m][0],linestyle="none",markersize=6,label=m) for m in METHODS]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.61,.105),ncol=3,frameon=False,handletextpad=.4,columnspacing=1.2)
    fig.text(.5,.055,"Markers: fold means; bars: fold SD.",ha="center",fontsize=12)
    fig.text(.5,.025,"Each target defines a different classification task.",ha="center",fontsize=12)
    save(fig,folder,"percepiano_model_profiles")


def group_importance(folder):
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    frame=pd.read_csv(folder/"permutation_group_results.csv")
    columns=[("mass","Group mass"),("renormalized_mean_weight","Normalized mean"),("importance_mean","Group permutation")]
    fig,axes=plt.subplots(2,3,figsize=(9.8,7.6),sharey=True)
    fig.subplots_adjust(left=.165,right=.98,bottom=.17,top=.90,hspace=.60,wspace=.25)
    for ri,(protocol,title,k) in enumerate(PROTOCOLS):
        part=frame[frame.protocol==protocol]
        for ci,(column,heading) in enumerate(columns):
            ax=axes[ri,ci]
            agg=part.groupby("group")[column].agg(["mean","std"]).loc[GROUPS]
            ax.barh(np.arange(5),agg["mean"],xerr=agg["std"],height=.62,
                color=[GROUP_COLORS[g] for g in GROUPS],edgecolor="none",alpha=.88,
                error_kw=dict(elinewidth=1.05,capsize=2.5,capthick=1.05),zorder=3)
            ax.set_yticks(range(5));ax.set_yticklabels(GROUPS);ax.set_ylim(4.6,-.6)
            ax.axvline(0,color="#777777",linewidth=.9)
            ax.set_title(heading,pad=12)
            if ci<2:
                ax.set_xlim(0,.55);ax.set_xlabel("Weight fraction")
            else:
                # Keep negative effects and negative error-bar endpoints visible.
                low=float((agg["mean"]-agg["std"]).min());high=float((agg["mean"]+agg["std"]).max())
                ax.set_xlim(min(-.025,low-.01),max(.12,high+.01));ax.set_xlabel("BA decrease")
            style(ax);panel(ax,chr(65+ri*3+ci))
        axes[ri,0].text(0,1.25,f"{title} ({k} folds)",transform=axes[ri,0].transAxes,fontsize=14,fontweight="bold")
    fig.text(.5,.075,"Means ± fold SD; primary Q19 target. Held-out BA: balanced accuracy.",ha="center",fontsize=12)
    fig.text(.5,.035,"Size normalization uses mean weight per retained feature, then renormalizes across groups.",ha="center",fontsize=12)
    save(fig,folder,"percepiano_group_importance")


def stability(folder):
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    frame=pd.read_csv(folder/"bootstrap_weight_stability.csv")
    keep=frame.retained_reference.astype(str).str.lower().isin(["true","1","1.0"])
    frame=frame.loc[keep].copy()
    spec=json.loads((folder/"feature_groups.json").read_text(encoding="utf-8"))
    group_for={f:g for g,fs in spec["groups"].items() for f in fs}
    frame["group"]=frame.feature.map(group_for)
    summary=json.loads((folder/"bootstrap_stability_summary.json").read_text())
    clusters=pd.read_csv(folder/"correlated_cluster_stability.csv")
    clusters=clusters[clusters["size"]>1]
    records=[json.loads(p.read_text()) for p in sorted((folder/"bootstrap_records").glob("*.json"))]
    assert len(records)==summary["replicates"]==50
    alpha=np.asarray([r["alpha"] for r in records])
    all_names=[d["name"] for d in spec["definitions"]]
    group_mass=np.column_stack([alpha[:,[all_names.index(f) for f in spec["groups"][g]]].sum(axis=1) for g in GROUPS])
    fig,axes=plt.subplots(2,2,figsize=(9.8,9.2))
    fig.subplots_adjust(left=.12,right=.98,bottom=.13,top=.87,hspace=.58,wspace=.33)
    for ci,column in enumerate(["weight_sd","weight_cv_eps1e_6"]):
        ax=axes[0,ci]
        for group in GROUPS:
            part=frame[frame.group==group]
            ax.scatter(part.max_abs_training_correlation,part[column],s=42,color=GROUP_COLORS[group],edgecolors="white",linewidths=.45,alpha=.9,zorder=3)
        ax.set_xlabel("Maximum absolute training correlation")
        ax.set_ylabel("Bootstrap weight SD" if ci==0 else r"Bootstrap weight CV")
        ax.set_xlim(max(0,float(frame.max_abs_training_correlation.min())-.05),1.02)
        ax.set_ylim(bottom=0)
        rho=summary["spearman_collinearity_vs_weight_sd" if ci==0 else "spearman_collinearity_vs_weight_cv"]
        ax.text(.04,.95,rf"Descriptive $\rho={rho:.3f}$",transform=ax.transAxes,fontsize=12,va="top")
        style(ax,"y");panel(ax,chr(65+ci))
    ax=axes[1,0]
    limit=max(float(clusters.mean_individual_cv.max()),float(clusters.mass_cv.max()))*1.12
    ax.plot([0,limit],[0,limit],"--",color="#888888",linewidth=1.1)
    ax.scatter(clusters.mean_individual_cv,clusters.mass_cv,s=45+clusters["size"]*12,color="#4477AA",edgecolors="white",linewidths=.6,zorder=3)
    offsets={1:(5,4),6:(-13,5),7:(-14,-15),8:(8,-5),15:(7,2),20:(5,10),21:(-13,-10)}
    for _,row in clusters.iterrows():
        ax.annotate(str(int(row["size"])),(row.mean_individual_cv,row.mass_cv),xytext=offsets.get(int(row.cluster),(5,4)),textcoords="offset points",fontsize=12)
    ax.set_xlim(0,limit);ax.set_ylim(0,limit)
    ax.set_xlabel("Mean individual-weight CV");ax.set_ylabel("Cluster-mass CV")
    ax.set_title(r"Connected clusters at $|r|\geq0.8$",pad=11)
    ax.text(.04,.95,"Labels: features per cluster",transform=ax.transAxes,va="top",fontsize=12)
    style(ax,"both");panel(ax,"C")
    ax=axes[1,1]
    rng=np.random.default_rng(20261020)
    for gi,group in enumerate(GROUPS):
        vals=group_mass[:,gi]
        jitter=rng.uniform(-.15,.15,size=len(vals))
        ax.scatter(vals,gi+jitter,s=15,color=GROUP_COLORS[group],alpha=.45,edgecolors="none",zorder=2)
        q=np.quantile(vals,[.025,.975])
        ax.plot(q,[gi,gi],color=GROUP_COLORS[group],linewidth=2.2,zorder=3)
        ax.plot([vals.mean()],[gi],marker="D",markersize=6,color=GROUP_COLORS[group],markeredgecolor="white",markeredgewidth=.5,zorder=4)
    ax.set_yticks(range(5));ax.set_yticklabels(GROUPS);ax.set_ylim(4.6,-.6)
    ax.set_xlabel("Bootstrap group mass");ax.set_xlim(0,.5)
    ax.set_title("Group-level weight variation",pad=11)
    style(ax);panel(ax,"D")
    handles=[Line2D([],[],marker="o",color=GROUP_COLORS[g],linestyle="none",markersize=6,label=g) for g in GROUPS]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.53,.975),ncol=5,frameon=False,columnspacing=1.0,handletextpad=.35)
    fig.text(.5,.065,"50 performer-group bootstrap refits of one fixed training fold; no significance tests.",ha="center",fontsize=12)
    fig.text(.5,.032,r"CV = SD / max(mean, $10^{-6}$). Panel D: points = refits; diamond = mean; line = 2.5–97.5% quantiles.",ha="center",fontsize=12)
    save(fig,folder,"percepiano_stability")


def optimization(folder):
    import numpy as np
    import matplotlib.pyplot as plt
    records=[json.loads(p.read_text()) for p in sorted((folder/"fit_records").glob("*_interpretation.json"))]
    assert len(records)==8
    colors=["#4477AA","#EE6677","#228833","#CC9900","#AA3377"]
    fig,axes=plt.subplots(2,2,figsize=(9.8,8.0),sharex="col")
    fig.subplots_adjust(left=.12,right=.98,bottom=.15,top=.89,hspace=.25,wspace=.28)
    for ci,(protocol,title,k) in enumerate(PROTOCOLS):
        part=sorted((r for r in records if r["protocol"]==protocol),key=lambda r:r["fold"])
        assert len(part)==k
        for r in part:
            m=next(m for m in r["methods"] if m["method"]=="BFWK-N")
            history=m["history"]
            xx=np.asarray([h["iteration"] for h in history])
            objective=np.asarray([h["objective"] for h in history])
            residual=np.asarray([h["residual"] for h in history])
            assert len(xx)>0 and np.all(residual>0)
            color=colors[int(r["fold"])-1]
            axes[0,ci].plot(xx,objective,color=color,label=f"Fold {r['fold']}")
            axes[1,ci].plot(xx,residual,color=color)
            final_x=xx[-1] if m["termination"] in ["projected_gradient_tolerance","line_search_failed"] else xx[-1]+1
            axes[1,ci].plot(final_x,m["residual"],marker="x",markersize=7,markeredgewidth=1.7,color=color,linestyle="none")
        axes[0,ci].set_title(f"{title} ({k} folds)",pad=13)
        axes[0,ci].legend(frameon=False,loc="center right" if ci==0 else "upper right",fontsize=12,ncol=1,handlelength=1.5,labelspacing=.25)
        axes[1,ci].set_yscale("log")
        axes[1,ci].axhline(1e-4,color="#888888",linestyle="--",linewidth=1.1)
        axes[1,ci].set_xlabel("Outer iteration")
        for ri in range(2):
            style(axes[ri,ci],"y");panel(axes[ri,ci],chr(65+ri*2+ci))
    axes[0,0].set_ylabel(r"Recorded objective $J_N$")
    axes[1,0].set_ylabel("Projected-gradient residual")
    fig.text(.5,.072,"Primary Q19 interpretation target; curves show recorded pre-step values.",ha="center",fontsize=12)
    fig.text(.5,.035,r"×: returned-weight residual. Dashed line: projected-gradient tolerance $10^{-4}$.",ha="center",fontsize=12)
    save(fig,folder,"percepiano_optimization")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,default=HERE/"results_percepiano")
    parser.add_argument("--dependency-dir",type=Path)
    args=parser.parse_args()
    if args.dependency_dir:
        sys.path.insert(0,str(args.dependency_dir.resolve()))
    setup()
    profiles(args.input)
    group_importance(args.input)
    stability(args.input)
    optimization(args.input)
    print("Saved four PDF/PNG figures from existing result tables and actual recorded histories.")


if __name__=="__main__":
    main()
