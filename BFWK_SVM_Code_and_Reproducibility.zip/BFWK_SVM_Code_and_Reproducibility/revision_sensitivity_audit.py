"""Summarize measured sensitivity, save selected held-out predictions and bounds.

Run only after revision_factorial_jitter.py has completed. The selected model
refit is a deterministic verification, not an additional model-selection step.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
import revision_core as core
import revision_factorial_jitter as run


def main():
    out=run.OUT;grid=pd.read_csv(out/"factorial_grid.csv")
    selected=pd.read_csv(out/"factorial_selected_test.csv")
    jitter=pd.read_csv(out/"jitter_sensitivity.csv")
    counts=grid.groupby(["dataset","status","termination"]).size().reset_index(name="count")
    counts.to_csv(out/"factorial_termination_counts.csv",index=False)
    summaries=[];bounds=[];predictions=[]
    for row in selected.to_dict("records"):
        name=row["dataset"];X,y,ids,_=run.datasets()[name]
        tr,va,te=run.split_data(X,y,run.SEED,True);dev=np.r_[tr,va];A,T=run.scaled(X,dev,te)
        model=core.fit_bfwk(A,y[dev],row["C"],row["gamma"],row["lambda"],row["rho"],row["tau"],max_outer=run.CAP)
        score=core.predict_kernel(model,T);met=core.metrics(y[te],score)
        if abs(met["BalancedAccuracy"]-row["independent_test_BA"])>1e-12:
            raise RuntimeError("Selected-model deterministic verification disagrees")
        for original_id,label,s in zip(ids[te],y[te],score):
            predictions.append({"dataset":name,"original_id":int(original_id),"label":int(label),"score":float(s),"predicted_label":1 if s>=0 else -1})
        n=len(A);sum_squared_deltas=np.zeros((n,n))
        for r in range(A.shape[1]):
            diff=A[:,r,None]-A[None,:,r]
            sum_squared_deltas+=diff**4  # ||d_ij||_2² where delta_ijr=(x_ir-x_jr)².
        B1=row["gamma"]*np.sqrt(sum_squared_deltas.sum())
        B2=row["gamma"]**2*np.sqrt((sum_squared_deltas**2).sum())
        Rbeta2=float(np.sum(core.class_box_limits(y[dev],row["C"])**2))
        regularizer_bound=row["lambda"]+row["rho"]*np.linalg.norm(model["M"],2)
        # Normalized objective scales V only. Its normalized regularizers above
        # correspond to raw coefficients multiplied by n.
        sufficient=regularizer_bound+Rbeta2/n*(B1**2/core.DEFAULT_JITTER+B2/2)
        bounds.append({"dataset":name,"n_refit":n,"d":A.shape[1],"C":row["C"],"gamma":row["gamma"],
                       "lambda_N":row["lambda"],"rho_N":row["rho"],"tau_N":row["tau"],
                       "jitter_only_mu":core.DEFAULT_JITTER,"B1":B1,"B2":B2,"Rbeta_squared":Rbeta2,
                       "regularizer_L_bound":regularizer_bound,"normalized_L_sufficient_bound":sufficient,
                       "interpretation":"Conservative analytic upper bound, not an estimated true smoothness constant"})
        g=grid[grid.dataset==name];j=jitter[jitter.dataset==name]
        summaries.append({"dataset":name,"grid_evaluations":len(g),"failures":int((g.status!="completed").sum()),
                          "outer_caps":int((g.termination=="outer_iteration_cap").sum()),
                          "projected_tolerance_stops":int((g.termination=="projected_gradient_tolerance").sum()),
                          "relative_objective_stops":int((g.termination=="relative_objective_tolerance").sum()),
                          "line_search_failures":int((g.termination=="line_search_failed").sum()),
                          "any_inner_solver_failure":int((g.dual_fit_status!=0).sum()),
                          "validation_BA_min":float(g.validation_BA.min()),"validation_BA_max":float(g.validation_BA.max()),
                          "median_final_residual":float(g.projected_gradient_residual.median()),
                          "grid_seconds_sum":float(g.seconds.sum()),"jitter_evaluations":len(j),
                          "jitter_BA_mean_min":float(j.groupby("jitter").test_BA.mean().min()),
                          "jitter_BA_mean_max":float(j.groupby("jitter").test_BA.mean().max())})
    pd.DataFrame(predictions).to_csv(out/"factorial_selected_test_predictions.csv",index=False)
    pd.DataFrame(bounds).to_csv(out/"lipschitz_bounds_selected.csv",index=False)
    summary=pd.DataFrame(summaries);summary.to_csv(out/"sensitivity_audit_summary.csv",index=False)
    lines=["# Measured full-factorial and jitter sensitivity (new revision runs)","",
           "These exploratory public-data results do not replace the archived 13-task benchmark. They use a newly specified fixed kernel jitter of 1e-6; no historical epsilon value is inferred.","",
           "The actual normalized objective is V_epsilon/n + R(lambda_N,rho_N,tau_N). It equals raw J/n only with raw regularization coefficients n times the normalized coefficients. Every training dual value and bias uses the same jittered training Gram matrix; held-out predictions use the base cross-kernel.","",
           "The full Cartesian design has 3^5=243 configurations per dataset (486 total), with C in {0.25,4,64}, gamma in {0.01,0.1,1}, and each of lambda_N,rho_N,tau_N in {0.001,0.1,10}. One fixed stratified 60/20/20 train/validation/test split per task was declared before execution. Validation selects the maximum balanced accuracy with grid-order tie breaking. The chosen configuration is refitted on train+validation and evaluated once on the independent test partition.","",
           "The separate jitter sweep uses seven values from 1e-12 to 0.1 over three paired 70/30 splits per dataset (42 fits), with C=4, gamma=0.1, lambda_N=0.08, rho_N=0.18, tau_N=0.35. Split standard deviations are descriptive: the repeated splits overlap and are not independent replications.","",
           "All sensitivity fits use an 80-iteration outer cap, a projected-gradient tolerance of 1e-4, a relative-objective tolerance of 1e-7, and SVC tolerance 1e-5. The initial inner cap was 50,000 iterations. Under a uniform documented retry rule, the four factorial configurations with any initial capped inner solve were refitted from uniform alpha with an inner cap of 200,000. Their initial records are preserved under pilot_inner_cap50k and the final per-row cap is recorded in factorial_grid.csv. All four retries resolved the inner cap; validation scores and the selected configurations were unchanged to floating-point precision. A relative-objective stop or outer cap does not certify a small stationarity residual. Convergence conclusions must use the recorded residuals and termination causes.","",
           "One-dimensional factorial plots marginalize over 81 joint configurations at each parameter level; shaded bands are min–max configuration ranges, not confidence intervals. Grid observations are not treated as independent datasets.","",
           summary.to_csv(index=False),"",
           "Selected-model held-out results:","",selected[["dataset","C","gamma","lambda","rho","tau","validation_BA","independent_test_BA","independent_test_accuracy","termination","projected_gradient_residual"]].to_csv(index=False),"",
           "The selected-model Lipschitz-bound table evaluates a sufficient analytic bound for the actual normalized objective, using mu_beta=epsilon_K. These bounds may be extremely conservative and cannot establish that the true Lipschitz constants are moderate. The jitter sweep also records observed restricted curvature and full-Hessian conditioning; those floating-point diagnostics are not proofs of a uniform bound over the simplex.","",
           "No result here addresses missing raw PercePiano target ratings, original musical feature groups, or its permutation importance. No universal robust parameter region or statistically significant accuracy advantage is claimed from this exploratory design."]
    # Avoid a dependency on optional tabulate when writing plain-text summaries.
    (out/"sensitivity_results_notes.md").write_text("\n".join(lines),encoding="utf-8")
    print(summary.to_string(index=False));print(pd.DataFrame(bounds).to_string(index=False))


if __name__=="__main__":
    with threadpool_limits(limits=1):main()
