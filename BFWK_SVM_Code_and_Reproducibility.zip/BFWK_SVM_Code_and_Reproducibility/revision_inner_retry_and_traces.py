"""Documented recovery of inner-cap cases, plus actual jitter iteration traces.

Uniform rule: any factorial configuration whose initial evaluated inner solves
hit 50,000 iterations is refitted from the initial uniform alpha with an inner
cap of 200,000; all other settings, including the outer cap of 80, are unchanged.
Initial complete records are preserved before any replacement. Selection remains
based exclusively on validation balanced accuracy, never the independent test.
"""
import hashlib, json, shutil
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from threadpoolctl import threadpool_limits
import revision_core as core
import revision_factorial_jitter as run
import revision_sensitivity_audit as audit


def retry():
    out=run.OUT;archive=out/"pilot_inner_cap50k";archive.mkdir(exist_ok=True)
    for name in ("factorial_grid.csv","factorial_selected_test.csv","factorial_jitter_protocol.json",
                 "factorial_marginal_profiles.csv","factorial_selected_test_predictions.csv","sensitivity_audit_summary.csv"):
        src=out/name;dst=archive/name
        if src.exists() and not dst.exists():shutil.copy2(src,dst)
    grid=pd.read_csv(out/"factorial_grid.csv")
    if "inner_cap_used" not in grid:grid["inner_cap_used"]=50000
    if "inner_retry" not in grid:grid["inner_retry"]=False
    log=[]
    for i,row in grid[(grid.dual_fit_status!=0)&(~grid.inner_retry)].iterrows():
        X,y,_,_=run.datasets()[row.dataset];tr,va,te=run.split_data(X,y,run.SEED,True);A,B=run.scaled(X,tr,va)
        model=core.fit_bfwk(A,y[tr],row.C,row.gamma,row["lambda"],row.rho,row.tau,max_outer=run.CAP,svc_max_iter=200000)
        m=core.metrics(y[va],core.predict_kernel(model,B))
        record={"dataset":row.dataset,"grid_id":int(row.grid_id),"original_inner_cap":50000,"retry_inner_cap":200000,
                "original_validation_BA":row.validation_BA,"retry_validation_BA":m["BalancedAccuracy"],
                "original_residual":row.projected_gradient_residual,"retry_residual":model["projected_gradient_residual"],
                "retry_any_inner_cap":model["dual_fit_status"],"outer_cap_unchanged":run.CAP,"retry_seconds":model["seconds"]}
        log.append(record)
        for key,value in {**run.diagnostic(model),"validation_BA":m["BalancedAccuracy"],"validation_accuracy":m["Accuracy"],
                          "inner_cap_used":200000,"inner_retry":True}.items():grid.loc[i,key]=value
        print("INNER RETRY",record,flush=True)
    grid.to_csv(out/"factorial_grid.csv",index=False)
    if log:pd.DataFrame(log).to_csv(out/"factorial_inner_retry_log.csv",index=False)
    protocol=json.loads((out/"factorial_jitter_protocol.json").read_text(encoding="utf-8"))
    protocol["inner_retry_policy"]="Any configuration with an initial inner cap is refitted from uniform alpha with 200000 inner iterations; outer80 unchanged; initial CSVs preserved in pilot_inner_cap50k"
    protocol["inner_retry_driver_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    protocol["rows_after_retry"]=len(grid);protocol["unresolved_inner_cap_rows"]=int((grid.dual_fit_status!=0).sum())
    (out/"factorial_jitter_protocol.json").write_text(json.dumps(protocol,indent=2),encoding="utf-8")
    # This recomputes validation-only selection from completed rows. The CSV
    # already contains every grid ID, so no grid configuration is duplicated.
    run.factorial(["Wine-01","WDBC"])


def traces():
    rows=[];predictions=[];measured=pd.read_csv(run.OUT/"jitter_sensitivity.csv")
    for row in measured.itertuples(index=False):
        X,y,ids,_=run.datasets()[row.dataset]
        tr,te=run.split_data(X,y,int(row.split_seed),False);A,T=run.scaled(X,tr,te)
        model=core.fit_bfwk(A,y[tr],4.,.1,.08,.18,.35,jitter=row.jitter,max_outer=run.CAP)
        score=core.predict_kernel(model,T);m=core.metrics(y[te],score)
        if abs(m["BalancedAccuracy"]-row.test_BA)>1e-12:raise RuntimeError("Jitter trace refit differs from measured score")
        for h in model["history"]:
            rows.append({"dataset":row.dataset,"split_seed":int(row.split_seed),"jitter":row.jitter,**h,"is_returned_final":False})
        rows.append({"dataset":row.dataset,"split_seed":int(row.split_seed),"jitter":row.jitter,
                     "iteration":len(model["history"]),"objective":model["objective"],"residual":model["projected_gradient_residual"],"step":0.,"is_returned_final":True})
        for original_id,label,s in zip(ids[te],y[te],score):
            predictions.append({"dataset":row.dataset,"split_seed":int(row.split_seed),"jitter":row.jitter,"original_id":int(original_id),"label":int(label),"score":float(s)})
    df=pd.DataFrame(rows);df.to_csv(run.OUT/"jitter_iteration_histories.csv",index=False)
    pd.DataFrame(predictions).to_csv(run.OUT/"jitter_heldout_predictions.csv",index=False)
    fig,axs=plt.subplots(1,2,figsize=(10,3.6))
    for ax,name in zip(axs,["Wine-01","WDBC"]):
        for eps,g in df[(df.dataset==name)&(df.split_seed==run.SEED)].groupby("jitter"):
            ax.semilogy(g.iteration,np.maximum(g.residual,1e-12),label=f"{eps:g}")
        ax.set_xlabel("Outer iteration");ax.set_ylabel("Projected-gradient residual");ax.set_title(name);ax.grid(alpha=.2);ax.legend(title="Fixed jitter",fontsize=7)
    fig.suptitle("Actual residual traces for the first prespecified paired split; stopping does not certify stationarity")
    fig.tight_layout();fig.savefig(run.OUT/"jitter_iteration_traces.png",dpi=180);fig.savefig(run.OUT/"jitter_iteration_traces.pdf");plt.close(fig)
    print("Exported42 measured jitter histories and verified held-out scores",flush=True)


if __name__=="__main__":
    with threadpool_limits(limits=1):
        retry();traces();run.plots();audit.main()
