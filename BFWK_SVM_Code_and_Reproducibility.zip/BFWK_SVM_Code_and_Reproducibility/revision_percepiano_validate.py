"""Independent numerical consistency checks of saved public-data fits."""
from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
from revision_core import weighted_kernel
from revision_percepiano_analysis import data,score_vector,preprocessing,OUT,TARGETS

def main():
    d=data();splits=json.loads((OUT/'analysis_splits.json').read_text())
    lookup={(s['protocol'],s['fold']):s for s in splits}
    maximum=0.;fits=0
    with threadpool_limits(limits=1):
        for path in sorted((OUT/'fit_records').glob('*.json')):
            r=json.loads(path.read_text());s=lookup[r['protocol'],r['fold']]
            tr=np.asarray(s['train']);te=np.asarray(s['test'])
            assert not set(d['df'].iloc[tr][s['group_field']])&set(d['df'].iloc[te][s['group_field']])
            X,p=preprocessing(d['X'],tr)
            cont,_=score_vector(d,r['target'],tr)
            cut=np.median(cont[tr]);assert abs(cut-r['threshold'])<1e-12
            y=np.where(cont[te]>=cut,1,-1)
            for m in r['methods']:
                z=np.load(OUT/'fit_records'/m['model_file'],allow_pickle=False)
                assert np.array_equal(z['train'],tr) and np.array_equal(z['test'],te)
                assert np.array_equal(z['retained_mask'],p['mask'])
                for key in ['median','center','scale']:assert np.max(np.abs(z[key]-p[key]))<1e-12
                alpha=z['alpha'][p['mask']]
                assert alpha.min()>=-1e-12 and abs(alpha.sum()-1)<1e-10
                score=weighted_kernel(X[te],X[tr],alpha,float(z['gamma']))@z['u']+float(z['intercept'])
                err=float(np.max(np.abs(score-z['score'])))
                assert err<1e-7,(path.name,m['method'],err)
                assert np.array_equal(y,z['ytest'])
                maximum=max(maximum,err);fits+=1
    assert len(list((OUT/'fit_records').glob('*.json')))==80
    assert fits==240
    assert len(list((OUT/'bootstrap_records').glob('*.json')))==50
    featurepi=pd.read_csv(OUT/'permutation_feature_results.csv')
    grouppi=pd.read_csv(OUT/'permutation_group_results.csv')
    assert len(featurepi)==8*44 and len(grouppi)==8*5
    assert np.isfinite(featurepi[['alpha','importance_mean','importance_sd_repeats']]).all().all()
    for _,group in grouppi.groupby(['protocol','fold']):
        assert abs(group.mass.sum()-1)<1e-10
        assert abs(group.renormalized_mean_weight.sum()-1)<1e-10
        assert np.max(np.abs(group.mass/group.retained_count-group.mean_weight_per_feature))<1e-12
    summary={'cohort':len(d['df']),'outer_target_records':80,'fitted_models_reconstructed':fits,'max_prediction_reconstruction_error':maximum,
             'bootstrap_replicates':50,'heldout_feature_permutations':int(len(featurepi)*20),'heldout_group_permutations':int(len(grouppi)*20),
             'all_group_splits_disjoint':True,'training_only_preprocessing_reproduced':True,'training_only_target_thresholds_reproduced':True,
             'group_mass_and_normalization_checks':True,'python':platform.python_version(),
             'interpretation':'Numerical consistency checks do not certify asymptotic convergence or historical-case replication.'}
    (OUT/'numerical_validation.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
