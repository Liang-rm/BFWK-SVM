# Measured full-factorial and jitter sensitivity (new revision runs)

These exploratory public-data results do not replace the archived 13-task benchmark. They use a newly specified fixed kernel jitter of 1e-6; no historical epsilon value is inferred.

The actual normalized objective is V_epsilon/n + R(lambda_N,rho_N,tau_N). It equals raw J/n only with raw regularization coefficients n times the normalized coefficients. Every training dual value and bias uses the same jittered training Gram matrix; held-out predictions use the base cross-kernel.

The full Cartesian design has 3^5=243 configurations per dataset (486 total), with C in {0.25,4,64}, gamma in {0.01,0.1,1}, and each of lambda_N,rho_N,tau_N in {0.001,0.1,10}. One fixed stratified 60/20/20 train/validation/test split per task was declared before execution. Validation selects the maximum balanced accuracy with grid-order tie breaking. The chosen configuration is refitted on train+validation and evaluated once on the independent test partition.

The separate jitter sweep uses seven values from 1e-12 to 0.1 over three paired 70/30 splits per dataset (42 fits), with C=4, gamma=0.1, lambda_N=0.08, rho_N=0.18, tau_N=0.35. Split standard deviations are descriptive: the repeated splits overlap and are not independent replications.

All sensitivity fits use an 80-iteration outer cap, a projected-gradient tolerance of 1e-4, a relative-objective tolerance of 1e-7, and SVC tolerance 1e-5. The initial inner cap was 50,000 iterations. Under a uniform documented retry rule, the four factorial configurations with any initial capped inner solve were refitted from uniform alpha with an inner cap of 200,000. Their initial records are preserved under pilot_inner_cap50k and the final per-row cap is recorded in factorial_grid.csv. All four retries resolved the inner cap; validation scores and the selected configurations were unchanged to floating-point precision. A relative-objective stop or outer cap does not certify a small stationarity residual. Convergence conclusions must use the recorded residuals and termination causes.

One-dimensional factorial plots marginalize over 81 joint configurations at each parameter level; shaded bands are min–max configuration ranges, not confidence intervals. Grid observations are not treated as independent datasets.

dataset,grid_evaluations,failures,outer_caps,projected_tolerance_stops,relative_objective_stops,line_search_failures,any_inner_solver_failure,validation_BA_min,validation_BA_max,median_final_residual,grid_seconds_sum,jitter_evaluations,jitter_BA_mean_min,jitter_BA_mean_max
Wine-01,243,0,42,12,189,0,0,0.5,0.9583333333333331,0.0040488257797122,46.908470600028515,21,1.0,1.0
WDBC,243,0,143,0,100,0,0,0.8231247952833278,0.962659679004258,0.0165728910062917,233.88507249951363,21,0.9698208722741434,0.9750292056074766


Selected-model held-out results:

dataset,C,gamma,lambda,rho,tau,validation_BA,independent_test_BA,independent_test_accuracy,termination,projected_gradient_residual
Wine-01,0.25,0.1,10.0,0.001,0.001,0.9583333333333331,0.9642857142857144,0.9615384615384616,relative_objective_tolerance,0.0003446357872562
WDBC,4.0,0.1,0.001,0.1,0.001,0.962659679004258,0.9692460317460316,0.9736842105263158,relative_objective_tolerance,0.0351806490719541


The selected-model Lipschitz-bound table evaluates a sufficient analytic bound for the actual normalized objective, using mu_beta=epsilon_K. These bounds may be extremely conservative and cannot establish that the true Lipschitz constants are moderate. The jitter sweep also records observed restricted curvature and full-Hessian conditioning; those floating-point diagnostics are not proofs of a uniform bound over the simplex.

No result here addresses missing raw PercePiano target ratings, original musical feature groups, or its permutation importance. No universal robust parameter region or statistically significant accuracy advantage is claimed from this exploratory design.