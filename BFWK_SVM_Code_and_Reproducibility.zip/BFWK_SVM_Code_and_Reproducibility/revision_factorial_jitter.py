"""REAL exploratory sensitivity runs; independent of archived benchmark tables.

Full 3^5 Cartesian design on two prespecified datasets and fixed train/validation/
test splits. Grid performance uses validation only. Only the selected grid
configuration is refitted on train+validation and scored on the untouched test.
Jitter is a separate paired 3-split sweep at fixed prespecified coefficients.
No confidence intervals are inferred from hyperparameter-grid configurations.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json, os, platform, sys, time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd
import scipy, scipy.linalg
import sklearn
from sklearn.datasets import load_wine, load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from threadpoolctl import threadpool_limits
import revision_core as core

BASE=Path(__file__).resolve().parent
OUT=BASE/"results_revision"
SEED=20261020
GRID={"C":[.25,4.,64.],"gamma":[.01,.1,1.],
      "lambda":[.001,.1,10.],"rho":[.001,.1,10.],"tau":[.001,.1,10.]}
JITTERS=[1e-12,1e-10,1e-8,1e-6,1e-4,1e-2,1e-1]
CAP=80


def datasets():
    w=load_wine();keep=np.flatnonzero(np.isin(w.target,[0,1]))
    b=load_breast_cancer()
    return {"Wine-01":(w.data[keep],np.where(w.target[keep]==1,1,-1),keep,"scikit-learn load_wine, original classes 0 versus 1"),
            "WDBC":(b.data,np.where(b.target==1,1,-1),np.arange(len(b.target)),"scikit-learn load_breast_cancer, all observations")}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path,obj):
    path.write_text(json.dumps(obj,indent=2,default=lambda v:v.item() if isinstance(v,np.generic) else v),encoding="utf-8")


def append(path,row):
    new=not path.exists()
    with path.open("a",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(row));
        if new:w.writeheader()
        w.writerow(row)


def split_data(X,y,seed,three_way=True):
    all_idx=np.arange(len(y))
    development,test=train_test_split(all_idx,test_size=.2 if three_way else .3,stratify=y,random_state=seed)
    if three_way:
        train,validation=train_test_split(development,test_size=.25,stratify=y[development],random_state=seed+1)
        return train,validation,test
    return development,test


def scaled(X,train,other):
    scaler=StandardScaler().fit(X[train]); A=scaler.transform(X[train]);B=scaler.transform(X[other])
    keep=np.std(A,axis=0)>1e-10
    return A[:,keep],B[:,keep]


def diagnostic(model):
    return {"objective":model["objective"],"dual_value":model["dual_value"],
            "outer_iterations":len(model["history"]),"evaluations":model["evaluations"],
            "termination":model["termination"],"projected_gradient_residual":model["projected_gradient_residual"],
            "dual_fit_status":model["dual_fit_status"],"free_sv_kkt_error":model["free_sv_kkt_error"],
            "dual_equality_residual":model["dual_equality_residual"],"seconds":model["seconds"]}


def numerical_validation():
    X,y,_,_=datasets()["Wine-01"];tr,te=split_data(X,y,SEED,False)
    X,_=scaled(X,tr,te);y=y[tr]
    q,M=core.compute_q_M(X,y);a=np.full(X.shape[1],1/X.shape[1]);rng=np.random.default_rng(SEED)
    h=rng.normal(size=len(a));h-=h.mean();h/=np.linalg.norm(h);eps=1e-5
    args=(4.,.1,q,M,.08,.18,.35,"normalized",1e-4,1e-9,200000)
    ev=core._evaluate(X,y,a,*args)
    plus=core._evaluate(X,y,a+eps*h,*args);minus=core._evaluate(X,y,a-eps*h,*args)
    finite=(plus["J"]-minus["J"])/(2*eps);analytic=float(ev["g"]@h)
    raw_args=(4.,.1,q,M,*core.raw_coefficients((.08,.18,.35),len(y)),"raw",1e-4,1e-9,200000)
    raw=core._evaluate(X,y,a,*raw_args)
    result={"source":"Wine-01 training partition; numerical verification, not a predictive experiment",
            "finite_difference":finite,"analytic_directional_gradient":analytic,"absolute_error":abs(finite-analytic),
            "normalized_vs_mapped_raw_value_error":abs(ev["J"]-raw["J"]/len(y)),
            "normalized_vs_mapped_raw_gradient_max_error":float(np.max(np.abs(ev["g"]-raw["g"]/len(y)))),
            "inner_tolerance":1e-9,"jitter":1e-4}
    result["passed"]=result["absolute_error"]<2e-3 and result["normalized_vs_mapped_raw_value_error"]<1e-10
    write_json(OUT/"core_numerical_validation.json",result)
    if not result["passed"]:raise RuntimeError(f"Numerical validation failed: {result}")
    return result


def factorial(names):
    path=OUT/"factorial_grid.csv"; selected=[];plans={}
    existing=set()
    if path.exists():
        old=pd.read_csv(path)
        existing={(r.dataset,int(r.grid_id)) for r in old.itertuples()}
    for name in names:
        X,y,ids,source=datasets()[name];tr,va,te=split_data(X,y,SEED,True)
        A,B=scaled(X,tr,va);qM=core.compute_q_M(A,y[tr])
        plans[name]={"source":source,"sample_sha256":hashlib.sha256(X.tobytes()+y.tobytes()).hexdigest(),
                     "train_original_ids":ids[tr].tolist(),"validation_original_ids":ids[va].tolist(),"test_original_ids":ids[te].tolist()}
        write_json(OUT/"factorial_splits.json",plans)
        for grid_id,values in enumerate(itertools.product(*GRID.values()),1):
            if (name,grid_id) in existing:continue
            C,g,lam,rho,tau=values;t0=time.perf_counter()
            try:
                model=core.fit_bfwk(A,y[tr],C,g,lam,rho,tau,max_outer=CAP,q_M=qM)
                m=core.metrics(y[va],core.predict_kernel(model,B))
                row={"dataset":name,"grid_id":grid_id,**dict(zip(GRID,values)),"jitter":core.DEFAULT_JITTER,
                     "n_train":len(tr),"n_validation":len(va),"n_test_untouched":len(te),"d":A.shape[1],
                     "validation_BA":m["BalancedAccuracy"],"validation_accuracy":m["Accuracy"],"status":"completed",**diagnostic(model)}
            except Exception as exc:
                row={"dataset":name,"grid_id":grid_id,**dict(zip(GRID,values)),"jitter":core.DEFAULT_JITTER,
                     "n_train":len(tr),"n_validation":len(va),"n_test_untouched":len(te),"d":A.shape[1],
                     "validation_BA":float("nan"),"validation_accuracy":float("nan"),"status":"failed:"+repr(exc),
                     **dict.fromkeys(["objective","dual_value","outer_iterations","evaluations","termination","projected_gradient_residual","dual_fit_status","free_sv_kkt_error","dual_equality_residual"],float("nan")),"seconds":time.perf_counter()-t0}
            append(path,row)
            if grid_id%27==0:print(f"FACTORIAL {name} {grid_id}/243; latest validation BA={row['validation_BA']:.4f}",flush=True)
        frame=pd.read_csv(path);f=frame[(frame.dataset==name)&(frame.status=="completed")]
        best=f.sort_values(["validation_BA","grid_id"],ascending=[False,True]).iloc[0]
        dev=np.r_[tr,va];A,T=scaled(X,dev,te)
        model=core.fit_bfwk(A,y[dev],best.C,best.gamma,best["lambda"],best.rho,best.tau,max_outer=CAP)
        m=core.metrics(y[te],core.predict_kernel(model,T))
        selected.append({"dataset":name,"selection_rule":"maximum validation BA, then earliest grid ID", "grid_id":int(best.grid_id),
                         **{k:float(best[k]) for k in GRID},"validation_BA":float(best.validation_BA),
                         "independent_test_BA":m["BalancedAccuracy"],"independent_test_accuracy":m["Accuracy"],
                         "n_refit":len(dev),"n_test":len(te),**diagnostic(model)})
        np.savez_compressed(OUT/f"factorial_selected_{name}_weights.npz",alpha=model["alpha"],q=model["q"],M=model["M"])
    pd.DataFrame(selected).to_csv(OUT/"factorial_selected_test.csv",index=False)


def curvature(model):
    X=model["X"];y=model["y"];K=core.weighted_kernel(X,X,model["alpha"],model["gamma"])
    Z=scipy.linalg.null_space(y[None,:].astype(float))
    Q=(y[:,None]*y[None,:])*K
    restricted=Z.T@Q@Z
    bounds=scipy.linalg.eigvalsh(restricted,subset_by_index=[0,0],check_finite=False)
    maximum=float(scipy.linalg.eigvalsh(Q,subset_by_index=[len(y)-1,len(y)-1],check_finite=False)[0])
    minimum=float(scipy.linalg.eigvalsh(Q,subset_by_index=[0,0],check_finite=False)[0])
    eps=model["jitter"]
    return {"restricted_mu_observed":float(bounds[0]+eps),"full_min_eigenvalue":minimum+eps,
            "full_max_eigenvalue":maximum+eps,"spectral_condition":float((maximum+eps)/max(minimum+eps,np.finfo(float).tiny)),
            "relative_gram_frobenius_change":float(eps*np.sqrt(len(y))/np.linalg.norm(K,"fro")),
            "guaranteed_mu_exact_arithmetic":eps}


def jitter(names):
    path=OUT/"jitter_sensitivity.csv";plans={};existing=set()
    if path.exists():
        old=pd.read_csv(path);existing={(r.dataset,int(r.split_seed),float(r.jitter)) for r in old.itertuples()}
    for name in names:
        X,y,ids,source=datasets()[name]
        for seed in (SEED,SEED+101,SEED+202):
            tr,te=split_data(X,y,seed,False);A,T=scaled(X,tr,te);qM=core.compute_q_M(A,y[tr])
            plans[f"{name}:{seed}"]={"train_original_ids":ids[tr].tolist(),"test_original_ids":ids[te].tolist()}
            write_json(OUT/"jitter_splits.json",plans)
            for eps in JITTERS:
                if (name,seed,eps) in existing:continue
                model=core.fit_bfwk(A,y[tr],4.,.1,.08,.18,.35,jitter=eps,max_outer=CAP,q_M=qM)
                m=core.metrics(y[te],core.predict_kernel(model,T))
                row={"dataset":name,"split_seed":seed,"jitter":eps,"C":4.,"gamma":.1,"lambda":.08,"rho":.18,"tau":.35,
                     "n_train":len(tr),"n_test":len(te),"d":A.shape[1],"test_BA":m["BalancedAccuracy"],"test_accuracy":m["Accuracy"],
                     **diagnostic(model),**curvature(model)}
                append(path,row)
            print(f"JITTER {name} paired split {seed} completed 7 values",flush=True)


def plots():
    df=pd.read_csv(OUT/"factorial_grid.csv");profiles=[]
    fig,axs=plt.subplots(2,5,figsize=(15,6),sharey=True)
    for i,(name,g) in enumerate(df.groupby("dataset",sort=False)):
        for j,key in enumerate(GRID):
            p=g.groupby(key).validation_BA.agg(["mean","min","max"])
            axs[i,j].semilogx(p.index,p["mean"],"o-",label="marginal mean")
            axs[i,j].fill_between(p.index,p["min"],p["max"],alpha=.15,label="configuration range")
            axs[i,j].set_xlabel(key);axs[i,j].set_title(name);axs[i,j].grid(alpha=.2)
            if j==0:axs[i,j].set_ylabel("Validation balanced accuracy")
            for value,r in p.iterrows():profiles.append({"dataset":name,"parameter":key,"value":value,**r.to_dict()})
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc="lower center",ncol=2)
    fig.suptitle("Full factorial sensitivity: each point averages 81 joint configurations; bands are ranges, not CIs")
    fig.tight_layout(rect=(0,.06,1,.96));fig.savefig(OUT/"factorial_sensitivity.png",dpi=180);fig.savefig(OUT/"factorial_sensitivity.pdf");plt.close(fig)
    pd.DataFrame(profiles).to_csv(OUT/"factorial_marginal_profiles.csv",index=False)
    j=pd.read_csv(OUT/"jitter_sensitivity.csv");fig,axs=plt.subplots(1,3,figsize=(13,3.6))
    for name,g in j.groupby("dataset",sort=False):
        p=g.groupby("jitter").agg(BA=("test_BA","mean"),sd=("test_BA","std"),residual=("projected_gradient_residual","mean"),condition=("spectral_condition","median"))
        axs[0].errorbar(p.index,p.BA,yerr=p.sd,marker="o",label=name)
        axs[1].loglog(p.index,p.residual,"o-",label=name);axs[2].loglog(p.index,p.condition,"o-",label=name)
    axs[0].set_xscale("log");axs[0].set_ylabel("Held-out BA (mean ± split SD)")
    axs[1].set_ylabel("Mean final projected-gradient residual");axs[2].set_ylabel("Median full-Hessian condition number")
    for ax in axs:ax.set_xlabel("Fixed absolute jitter");ax.grid(alpha=.2);ax.legend()
    fig.suptitle("Prespecified jitter sweep: 3 paired 70/30 splits; split SD is descriptive, not an independent-sample CI")
    fig.tight_layout();fig.savefig(OUT/"jitter_sensitivity.png",dpi=180);fig.savefig(OUT/"jitter_sensitivity.pdf");plt.close(fig)
    j.groupby(["dataset","jitter"]).agg(BA_mean=("test_BA","mean"),BA_split_sd=("test_BA","std"),residual_mean=("projected_gradient_residual","mean"),condition_median=("spectral_condition","median"),seconds_mean=("seconds","mean")).to_csv(OUT/"jitter_summary.csv")


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--pilot",action="store_true");parser.add_argument("--plots-only",action="store_true");args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.plots_only:return plots()
    with threadpool_limits(limits=1):
        check=numerical_validation();print("Numerical validation",check,flush=True)
        if args.pilot:
            X,y,_,_=datasets()["WDBC"];tr,va,te=split_data(X,y,SEED,True);A,B=scaled(X,tr,va)
            t0=time.perf_counter();m=core.fit_bfwk(A,y[tr],4,.1,max_outer=CAP)
            pilot={"dataset":"WDBC","n_train":len(tr),"d":A.shape[1],"elapsed":time.perf_counter()-t0,**diagnostic(m)}
            write_json(OUT/"timing_pilot.json",pilot);print(pilot,flush=True);return
        protocol={"started_UTC":datetime.now(timezone.utc).isoformat(),"seed":SEED,"core_version":core.CORE_VERSION,
                  "core_sha256":sha(BASE/"revision_core.py"),"driver_sha256":sha(__file__),"python":sys.version,
                  "numpy":np.__version__,"scipy":scipy.__version__,"sklearn":sklearn.__version__,"platform":platform.platform(),
                  "BLAS_threads":1,"datasets":["Wine-01","WDBC"],"factorial_grid":GRID,"grid_points_per_dataset":243,
                  "factorial_split":"60% train /20% validation /20% independent test; stratified fixed seeds",
                  "factorial_objective":"V_epsilon/n + lambda_N/2 ||alpha||² + rho_N/2 alpha'Malpha - tau_N q'alpha",
                  "default_jitter":core.DEFAULT_JITTER,"jitter_is_new_default_not_historical":True,
                  "max_outer":CAP,"svc_tolerance":1e-5,"svc_max_iter":50000,"eps_alpha":1e-4,"eps_J":1e-7,
                  "jitter_sweep":JITTERS,"jitter_splits":"3 paired 70/30 stratified splits; overlapping samples",
                  "sensitivity_scope":"Exploratory two-task sensitivity; does not replace nested 13-task benchmark or certify convergence at the cap",
                  "factorial_plot_bands":"Range across joint grid configurations, not statistical confidence intervals"}
        write_json(OUT/"factorial_jitter_protocol.json",protocol)
        factorial(["Wine-01","WDBC"]);jitter(["Wine-01","WDBC"]);plots()
        protocol["completed_UTC"]=datetime.now(timezone.utc).isoformat();write_json(OUT/"factorial_jitter_protocol.json",protocol)
        print("COMPLETE factorial=486 evaluations +2 refits; jitter=42 fits",flush=True)


if __name__=="__main__":main()
