# Human-cohort data and target audit

No classifier is fitted here. The analysis is restricted to 1,073 human source segments; 129 Score/Score2 controls are excluded. All target comparisons are descriptive. Correlations are Spearman rank associations, without significance tests. No global standardization is used.

Actual release counts: 14934 raw rows; 208 invalid rows; 2,200 exact duplicate records removed; 12,526 distinct rating vectors; 11,118 rater-by-segment contributions after averaging distinct repeat ratings. The release contains 63 distinct anonymized rater codes, which is a code count rather than a verified count of experts. The paper's 12,652 annotations/53 experts are not forced onto these data.

The new composite uses official ordinal labels 13 (Spacious), 15 (Dramatic/expressive), 18 (Imaginative), 19 (Convincing). Higher values point toward these named poles; they do not define a common musical-quality scale. Label 14 is excluded because the official README and paper disagree on its direction. The old manuscript four-attribute mapping and historical 0.812 are not reconstructed.

Primary statistical unit: one rater per segment. A full 19-dimensional vector is the exact-duplicate key; repeated equal values in one attribute are retained if the other attributes make the complete vectors distinct. Distinct vectors from the same rater/segment are averaged attribute by attribute, then z=(rating-1)/6. Means and sample variances use these rater contributions, with ddof=1. The all-valid-row comparator instead aggregates valid released records before duplicate removal.

All four chosen labels have at least two valid rater contributions in every human segment. Single-label targets use their own n>=2 eligibility; IVW and equal-weight composites require all four labels. Training-fold standardized composites and train-only median thresholds belong to the separate modeling analysis and are not calculated from full-cohort moments here.

The official mapper would merge 13 pairs of Score and Score2 controls, whereas the released JSON/MIDI source IDs retain them. The primary tables preserve all 1,202 source IDs, and all 1,202 match unique normalized MIDI IDs. This ambiguity does not alter the 1,073 human cohort.

## Independent arithmetic spot checks

Two human segments from different source families, including one with repeated-record content, were recomputed directly from the raw CSV without importing revision_percepiano_ratings.py. For each segment, first remove invalid rows and exact full-vector duplicates; average distinct vectors within rater; then compute mean=sum(z)/n and sample variance=[sum(z^2)-sum(z)^2/n]/(n-1).

### Beethoven_WoO80_thema_8bars_11_1

5 valid source rows; 5 unique full rating vectors; 5 rater contributions.

| Rater code | Distinct full vectors | z13 | z15 | z18 | z19 |
|---|---:|---:|---:|---:|---:|
| 201 | 1 | 0.000000000 | 0.500000000 | 0.333333333 | 0.333333333 |
| 202 | 1 | 0.500000000 | 0.833333333 | 0.833333333 | 0.000000000 |
| 203 | 1 | 0.666666667 | 0.666666667 | 0.666666667 | 0.500000000 |
| 206 | 1 | 0.333333333 | 0.333333333 | 0.333333333 | 0.333333333 |
| 209 | 1 | 0.333333333 | 0.333333333 | 0.333333333 | 0.500000000 |

| Label | n | sum(z) | sum(z²) | mean | sample variance | max table difference |
|---|---:|---:|---:|---:|---:|---:|
| 13 | 5 | 1.83333333333 | 0.916666666667 | 0.366666666667 | 0.0611111111111 | 5.55e-17 |
| 15 | 5 | 2.66666666667 | 1.61111111111 | 0.533333333333 | 0.0472222222222 | 7.63e-17 |
| 18 | 5 | 2.5 | 1.47222222222 | 0.5 | 0.0555555555556 | 8.33e-17 |
| 19 | 5 | 1.66666666667 | 0.722222222222 | 0.333333333333 | 0.0416666666667 | 8.33e-17 |

### Schubert_D960_mv2_8bars_12_1

17 valid source rows; 12 unique full rating vectors; 8 rater contributions.

| Rater code | Distinct full vectors | z13 | z15 | z18 | z19 |
|---|---:|---:|---:|---:|---:|
| 101 | 1 | 0.333333333 | 0.333333333 | 0.500000000 | 0.500000000 |
| 109 | 2 | 0.416666667 | 0.500000000 | 0.500000000 | 0.250000000 |
| 121 | 1 | 0.666666667 | 0.833333333 | 0.833333333 | 0.833333333 |
| 70 | 1 | 0.666666667 | 0.333333333 | 0.833333333 | 0.833333333 |
| 71 | 2 | 0.583333333 | 0.583333333 | 0.333333333 | 0.333333333 |
| 81 | 1 | 0.666666667 | 0.333333333 | 0.666666667 | 0.666666667 |
| 91 | 2 | 0.916666667 | 0.833333333 | 0.833333333 | 0.833333333 |
| 97 | 2 | 0.750000000 | 0.833333333 | 0.666666667 | 0.500000000 |

| Label | n | sum(z) | sum(z²) | mean | sample variance | max table difference |
|---|---:|---:|---:|---:|---:|---:|
| 13 | 8 | 5 | 3.36111111111 | 0.625 | 0.0337301587302 | 3.47e-17 |
| 15 | 8 | 4.58333333333 | 3.00694444444 | 0.572916666667 | 0.054439484127 | 8.33e-17 |
| 18 | 8 | 5.16666666667 | 3.58333333333 | 0.645833333333 | 0.0352182539683 | 5.55e-17 |
| 19 | 8 | 4.75 | 3.20138888889 | 0.59375 | 0.054439484127 | 8.33e-17 |

## Plot specification

target_human_sensitivity.pdf has two vector pages: page 1 rank-correlation heatmap (9.5 x 9.5 in); page 2 four-panel sensitivity comparison (9.5 x 9 in). The PNG is a vertical combined preview (1,900 x 3,700 px at 200 dpi). Main text/tick fonts are 12–15 pt before reduction. Difference summaries retain negative, positive and exactly-zero values. Figure C includes all observed differences; no outliers are removed.

## Input integrity

All source/target input hashes were checked before and after plotting; the inputs are unchanged.

```json
{
  "C:\\Users\\LPP\\Documents\\Codex\\2026-10-20\\referenced-chatgpt-conversation-this-is-an\\outputs\\BFWK_SVM_InformationSciences_Revision\\results_percepiano\\target_continuous.csv": "a7acedf5d109d1e9b2f21f9fa6d3f03a15e6b3329d0a67292eb8cadf80f0d9c9",
  "C:\\Users\\LPP\\Documents\\Codex\\2026-10-20\\referenced-chatgpt-conversation-this-is-an\\outputs\\BFWK_SVM_InformationSciences_Revision\\results_percepiano\\target_basis.csv": "ce3ddb334780d50831d998793e9175086bfc0d376143a9c9edf362da9f5c751d",
  "C:\\Users\\LPP\\Documents\\Codex\\2026-10-20\\referenced-chatgpt-conversation-this-is-an\\outputs\\BFWK_SVM_InformationSciences_Revision\\results_percepiano\\ratings_audit.json": "21e7333d6740a8de22be956cd4521aecb08d35e4191ee0988518ddaba882a182",
  "C:\\Users\\LPP\\Documents\\Codex\\2026-10-20\\referenced-chatgpt-conversation-this-is-an\\outputs\\BFWK_SVM_InformationSciences_Revision\\results_percepiano\\ratings_segment_metadata.csv": "05e3ce1cb67b75d0ed1b7ec7bdbe0c75ca412119592d18c80a40c6c204a60e9b",
  "work\\percepiano_reproduction_check\\source\\labels\\total_2rounds.csv": "96a61ce89a311979c60933073957420a7da3cf229fb8d1270a58b044ac441d3d"
}
```
