"""Verify and extract the fixed official public PercePiano release.

By default use the archive included under source_data. If it is absent, download
the same fixed public commit. No downloaded source code is executed.
"""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,urllib.request,zipfile
COMMIT='e672299b8661f63802cd5cd73bb3c76218a13029'
SHA256='676b2562f0b78890f1f29e884b6dcca6a9351c50f3e621c3f2a1fcf5483c633a'
HERE=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--archive',type=Path,default=HERE/'source_data'/f'PercePiano-{COMMIT}.zip')
    p.add_argument('--output',type=Path,default=HERE/'source_data/PercePiano')
    args=p.parse_args();archive=args.archive
    if not archive.exists():
        archive.parent.mkdir(parents=True,exist_ok=True)
        req=urllib.request.Request(f'https://codeload.github.com/JonghoKimSNU/PercePiano/zip/{COMMIT}',headers={'User-Agent':'BFWK-SVM-public-data-analysis'})
        with urllib.request.urlopen(req,timeout=90) as response:archive.write_bytes(response.read())
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==SHA256,'Official archive hash mismatch'
    target=args.output.resolve();target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in z.infolist():
            parts=PurePosixPath(item.filename).parts[1:]
            if not parts:continue
            path=target.joinpath(*parts).resolve()
            assert path.is_relative_to(target),'Archive path escaped target'
            if item.is_dir():path.mkdir(parents=True,exist_ok=True)
            else:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(z.read(item))
    print(json.dumps({'commit':COMMIT,'sha256':SHA256,'output':str(target)},indent=2))
if __name__=='__main__':main()
