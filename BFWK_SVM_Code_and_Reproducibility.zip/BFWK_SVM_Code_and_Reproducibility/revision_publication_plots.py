"""Publication-sized figures from existing measured CSVs; no experiments rerun."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullLocator

OUT=Path(__file__).resolve().parent/"results_revision"
plt.rcParams.update({"font.size":12,"axes.labelsize":12,"axes.titlesize":13,
                     "xtick.labelsize":11,"ytick.labelsize":11,"legend.fontsize":11,
                     "pdf.fonttype":42,"ps.fonttype":42})


def save(fig,stem):
    fig.savefig(OUT/f"{stem}.pdf",bbox_inches="tight",pad_inches=.05)
    fig.savefig(OUT/f"{stem}.png",dpi=200,bbox_inches="tight",pad_inches=.05)
    plt.close(fig)


def factorial():
    data=pd.read_csv(OUT/"factorial_grid.csv")
    keys=["C","gamma","lambda","rho","tau"]
    axis_labels=[r"$C$",r"$\gamma$",r"$\lambda_N$",r"$\rho_N$",r"$\tau_N$"]
    for name,g in data.groupby("dataset",sort=False):
        fig,axes=plt.subplots(2,3,figsize=(9,6),sharey=True)
        for ax,key,label in zip(axes.flat,keys,axis_labels):
            p=g.groupby(key).validation_BA.agg(["mean","min","max"])
            ax.semilogx(p.index,p["mean"],"o-",lw=1.8,ms=5,label="Marginal mean")
            ax.fill_between(p.index,p["min"],p["max"],alpha=.18,label="Configuration range")
            ax.xaxis.set_major_locator(FixedLocator(p.index.to_numpy()))
            ax.set_xticklabels([f"{v:g}" for v in p.index]);ax.xaxis.set_minor_locator(NullLocator())
            ax.set_xlabel(label);ax.grid(alpha=.23);ax.set_ylim(.48,1.0)
        axes[0,0].set_ylabel("Validation balanced accuracy")
        axes[1,0].set_ylabel("Validation balanced accuracy")
        legend=axes[1,2];legend.axis("off")
        handles,legend_labels=axes[0,0].get_legend_handles_labels()
        legend.legend(handles,legend_labels,loc="upper center",frameon=False,fontsize=12)
        legend.text(.06,.46,"243 joint configurations\n81 per factor level\n\nBand: configuration\nminimum to maximum\n(no confidence interval)",
                    transform=legend.transAxes,va="top",fontsize=11.5,linespacing=1.35)
        fig.suptitle(f"{name}: full factorial sensitivity",fontsize=14,y=.995)
        fig.tight_layout(rect=(0,0,1,.97),h_pad=1.2,w_pad=1.0)
        save(fig,f"factorial_sensitivity_{name}")


def jitter():
    data=pd.read_csv(OUT/"jitter_sensitivity.csv")
    fig,axs=plt.subplots(1,3,figsize=(9,3.7))
    for name,g in data.groupby("dataset",sort=False):
        p=g.groupby("jitter").agg(BA=("test_BA","mean"),sd=("test_BA","std"),residual=("projected_gradient_residual","mean"),condition=("spectral_condition","median"))
        axs[0].errorbar(p.index,p.BA,yerr=p.sd,marker="o",ms=4,lw=1.5,capsize=2,label=name)
        axs[1].loglog(p.index,p.residual,"o-",ms=4,lw=1.5,label=name)
        axs[2].loglog(p.index,p.condition,"o-",ms=4,lw=1.5,label=name)
    axs[0].set_xscale("log");axs[0].set_ylabel("Held-out balanced accuracy")
    axs[1].set_ylabel("Mean final residual");axs[2].set_ylabel("Median condition number")
    for ax,title in zip(axs,["(a) Prediction","(b) Stationarity","(c) Conditioning"]):
        ax.set_title(title);ax.set_xlabel(r"Fixed jitter $\varepsilon_K$");ax.grid(alpha=.23)
        ax.xaxis.set_major_locator(FixedLocator([1e-12,1e-8,1e-4,1e-1]));ax.xaxis.set_minor_locator(NullLocator())
    axs[0].legend(loc="lower left",fontsize=10,framealpha=.85)
    fig.tight_layout(rect=(0,.07,1,1),w_pad=1.25)
    fig.text(.5,.015,"Three paired splits; prediction error bars show split SD, not confidence intervals.",ha="center",fontsize=10.5)
    save(fig,"jitter_sensitivity")


def traces():
    data=pd.read_csv(OUT/"jitter_iteration_histories.csv")
    seed=int(data.split_seed.min());fig,axs=plt.subplots(1,2,figsize=(9,3.8))
    for ax,name in zip(axs,["Wine-01","WDBC"]):
        for eps,g in data[(data.dataset==name)&(data.split_seed==seed)].groupby("jitter"):
            ax.semilogy(g.iteration,np.maximum(g.residual,1e-12),lw=1.6,label=f"{eps:g}")
        ax.set_xlabel("Outer iteration");ax.set_ylabel("Projected-gradient residual")
        ax.set_title(name);ax.grid(alpha=.23);ax.legend(title=r"$\varepsilon_K$",fontsize=9.5,title_fontsize=11,ncol=1)
    fig.tight_layout(rect=(0,.07,1,1),w_pad=1.2)
    fig.text(.5,.015,"First prespecified paired split; a stopping decision does not certify stationarity.",ha="center",fontsize=10.5)
    save(fig,"jitter_iteration_traces")


if __name__=="__main__":
    factorial();jitter();traces()
    print("Publication figures regenerated from existing CSVs; experiment records unchanged.")
