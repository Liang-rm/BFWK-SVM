#!/usr/bin/env python3
"""New, bounded revision experiments; never overwrite supplied benchmark results.

Run with Python plus numpy/pandas/scipy/scikit-learn/statsmodels/matplotlib.
The supplied 13-task fold CSV is analysed as historical evidence. New experiments
use revision_core.py (fixed kernel jitter and explicitly normalized objective).
"""
from __future__ import annotations

import os
for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ.setdefault(_key, '1')

import argparse
import json
import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr
from sklearn.datasets import load_breast_cancer, load_digits, load_iris, load_wine
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm

BASE = Path(__file__).resolve().parent
OUT = BASE / 'results_revision'
OUT.mkdir(exist_ok=True)
SEED = 20261020
MAX_N = 360
N_FOLDS = 3
MAX_OUTER = 100
PAR = dict(C=1.0, gamma=1.0, lam=0.08, rho=0.18, tau=0.35,
           objective='normalized', jitter=1e-6, max_outer=MAX_OUTER,
           svc_tol=1e-7,min_step=2**-20,eps_alpha=1e-4,eps_J=1e-7,svc_max_iter=50000)
STRESS_NAMES = ['WDBC', 'Wine-01', 'Iris-12', 'Digits-35', 'Spector', 'ANES96']


def numeric_tasks():
    """Eight original tasks available in distributable package data, no download."""
    out = {}
    def add(name, X, y):
        out[name] = (pd.DataFrame(X).reset_index(drop=True), np.asarray(y, dtype=int))
    b = load_breast_cancer(as_frame=True)
    add('WDBC', b.data, np.where(b.target == 1, 1, -1))
    b = load_wine(as_frame=True); mask = b.target.isin([0, 1])
    add('Wine-01', b.data.loc[mask], np.where(b.target.loc[mask] == 1, 1, -1))
    b = load_iris(as_frame=True); mask = b.target.isin([1, 2])
    add('Iris-12', b.data.loc[mask], np.where(b.target.loc[mask] == 2, 1, -1))
    b = load_digits(as_frame=True); mask = b.target.isin([3, 5])
    add('Digits-35', b.data.loc[mask], np.where(b.target.loc[mask] == 5, 1, -1))
    b = sm.datasets.spector.load_pandas()
    add('Spector', b.exog, np.where(b.endog > 0, 1, -1))
    b = sm.datasets.modechoice.load_pandas()
    add('ModeChoice', b.exog, np.where(b.endog > 0, 1, -1))
    b = sm.datasets.fair.load_pandas()
    add('Fair-Affair', b.exog, np.where(b.endog > 0, 1, -1))
    b = sm.datasets.anes96.load_pandas(); mask = b.endog.to_numpy() != 3
    add('ANES96', b.exog.loc[mask], np.where(b.endog.to_numpy()[mask] >= 4, 1, -1))
    return out


def original_subsample(X, y, max_n=1000, seed=2026):
    """Reproduce the supplied benchmark's stratified_subsample exactly."""
    if len(y) <= max_n:
        return X.reset_index(drop=True), y.copy()
    rng = np.random.default_rng(seed)
    idxs = []
    for cls in [-1, 1]:
        ids = np.flatnonzero(y == cls)
        n_take = min(int(round(max_n * len(ids) / len(y))), len(ids))
        idxs.extend(rng.choice(ids, size=n_take, replace=False).tolist())
    idxs = np.array(sorted(set(idxs)))
    if len(idxs) > max_n:
        idxs = rng.choice(idxs, size=max_n, replace=False)
    elif len(idxs) < max_n:
        remain = np.setdiff1d(np.arange(len(y)), idxs)
        idxs = np.r_[idxs, rng.choice(remain, size=max_n-len(idxs), replace=False)]
    rng.shuffle(idxs)
    return X.iloc[idxs].reset_index(drop=True), y[idxs]


def holm(p):
    p = np.asarray(p, dtype=float); order = np.argsort(p)
    adjusted = np.minimum(1.0, np.maximum.accumulate((len(p)-np.arange(len(p))) * p[order]))
    out = np.empty(len(p)); out[order] = adjusted
    return out


def permutation_spearman(x, y, seed=SEED, reps=19999):
    x = np.asarray(x, float); y = np.asarray(y, float)
    rx, ry = rankdata(x), rankdata(y)
    rx -= rx.mean(); ry -= ry.mean()
    denom = np.linalg.norm(rx)*np.linalg.norm(ry)
    if denom == 0:
        return np.nan, np.nan
    observed = float(rx @ ry / denom)
    rng = np.random.default_rng(seed)
    perms = np.array([rng.permutation(ry) for _ in range(reps)])
    null = perms @ rx / denom
    p = (1 + np.count_nonzero(np.abs(null) >= abs(observed)-1e-14))/(reps+1)
    return observed, p


def analyse_properties(tasks):
    meta = pd.read_csv(BASE/'results/benchmark_datasets.csv').rename(columns={'Dataset':'dataset'})
    folds = pd.read_csv(BASE/'results/benchmark_fold_results.csv')
    pair = folds[folds.method.isin(['BFWK-SVM', 'RBF-SVM'])].pivot(
        index=['dataset', 'fold'], columns='method', values='BalancedAccuracy').reset_index()
    if len(meta)!=13 or len(pair)!=65 or pair[['BFWK-SVM','RBF-SVM']].isna().any().any():
        raise ValueError('Expected 13 complete original tasks with five paired folds each')
    if not (pair.groupby('dataset').size()==5).all():
        raise ValueError('Each original task must have five paired folds')
    pair['BA_gain'] = pair['BFWK-SVM'] - pair['RBF-SVM']
    pair.to_csv(OUT/'original13_paired_fold_gains.csv', index=False)
    gains = pair.groupby('dataset').agg(BA_gain=('BA_gain','mean'),
        gain_fold_sd=('BA_gain','std'), folds=('BA_gain','count'),
        BFWK_BA=('BFWK-SVM','mean'), RBF_BA=('RBF-SVM','mean')).reset_index()
    df = meta.merge(gains, on='dataset', validate='one_to_one')
    df['log10_N'] = np.log10(df.N)
    df['raw_d_over_n'] = df.RawFeatures / df.N
    df['minority_fraction'] = np.minimum(df.PositiveRate, 1-df.PositiveRate)
    df['imbalance'] = 1 - 2*df.minority_fraction
    df['mean_abs_feature_corr'] = np.nan
    df['mean_squared_feature_corr'] = np.nan
    df['raw_descriptor_status'] = 'raw data not recovered locally; no collinearity estimate'
    for name, (X, y) in tasks.items():
        X, y = original_subsample(X, y)
        m = df.dataset == name
        expected = int(df.loc[m,'N'].iloc[0])
        if len(y) != expected or X.shape[1] != int(df.loc[m,'RawFeatures'].iloc[0]):
            raise ValueError(f'Original descriptor mismatch: {name}')
        if not np.isclose(np.mean(y==1),df.loc[m,'PositiveRate'].iloc[0],atol=1e-12):
            raise ValueError(f'Original positive-class fraction mismatch: {name}')
        Z = SimpleImputer(strategy='median').fit_transform(X)
        Z = Z[:, Z.std(axis=0) > 1e-12]
        corr = np.corrcoef(Z, rowvar=False)
        v = corr[np.triu_indices(corr.shape[0], k=1)]
        df.loc[m,'mean_abs_feature_corr'] = np.mean(np.abs(v))
        df.loc[m,'mean_squared_feature_corr'] = np.mean(v*v)
        df.loc[m,'raw_descriptor_status'] = 'raw package data recovered; original cap/seed reproduced'
    df.to_csv(OUT/'original13_dataset_properties_and_gains.csv', index=False)
    rows = []
    properties = ['log10_N', 'RawFeatures', 'raw_d_over_n', 'imbalance']
    for i, prop in enumerate(properties):
        rho, p = permutation_spearman(df[prop], df.BA_gain, seed=SEED+i)
        rows.append(dict(cohort='all 13 original tasks', property=prop, n_tasks=len(df),
                         Spearman_rho=rho, permutation_p=p, permutations=19999))
    adjusted = holm([r['permutation_p'] for r in rows])
    for row, p in zip(rows, adjusted):
        row['Holm_p_within_cohort'] = p
    col = df.dropna(subset=['mean_abs_feature_corr'])
    subrows = []
    for i, prop in enumerate(['mean_abs_feature_corr', 'mean_squared_feature_corr']):
        rho,p = permutation_spearman(col[prop], col.BA_gain, seed=SEED+10+i)
        subrows.append(dict(cohort='8 locally recovered numeric tasks (exploratory subset)',
            property=prop, n_tasks=len(col), Spearman_rho=rho, permutation_p=p, permutations=19999))
    adjusted = holm([r['permutation_p'] for r in subrows])
    for row, p in zip(subrows, adjusted):
        row['Holm_p_within_cohort'] = p
    pd.DataFrame(rows+subrows).to_csv(OUT/'original13_property_correlations.csv', index=False)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(2,2,figsize=(10,7))
    axis_labels={'log10_N':'log10(sample count n)', 'RawFeatures':'Raw feature count d',
                 'raw_d_over_n':'Raw feature/sample ratio d/n', 'imbalance':'Class imbalance (0=balanced)'}
    for ax, prop, row in zip(axes.flat,properties,rows):
        ax.scatter(df[prop],100*df.BA_gain,color='#2166ac',s=30)
        ax.axhline(0,color='0.6',lw=.7)
        ax.set(xlabel=axis_labels[prop],ylabel='BFWK - RBF balanced accuracy (pp)',
            title=f"Spearman rho={row['Spearman_rho']:.2f}; Holm p={row['Holm_p_within_cohort']:.3f}")
    fig.suptitle('Original 13 tasks: exploratory dataset-property associations')
    fig.text(.5,.015,'Each point is one dataset; fold means and dataset identities are provided in the accompanying CSV.',ha='center',fontsize=9)
    fig.tight_layout(rect=(0,.045,1,.96)); fig.savefig(OUT/'original13_property_correlations.pdf'); fig.savefig(OUT/'original13_property_correlations.png',dpi=180); plt.close(fig)
    return df,rows+subrows


def cap_task(X,y,max_n=MAX_N,seed=SEED):
    if len(y) <= max_n:
        return X.reset_index(drop=True), y.copy()
    tr,_ = next(StratifiedShuffleSplit(n_splits=1,train_size=max_n,random_state=seed).split(X,y))
    return X.iloc[tr].reset_index(drop=True),y[tr]


def preprocess(Xtr,Xte):
    imp = SimpleImputer(strategy='median')
    A = imp.fit_transform(Xtr); B = imp.transform(Xte)
    keep = A.std(0)>1e-10; A = A[:,keep]; B = B[:,keep]
    sc = StandardScaler(); A = sc.fit_transform(A); B = sc.transform(B)
    return A,B


def augment(A,B,duplicate_fraction,noise_fraction,seed):
    """Nested duplicate/noise columns, same construction seed within each fold.

    A duplicate is x_j+0.05*z, z~N(0,1); source columns are drawn uniformly with
    replacement. All appended columns are scaled with training statistics only.
    """
    rng = np.random.default_rng(seed); d = A.shape[1]
    src = rng.integers(0,d,size=2*d)
    DA = A[:,src]+0.05*rng.normal(size=(len(A),2*d))
    DB = B[:,src]+0.05*rng.normal(size=(len(B),2*d))
    NA = rng.normal(size=(len(A),d)); NB = rng.normal(size=(len(B),d))
    kd = int(round(d*duplicate_fraction)); kn = int(round(d*noise_fraction))
    AA = np.column_stack([A,DA[:,:kd],NA[:,:kn]])
    BB = np.column_stack([B,DB[:,:kd],NB[:,:kn]])
    sc = StandardScaler(); AA = sc.fit_transform(AA); BB = sc.transform(BB)
    return AA,BB,kd,kn


def evaluate_pair(core,A,y,B,ytest,meta):
    rows=[]
    for method in ['RBF-SVM-jitter', 'BFWK-SVM-N-jitter']:
        start=time.perf_counter()
        if method.startswith('BFWK'):
            model=core.fit_bfwk(A,y,**PAR)
        else:
            model=core.fit_fixed_weight(A,y,C=PAR['C'],gamma=PAR['gamma'],
                alpha=np.full(A.shape[1],1/A.shape[1]),jitter=PAR['jitter'],svc_tol=PAR['svc_tol'])
        score=core.predict_kernel(model,B); pred=np.where(score>=0,1,-1)
        row=dict(meta,method=method,Accuracy=accuracy_score(ytest,pred),
                 BalancedAccuracy=balanced_accuracy_score(ytest,pred),seconds=time.perf_counter()-start,
                 d_augmented=A.shape[1],C=PAR['C'],gamma=PAR['gamma'],lambda_=PAR['lam'],
                 rho=PAR['rho'],tau=PAR['tau'],epsilon_K=PAR['jitter'],max_outer=MAX_OUTER,
                 n_train=len(y),n_test=len(ytest),
                 termination=model.get('termination','fixed-weight baseline'),
                 projected_gradient_residual=model.get('projected_gradient_residual',np.nan),
                 dual_fit_status=model.get('dual_fit_status',np.nan),
                 dual_equality_residual=model.get('dual_equality_residual',np.nan),
                 free_sv_kkt_error=model.get('free_sv_kkt_error',np.nan),
                 outer_iterations=len(model.get('history',[])),
                 svc_tol=PAR['svc_tol'],minimum_step=PAR['min_step'],
                 alpha_mass_original=float(np.asarray(model['alpha'])[:meta['d_base']].sum()))
        rows.append(row)
    return rows


def summaries_and_plots():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    for kind,filename,groups in [
        ('stress','stress6_fold_results.csv',['dataset','duplicate_fraction','noise_fraction','method']),
        ('learning','learning6_fold_results.csv',['dataset','train_fraction','method'])]:
        path=OUT/filename
        if not path.exists():
            continue
        df=pd.read_csv(path)
        summary=df.groupby(groups).agg(
            Accuracy_mean=('Accuracy','mean'),Accuracy_sd=('Accuracy','std'),
            BalancedAccuracy_mean=('BalancedAccuracy','mean'),BalancedAccuracy_sd=('BalancedAccuracy','std'),
            n_folds=('fold','count'),median_seconds=('seconds','median')).reset_index()
        summary.to_csv(OUT/f'{kind}6_summary.csv',index=False)
        pair=df.pivot(index=[c for c in groups if c!='method']+['fold'],
                      columns='method',values=['Accuracy','BalancedAccuracy'])
        pair.columns=['_'.join(c) for c in pair.columns]
        for metric in ['Accuracy','BalancedAccuracy']:
            pair[f'{metric}_paired_gain']=pair[f'{metric}_BFWK-SVM-N-jitter']-pair[f'{metric}_RBF-SVM-jitter']
        pair.reset_index().to_csv(OUT/f'{kind}6_paired_gains.csv',index=False)
        if kind=='stress':
            gain=pair.reset_index().groupby(['dataset','duplicate_fraction','noise_fraction']).agg(
                BA_gain_mean=('BalancedAccuracy_paired_gain','mean'),
                BA_gain_sd=('BalancedAccuracy_paired_gain','std'),
                BA_gain_min=('BalancedAccuracy_paired_gain','min'),
                BA_gain_max=('BalancedAccuracy_paired_gain','max'),
                BFWK_positive_folds=('BalancedAccuracy_paired_gain',lambda s:int((s>0).sum())),
                Accuracy_gain_mean=('Accuracy_paired_gain','mean')).reset_index()
            gain.to_csv(OUT/'stress6_paired_gain_summary.csv',index=False)
        for metric in ['Accuracy','BalancedAccuracy']:
            fig,axes=plt.subplots(2,3,figsize=(12,7),sharey=True)
            for ax,name in zip(axes.flat,STRESS_NAMES):
                one=summary[summary.dataset==name]
                if kind=='stress':
                    for noise,style in [(0.,'-'),(.5,'--'),(1.,':')]:
                        for method,color in [('BFWK-SVM-N-jitter','#b2182b'),('RBF-SVM-jitter','#2166ac')]:
                            p=one[(one.noise_fraction==noise)&(one.method==method)]
                            ax.plot(p.duplicate_fraction,p[f'{metric}_mean'],style,color=color,marker='o',ms=3,
                                    label=f"{'BFWK-N' if method.startswith('BFWK') else 'RBF'}; noise/d={noise:g}")
                    ax.set_xlabel('Number of noisy copies / base feature count')
                else:
                    for method,color in [('BFWK-SVM-N-jitter','#b2182b'),('RBF-SVM-jitter','#2166ac')]:
                        p=one[one.method==method]
                        ax.errorbar(p.train_fraction,p[f'{metric}_mean'],yerr=p[f'{metric}_sd'],
                                    color=color,marker='o',ms=3,capsize=2,label=method)
                    ax.set_xlabel('Fraction of outer training fold (nominal)')
                ax.set_title(name); ax.set_ylabel('Balanced accuracy' if metric=='BalancedAccuracy' else 'Accuracy'); ax.grid(alpha=.2)
            handles,labels=axes.flat[0].get_legend_handles_labels()
            fig.legend(handles,labels,loc='lower center',ncol=3,fontsize=8)
            fig.suptitle(f"Six-task {'redundancy/noise profiles' if kind=='stress' else 'training-size learning curves (copies/d=1, noise/d=1)'}")
            fig.tight_layout(rect=(0,.09,1,.95)); fig.savefig(OUT/f'{kind}6_{metric}.pdf')
            fig.savefig(OUT/f'{kind}6_{metric}.png',dpi=180); plt.close(fig)
    write_evidence_summary()


def write_evidence_summary():
    path=OUT/'stress6_fold_results.csv'
    if not path.exists():
        return
    df=pd.read_csv(path)
    table=[]
    for name in STRESS_NAMES:
        row={'dataset':name}
        for label,dup,noise in [('clean',0.,0.),('severe',2.,1.)]:
            one=df[(df.dataset==name)&(df.duplicate_fraction==dup)&(df.noise_fraction==noise)]
            for method,short in [('BFWK-SVM-N-jitter','BFWK_N'),('RBF-SVM-jitter','RBF')]:
                s=one[one.method==method]
                row[f'{label}_{short}_BA']=float(s.BalancedAccuracy.mean())
                row[f'{label}_{short}_Accuracy']=float(s.Accuracy.mean())
            row[f'{label}_BA_gain']=row[f'{label}_BFWK_N_BA']-row[f'{label}_RBF_BA']
        table.append(row)
    pd.DataFrame(table).to_csv(OUT/'stress6_clean_vs_severe.csv',index=False)
    learned=df[df.method=='BFWK-SVM-N-jitter']
    states=learned.termination.value_counts().to_dict()
    residual=learned.projected_gradient_residual
    failures=int((df.dual_fit_status!=0).sum()) if 'dual_fit_status' in df else 'not recorded'
    lines=['# Actual results: bounded six-task stress protocol','',
           'The paired experiment completed 432 stress model fits (216 BFWK-N and 216 RBF) and 144 training-size learning-curve fits. All results are descriptive three-fold means with n capped at 360; they do not establish a universal advantage or threshold.','',
           '| Dataset | Clean BFWK-N BA | Clean RBF BA | Clean gain (pp) | Severe BFWK-N BA | Severe RBF BA | Severe gain (pp) |',
           '|---|---:|---:|---:|---:|---:|---:|']
    for r in table:
        lines.append(f"| {r['dataset']} | {100*r['clean_BFWK_N_BA']:.2f} | {100*r['clean_RBF_BA']:.2f} | {100*r['clean_BA_gain']:+.2f} | {100*r['severe_BFWK_N_BA']:.2f} | {100*r['severe_RBF_BA']:.2f} | {100*r['severe_BA_gain']:+.2f} |")
    lines.extend(['','Severe = appended noisy-copy count/base d=2 and independent-noise count/base d=1. See the full profiles for all twelve crossed cells; those conditions must not be selected post hoc to imply a general win.','',
       f'BFWK-N outer termination counts in the 216 stress fits: {json.dumps(states,sort_keys=True)}.',
       f'Final projected-gradient residual median={residual.median():.6g}, maximum={residual.max():.6g}. Nonzero inner SVC fit-status count among all stress models={failures}.',
       'An outer iteration cap and a relative-objective stopping test do not certify stationarity. Final projected-gradient residuals and all fold termination/status columns are saved.','',
       'The original 13-task property correlations are exploratory and remain nonsignificant after the four-test Holm adjustment (minimum adjusted p=0.4392). The original Friedman p=0.402 remains the appropriate limitation on benchmark-wide superiority.'])
    (OUT/'stress6_evidence_summary.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')


def run_stress(tasks):
    import revision_core as core
    started=time.perf_counter()
    rows=[]; learning=[]; manifest=[]
    for ds_index,name in enumerate(STRESS_NAMES):
        X,y=tasks[name]; n_original=len(y)
        X,y=cap_task(X,y,seed=SEED+ds_index)
        manifest.append(dict(dataset=name,n_available=n_original,n_used=len(y),raw_d=X.shape[1],
            positive_fraction=float(np.mean(y==1)),cap_seed=SEED+ds_index))
        outer=StratifiedKFold(N_FOLDS,shuffle=True,random_state=SEED)
        for fold,(tr,te) in enumerate(outer.split(X,y),1):
            A,B=preprocess(X.iloc[tr],X.iloc[te]); d=A.shape[1]
            for noise in [0.,.5,1.]:
                for dup in [0.,.5,1.,2.]:
                    AA,BB,kd,kn=augment(A,B,dup,noise,SEED+1000*ds_index+fold)
                    meta=dict(dataset=name,fold=fold,duplicate_fraction=dup,noise_fraction=noise,
                              duplicate_columns=kd,noise_columns=kn,d_base=d,n_dataset=len(y))
                    rows.extend(evaluate_pair(core,AA,y[tr],BB,y[te],meta))
                    pd.DataFrame(rows).to_csv(OUT/'stress6_fold_results.csv',index=False)
            # Learning curves use subsets of outer training fold and refit all
            # preprocessing. Labels are used only for stratified train sampling.
            for fraction in [.25,.5,.75,1.]:
                target=max(8,int(round(len(tr)*fraction)))
                if target>=len(tr):
                    sub=tr.copy()
                else:
                    ids,_=next(StratifiedShuffleSplit(n_splits=1,train_size=target,
                              random_state=SEED+2000*ds_index+fold).split(X.iloc[tr],y[tr]))
                    sub=tr[ids]
                LA,LB=preprocess(X.iloc[sub],X.iloc[te]); ld=LA.shape[1]
                LA,LB,kd,kn=augment(LA,LB,1.,1.,SEED+3000*ds_index+fold)
                meta=dict(dataset=name,fold=fold,train_fraction=fraction,
                    train_fraction_actual=len(sub)/len(tr),duplicate_fraction=1.,noise_fraction=1.,
                    duplicate_columns=kd,noise_columns=kn,d_base=ld,n_dataset=len(y))
                learning.extend(evaluate_pair(core,LA,y[sub],LB,y[te],meta))
                pd.DataFrame(learning).to_csv(OUT/'learning6_fold_results.csv',index=False)
            print(f'{name} fold {fold}/{N_FOLDS} completed ({len(rows)} stress model fits; {len(learning)} learning fits)',flush=True)
        pd.DataFrame(manifest).to_csv(OUT/'stress6_dataset_manifest.csv',index=False)
    summaries_and_plots()
    runtime=dict(wall_seconds=time.perf_counter()-started,stress_model_fits=len(rows),
        learning_model_fits=len(learning),total_model_seconds=float(sum(r['seconds'] for r in rows+learning)),
        threads_per_blas=1,platform=platform.platform(),processor=platform.processor(),
        logical_cores=os.cpu_count())
    try:
        import ctypes
        from ctypes import wintypes
        class ProcessMemoryCounters(ctypes.Structure):
            _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
                ('PeakWorkingSetSize',ctypes.c_size_t),('WorkingSetSize',ctypes.c_size_t),
                ('QuotaPeakPagedPoolUsage',ctypes.c_size_t),('QuotaPagedPoolUsage',ctypes.c_size_t),
                ('QuotaPeakNonPagedPoolUsage',ctypes.c_size_t),('QuotaNonPagedPoolUsage',ctypes.c_size_t),
                ('PagefileUsage',ctypes.c_size_t),('PeakPagefileUsage',ctypes.c_size_t)]
        counters=ProcessMemoryCounters(); counters.cb=ctypes.sizeof(counters)
        ctypes.windll.kernel32.GetCurrentProcess.restype=wintypes.HANDLE
        ctypes.windll.psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.POINTER(ProcessMemoryCounters),wintypes.DWORD]
        ctypes.windll.psapi.GetProcessMemoryInfo.restype=wintypes.BOOL
        handle=ctypes.windll.kernel32.GetCurrentProcess()
        if ctypes.windll.psapi.GetProcessMemoryInfo(handle,ctypes.byref(counters),counters.cb):
            runtime['peak_process_working_set_bytes']=int(counters.PeakWorkingSetSize)
            runtime['process_working_set_bytes_at_end']=int(counters.WorkingSetSize)
        else:
            runtime['memory_measurement_unavailable']='GetProcessMemoryInfo returned no successful measurement'
    except (AttributeError,OSError) as exc:
        runtime['memory_measurement_unavailable']=str(exc)
    (OUT/'stress_properties_runtime.json').write_text(json.dumps(runtime,indent=2),encoding='utf-8')


def write_protocol(correlations):
    import sklearn,scipy,statsmodels
    protocol=dict(seed=SEED,folds=N_FOLDS,max_n=MAX_N,max_outer=MAX_OUTER,parameters=PAR,
        stress_datasets=STRESS_NAMES,duplicate_fractions=[0,.5,1,2],noise_fractions=[0,.5,1],
        copy_definition='x_j + 0.05*z, z independent standard Gaussian; source j uniform with replacement',
        train_fractions=[.25,.5,.75,1.],learning_condition=dict(duplicate_fraction=1,noise_fraction=1),
        baseline='uniform alpha (1/d) weighted RBF; same C/gamma and diagonal jitter as BFWK',
        selection='all parameters prespecified; no held-out performance tuning',
        objective='J_N = V/n + lambda*||alpha||^2/2 + rho*alpha^T M alpha/2 - tau*q^T alpha',
        preprocessing='median imputation, constant removal, z score learned on each training subset only; appended columns rescaled using training statistics only',
        randomness='same augmentation seeds within each fold; nested duplicate/noise column prefixes across severity cells',
        metrics=['Accuracy','BalancedAccuracy'],error_bars='standard deviation across three folds; descriptive, not independent-replicate confidence intervals',
        data_splits='StratifiedKFold(3, shuffle=True, seed=20261020); cap performed before CV by stratified subsampling when n>360',
        historical_property_analysis='13 original dataset units; mean of paired five-fold BFWK minus RBF balanced accuracy; four descriptor correlations, 19999 two-sided random-label permutations, Holm adjustment within cohort',
        raw_collinearity_scope='8 original numeric tasks recoverable from package data; no invented collinearity values for 5 missing OpenML raw datasets',
        interpretation='exploratory descriptive evidence; unchanged supplied Friedman p=0.40199671335801085 does not establish omnibus superiority; new capped fixed-parameter runs do not replace original full benchmark',
        limitations=['n cap360, three folds,100 outer iterations; no search for optimum',
            'six tasks include small Spector(n32); limited representativeness',
            'synthetic redundant/noise columns augment real public observations; these are not new real-world measurements',
            'no PercePiano records were supplied; no PercePiano result is generated'],
        versions=dict(numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,
                      sklearn=sklearn.__version__,statsmodels=statsmodels.__version__),
        hardware=dict(platform=platform.platform(),processor=platform.processor(),
                      machine=platform.machine(),logical_cores=os.cpu_count(),blas_threads=1),
        numerical_audit='Pilot cap12 retained in pilot_cap12/. 207/216 pilot stress BFWK fits hit the cap, so the final cap was uniformly raised to100 based only on termination/residual diagnostics; inner tolerance tightened to1e-7 and minimum line-search step to2^-20. Model hyperparameters and data splits unchanged; no test-performance selection.',
        property_correlations=correlations)
    (OUT/'stress_properties_protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    text='''# New revision evidence: six-task stress tests and original 13-task properties\n\nThis directory contains actual computations generated by revision_stress_properties.py. Supplied results/ CSV files are immutable historical evidence. New BFWK-N results use J_N=V/n+R and fixed epsilon_K=1e-6 with the corrected revision_core.py; they are not interchangeable with the supplied unjittered results or with raw J at the same regularization coefficients.\n\n## Original 13-task property analysis\n\nThe analysis uses one unit per dataset, mean paired five-fold BFWK minus RBF balanced-accuracy differences. Four properties available for all 13 tasks are log10(n), raw d, raw d/n, and imbalance=1-2*minority_fraction. Two-sided permutation p values use 19,999 random permutations; Holm adjustment is within these four comparisons. Numeric-data collinearity is additionally calculated for eight locally recovered tasks and analysed as a separately labelled exploratory subset. These associations cannot establish causation, an optimal usage regime, or superiority. The original omnibus Friedman p=0.402 is retained.\n\n## New six-task stress and learning protocols\n\nReal public data: WDBC, Wine-01, Iris-12, Digits-35, Spector, ANES96. At most 360 observations per task, 3 paired stratified outer folds, at most 12 outer steps. Fixed parameters C=1, gamma=1, lambda=.08, rho=.18, tau=.35, epsilon_K=1e-6 are prespecified and are not test-tuned. Both methods use identical folds/preprocessing and kernel jitter. A uniform alpha=1/d defines the RBF baseline under the feature-weighted parameterization.\n\nRedundancy severity is appended copy count divided by base d: 0,.5,1,2 (rounded integer column counts). A copy is a randomly selected original standardized feature plus independent N(0,.05^2) perturbation. Noise severity is appended independent N(0,1) column count divided by d: 0,.5,1. All 12 crossed cells are run, including clean (0,0). The same augmentation seeds and nested column prefixes permit paired profiles. Training-set size curves use fractions .25,.5,.75,1 under copies/d=1, noise/d=1; Spector has a minimum of 8 training records, so actual fractions are explicitly recorded. All imputation/scaling, filtering and fitting are recomputed using each training subset only.\n\nBoth Accuracy and BalancedAccuracy are saved; figures show fold means (learning curve error bars are descriptive fold SD, not independent-replicate CIs). This is a bounded reproducible supplemental experiment, not a replacement for the original benchmark and not proof of an optimal parameter setting. Full convergence status, timing, actual training size and feature count are retained in fold CSV files. No PercePiano analysis is generated.\n'''
    text=text.replace('12 outer steps','100 outer steps')
    text+='\n## Numerical audit and final solver budget\n\nThe pilot with 12 outer steps is preserved in pilot_cap12/. Its 207/216 capped stress fits and four line-search failures motivated a uniform final cap of 100, SVC tolerance 1e-7 for both methods, and minimum BFWK line-search step 2^-20. This solver refinement used termination and residual diagnostics only; test performance did not select a budget or model hyperparameter. Final termination diagnostics remain explicit even if a fit is capped.\n'
    (OUT/'README_stress_properties.md').write_text(text,encoding='utf-8')


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--properties-only',action='store_true'); parser.add_argument('--plots-only',action='store_true')
    args=parser.parse_args()
    if args.plots_only:
        summaries_and_plots(); return
    tasks=numeric_tasks(); _,correlations=analyse_properties(tasks); write_protocol(correlations)
    print(pd.DataFrame(correlations).to_string(index=False),flush=True)
    if not args.properties_only:
        run_stress(tasks)


if __name__=='__main__':
    main()
