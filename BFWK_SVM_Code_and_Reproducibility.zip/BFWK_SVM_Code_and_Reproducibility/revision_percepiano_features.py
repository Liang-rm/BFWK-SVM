#!/usr/bin/env python3
"""Extract 45 score-free MIDI observables for a new PercePiano analysis.

No ratings, performer identities, score files, or official extraction code enter
the feature computation. Filename-derived fields are written only to metadata.
These are NOT the legacy IS feature matrix, audio timbre descriptors, score-
aligned deviations, or inferred musical phrases. See feature_groups.json for
every formula, unit, and missing-value convention.

Requires Python >=3.10 and mido==1.3.3. Example:
  python revision_percepiano_features.py --input /path/to/all_2rounds \
      --output results_percepiano --check-only
  python revision_percepiano_features.py --input /path/to/all_2rounds \
      --output results_percepiano
Use --dependency-dir to add a local dependency directory without installation.
"""
from __future__ import annotations

import argparse
import bisect
import collections
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re
import statistics
import sys

NAN = float("nan")
GROUPS = collections.OrderedDict((g, []) for g in
    ("Timing", "Dynamics", "Articulation", "Pedal", "Phrasing"))
DEFINITIONS = []


def define(name, group, formula, unit="dimensionless", missing="NaN if the required observations or positive denominator are absent"):
    GROUPS[group].append(name)
    DEFINITIONS.append(dict(name=name, group=group, formula=formula,
                            unit=unit, missing_rule=missing))


define("onset_rate_hz", "Timing", "K / D; K is number of distinct absolute-tick onsets", "s^-1")
define("note_rate_hz", "Timing", "N / D; N is number of paired positive-duration notes", "s^-1")
define("ioi_mean_s", "Timing", "mean(h); h_k = t_(k+1) - t_k for consecutive distinct onsets", "s")
define("ioi_sd_s", "Timing", "population SD(h), ddof=0", "s")
define("ioi_cv", "Timing", "population SD(h) / mean(h)")
define("ioi_q90_q10_ratio", "Timing", "Q_0.9(h) / Q_0.1(h)")
define("ioi_serial_corr", "Timing", "Pearson correlation of h[:-1] and h[1:]", missing="NaN if fewer than 3 IOIs or either lagged vector has zero variance")
define("ioi_normalized_mad", "Timing", "median(abs(h - median(h))) / median(h)")
define("chord_size_mean", "Timing", "mean(number of notes sharing each distinct absolute-tick onset)", "notes/onset")
define("chord_size_sd", "Timing", "population SD(number of notes at each distinct onset), ddof=0", "notes/onset")

define("velocity_mean", "Dynamics", "mean(v), where v = note-on velocity / 127")
define("velocity_sd", "Dynamics", "population SD(v), ddof=0")
define("velocity_q10", "Dynamics", "Q_0.1(v)")
define("velocity_q90", "Dynamics", "Q_0.9(v)")
define("velocity_range", "Dynamics", "max(v) - min(v)")
define("velocity_iqr", "Dynamics", "Q_0.75(v) - Q_0.25(v)")
define("velocity_adjacent_absdiff", "Dynamics", "mean(abs(z_(k+1)-z_k)); z_k is mean normalized velocity of onset k")
define("velocity_accent_fraction", "Dynamics", "fraction of notes with v > mean(v) + population SD(v)")
define("velocity_cv", "Dynamics", "population SD(v) / mean(v)")

define("duration_mean_s", "Articulation", "mean(d), where d is paired note-off minus note-on time; pedal is not applied", "s")
define("duration_sd_s", "Articulation", "population SD(d), ddof=0", "s")
define("duration_cv", "Articulation", "population SD(d) / mean(d)")
define("duration_q10_s", "Articulation", "Q_0.1(d)", "s")
define("duration_q90_s", "Articulation", "Q_0.9(d)", "s")
define("duration_next_ioi_median", "Articulation", "median(d_i / h_k) over notes in onset groups k < K; excludes the final onset group")
define("short_note_fraction", "Articulation", "fraction of paired note durations <= 0.1 seconds; fixed absolute-time proxy")
define("next_onset_signed_gap_mean_s", "Articulation", "mean(t_(k+1) - max(note-off times of notes beginning at t_k)); k < K", "s")
define("next_onset_overlap_fraction", "Articulation", "fraction of the preceding signed gaps < 0; no sustain-pedal correction")

PEDAL_MISSING = "No CC64 on a note-bearing channel means MIDI-observed pedal-off (initial value 0), not proof that physical pedal information was captured; cc64_present identifies this case"
define("cc64_present", "Pedal", "1 if any CC64 event exists on a note-bearing channel, else 0", missing=PEDAL_MISSING)
define("cc64_message_rate_hz", "Pedal", "number of CC64 messages on note-bearing channels within [a,b] / D; repeated values count", "s^-1", PEDAL_MISSING)
define("pedal_value_mean", "Pedal", "equal-channel, duration-weighted mean of CC64/127 over [a,b]", missing=PEDAL_MISSING)
define("pedal_value_sd", "Pedal", "SD of the equal-channel, duration-weighted CC64/127 mixture over [a,b]", missing=PEDAL_MISSING)
define("pedal_down_fraction", "Pedal", "equal-channel mean fraction of [a,b] with CC64 >= 64", missing=PEDAL_MISSING)
define("pedal_switch_rate_hz", "Pedal", "CC64 threshold-state transitions inside [a,b] / (D * number of note-bearing channels); transition at a counts", "s^-1", PEDAL_MISSING)
define("pedal_down_mean_duration_s", "Pedal", "mean duration of maximal per-channel CC64 >= 64 intervals clipped to [a,b]; 0 if no pedal-down interval", "s", PEDAL_MISSING)
define("pedal_down_note_on_fraction", "Pedal", "fraction of paired notes with their own channel's CC64 >=64 at note-on; same-tick merged event ordering is respected", missing=PEDAL_MISSING)

define("onset_density_end_start_ratio", "Phrasing", "count(distinct onsets at x>=0.75) / count(distinct onsets at x<0.25); x=(t-a)/D")
define("velocity_end_minus_start", "Phrasing", "mean(v for note-on x>=0.75) - mean(v for note-on x<0.25)")
define("velocity_time_slope", "Phrasing", "OLS slope of note-on normalized velocity v on normalized time x")
define("velocity_middle_endpoint_contrast", "Phrasing", "mean(v, 0.25<=x<0.75) - (mean(v,x<0.25)+mean(v,x>=0.75))/2")
define("duration_end_start_logratio", "Phrasing", "ln(mean(d, note-on x>=0.75) / mean(d, note-on x<0.25))")
define("log_duration_time_slope", "Phrasing", "OLS slope of ln(d/1 second) on note-on normalized time x")
define("log_ioi_time_slope", "Phrasing", "OLS slope of ln(h/1 second) on normalized midpoint time of each IOI")
define("normalized_onset_density_slope", "Phrasing", "OLS slope over eight equal time-bin centers of count_k / (K/8); bins cover normalized time [0,1]")
define("velocity_bin_contour_absdiff", "Phrasing", "mean absolute difference between consecutive nonempty-adjacent-bin mean velocities in eight equal time bins; empty bins are not bridged")
FEATURE_NAMES = [d["name"] for d in DEFINITIONS]


def avg(values):
    return statistics.fmean(values) if values else NAN


def sd(values):
    return statistics.pstdev(values) if values else NAN


def div(a, b):
    return a / b if math.isfinite(a) and math.isfinite(b) and b > 0 else NAN


def quant(values, p):
    """Linear interpolation at (n-1)*p, equivalent to numpy's linear method."""
    if not values:
        return NAN
    a = sorted(values)
    pos = (len(a) - 1) * p
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    return a[lo] + (pos - lo) * (a[hi] - a[lo])


def slope(xs, ys):
    if len(xs) < 2 or len(xs) != len(ys):
        return NAN
    mx, my = avg(xs), avg(ys)
    denominator = math.fsum((x-mx)**2 for x in xs)
    return math.fsum((x-mx)*(y-my) for x,y in zip(xs,ys)) / denominator if denominator > 0 else NAN


def corr(xs, ys):
    if len(xs) < 2:
        return NAN
    mx, my = avg(xs), avg(ys)
    xx = math.fsum((x-mx)**2 for x in xs)
    yy = math.fsum((y-my)**2 for y in ys)
    return math.fsum((x-mx)*(y-my) for x,y in zip(xs,ys)) / math.sqrt(xx*yy) if xx > 0 and yy > 0 else NAN


def parse_metadata(path):
    stem = path.stem.strip()  # preserve the original filename separately
    match = re.fullmatch(r"(.+?)_(\d+)bars_([^_]+)_(\d+)", stem)
    meta = dict(filename=path.name, canonical_stem=stem,
                source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                source_bytes=path.stat().st_size, filename_whitespace_trimmed=int(stem != path.stem))
    if not match:
        meta.update(metadata_parse_error="unrecognized filename", work="", performer_group="", is_control="")
        return meta
    piece, bars, performer, segment = match.groups()
    domain = "Beethoven" if piece.startswith("Beethoven_") else "Schubert" if piece.startswith("Schubert_") else "Unknown"
    work = next((w for w in ("Beethoven_WoO80", "Schubert_D935", "Schubert_D960") if piece.startswith(w)), "Unknown")
    is_control = performer.lower() in ("score", "score2")
    control = "Score2" if performer.lower() == "score2" else "Score" if is_control else ""
    normalized_performer = str(int(performer)) if performer.isdigit() else performer
    segment_id = f"{piece}_{bars}bars_{normalized_performer}_{int(segment)}"
    meta.update(metadata_parse_error="" if work != "Unknown" else "unknown work",
                segment_id=segment_id,
                work=work, excerpt_prefix=piece, bars=int(bars), performer_token=performer,
                performer_domain=domain, performer_group=f"{domain}:{control or normalized_performer}",
                segment_index=int(segment), is_control=int(is_control), control_type=control)
    return meta


def parse_midi(mid):
    """Independent type 0/1 MIDI parsing; FIFO note pairing by channel/pitch."""
    import mido
    if mid.type == 2:
        raise ValueError("MIDI type 2 has asynchronous tracks; no global feature timeline defined")
    if mid.ticks_per_beat <= 0:
        raise ValueError("SMPTE/nonpositive ticks-per-beat is unsupported")
    tempo, tick, sec = 500000, 0, 0.0
    pending = collections.defaultdict(collections.deque)
    notes, pedals = [], collections.defaultdict(list)
    q = dict(midi_type=mid.type, track_count=len(mid.tracks), ticks_per_beat=mid.ticks_per_beat,
             message_count=0, tempo_event_count=0, raw_note_on_count=0,
             raw_note_off_count=0, unmatched_note_off_count=0,
             same_pitch_retrigger_count=0, nonpositive_duration_count=0,
             cc64_message_count_all_channels=0)
    for order, msg in enumerate(mido.merge_tracks(mid.tracks)):
        tick += msg.time
        sec += mido.tick2second(msg.time, mid.ticks_per_beat, tempo)
        q["message_count"] += 1
        if msg.type == "set_tempo":
            if msg.tempo <= 0:
                raise ValueError("nonpositive tempo")
            tempo = msg.tempo
            q["tempo_event_count"] += 1
        elif msg.type == "control_change" and msg.control == 64:
            pedals[msg.channel].append(dict(tick=tick, time=sec, order=order, value=msg.value))
            q["cc64_message_count_all_channels"] += 1
        elif msg.type == "note_on" and msg.velocity > 0:
            key = (msg.channel, msg.note)
            q["raw_note_on_count"] += 1
            q["same_pitch_retrigger_count"] += int(bool(pending[key]))
            pending[key].append(dict(tick=tick, time=sec, order=order, channel=msg.channel,
                                     pitch=msg.note, velocity=msg.velocity))
        elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
            key = (msg.channel, msg.note)
            q["raw_note_off_count"] += 1
            if not pending[key]:
                q["unmatched_note_off_count"] += 1
            else:
                note = pending[key].popleft()
                if sec > note["time"]:
                    note.update(off=sec, off_tick=tick, duration=sec-note["time"])
                    notes.append(note)
                else:
                    q["nonpositive_duration_count"] += 1
    q.update(unmatched_note_on_count=sum(len(v) for v in pending.values()),
             paired_positive_note_count=len(notes), midi_total_duration_s=sec)
    notes.sort(key=lambda n: (n["tick"], n["order"]))
    return notes, pedals, q


def pedal_features(notes, pedals, start, end):
    duration = end - start
    channels = sorted({n["channel"] for n in notes})
    channel_count = len(channels)
    weighted_sum = weighted_sq = down_time = 0.0
    switches = message_count = present = 0
    holds = []
    for ch in channels:
        events = pedals.get(ch, [])
        present |= int(bool(events))
        message_count += sum(start <= e["time"] <= end for e in events)
        current, previous_time = 0, start
        hold_start = None
        # Events preceding the note window establish the state at its start.
        for e in events:
            if e["time"] < start:
                current = e["value"]
            else:
                break
        if current >= 64:
            hold_start = start
        for e in events:
            t = e["time"]
            if t < start:
                continue
            if t > end:
                break
            dt = t - previous_time
            weighted_sum += dt * current / 127
            weighted_sq += dt * (current / 127)**2
            down_time += dt * (current >= 64)
            was_down, is_down = current >= 64, e["value"] >= 64
            if was_down != is_down:
                switches += 1
                if is_down:
                    hold_start = t
                else:
                    if hold_start is not None and t > hold_start:
                        holds.append(t-hold_start)
                    hold_start = None
            current, previous_time = e["value"], t
        dt = end - previous_time
        weighted_sum += dt * current / 127
        weighted_sq += dt * (current / 127)**2
        down_time += dt * (current >= 64)
        if current >= 64 and hold_start is not None and end > hold_start:
            holds.append(end - hold_start)
    note_down = 0
    keys = {ch: [(e["tick"],e["order"]) for e in pedals.get(ch,[])] for ch in channels}
    for note in notes:
        ch = note["channel"]
        index = bisect.bisect_right(keys[ch], (note["tick"],note["order"]))-1
        value = pedals[ch][index]["value"] if index >= 0 else 0
        note_down += int(value >= 64)
    denom = duration * channel_count
    mean = div(weighted_sum, denom)
    return dict(cc64_present=float(present), cc64_message_rate_hz=div(message_count,duration),
                pedal_value_mean=mean, pedal_value_sd=math.sqrt(max(0.0,div(weighted_sq,denom)-mean**2)),
                pedal_down_fraction=div(down_time,denom), pedal_switch_rate_hz=div(switches,denom),
                pedal_down_mean_duration_s=avg(holds) if holds else 0.0,
                pedal_down_note_on_fraction=note_down/len(notes))


def extract(mid):
    notes, pedals, quality = parse_midi(mid)
    values = dict.fromkeys(FEATURE_NAMES, NAN)
    if not notes:
        quality["parse_error"] = "no paired positive-duration notes"
        return values, quality
    onset_groups = collections.OrderedDict()
    for note in notes:
        onset_groups.setdefault(note["tick"], []).append(note)
    groups = list(onset_groups.values())
    times = [g[0]["time"] for g in groups]
    start, end = times[0], max(n["off"] for n in notes)
    duration = end - start
    durations = [n["duration"] for n in notes]
    velocities = [n["velocity"]/127 for n in notes]
    iois = [b-a for a,b in zip(times,times[1:])]
    sizes = [len(g) for g in groups]
    onset_velocities = [avg([n["velocity"]/127 for n in g]) for g in groups]
    gaps = [times[k+1]-max(n["off"] for n in groups[k]) for k in range(len(groups)-1)]
    ratios = [n["duration"]/iois[k] for k in range(len(iois)) for n in groups[k]]
    velocity_mean, velocity_sd = avg(velocities), sd(velocities)
    values.update(onset_rate_hz=len(times)/duration, note_rate_hz=len(notes)/duration,
        ioi_mean_s=avg(iois), ioi_sd_s=sd(iois), ioi_cv=div(sd(iois),avg(iois)),
        ioi_q90_q10_ratio=div(quant(iois,.9),quant(iois,.1)),
        ioi_serial_corr=corr(iois[:-1],iois[1:]) if len(iois)>=3 else NAN,
        ioi_normalized_mad=div(quant([abs(t-quant(iois,.5)) for t in iois],.5),quant(iois,.5)),
        chord_size_mean=avg(sizes), chord_size_sd=sd(sizes),
        velocity_mean=velocity_mean, velocity_sd=velocity_sd,
        velocity_q10=quant(velocities,.1), velocity_q90=quant(velocities,.9),
        velocity_range=max(velocities)-min(velocities),
        velocity_iqr=quant(velocities,.75)-quant(velocities,.25),
        velocity_adjacent_absdiff=avg([abs(b-a) for a,b in zip(onset_velocities,onset_velocities[1:])]),
        velocity_accent_fraction=avg([float(v>velocity_mean+velocity_sd) for v in velocities]),
        velocity_cv=div(velocity_sd,velocity_mean),
        duration_mean_s=avg(durations), duration_sd_s=sd(durations),
        duration_cv=div(sd(durations),avg(durations)),
        duration_q10_s=quant(durations,.1), duration_q90_s=quant(durations,.9),
        duration_next_ioi_median=quant(ratios,.5),
        short_note_fraction=avg([float(d<=.1) for d in durations]),
        next_onset_signed_gap_mean_s=avg(gaps),
        next_onset_overlap_fraction=avg([float(g<0) for g in gaps]))
    values.update(pedal_features(notes,pedals,start,end))
    xs = [(n["time"]-start)/duration for n in notes]
    first = [i for i,x in enumerate(xs) if x<.25]
    middle = [i for i,x in enumerate(xs) if .25<=x<.75]
    last = [i for i,x in enumerate(xs) if x>=.75]
    v_first, v_middle, v_last = (avg([velocities[i] for i in ix]) for ix in (first,middle,last))
    bins_v = [[] for _ in range(8)]
    bins_onsets = [0]*8
    for x,v in zip(xs,velocities):
        bins_v[min(7,int(8*x))].append(v)
    for t in times:
        bins_onsets[min(7,int(8*(t-start)/duration))] += 1
    bin_means = [avg(v) for v in bins_v]
    mids = [((times[i]+times[i+1])/2-start)/duration for i in range(len(iois))]
    end_start = div(avg([durations[i] for i in last]),avg([durations[i] for i in first]))
    values.update(onset_density_end_start_ratio=div(sum((t-start)/duration>=.75 for t in times),sum((t-start)/duration<.25 for t in times)),
        velocity_end_minus_start=v_last-v_first,
        velocity_time_slope=slope(xs,velocities),
        velocity_middle_endpoint_contrast=v_middle-(v_first+v_last)/2,
        duration_end_start_logratio=math.log(end_start) if math.isfinite(end_start) and end_start>0 else NAN,
        log_duration_time_slope=slope(xs,[math.log(d) for d in durations]),
        log_ioi_time_slope=slope(mids,[math.log(h) for h in iois]),
        normalized_onset_density_slope=slope([(k+.5)/8 for k in range(8)],[c/(len(times)/8) for c in bins_onsets]),
        velocity_bin_contour_absdiff=avg([abs(b-a) for a,b in zip(bin_means,bin_means[1:]) if math.isfinite(a) and math.isfinite(b)]))
    quality.update(parse_error="", distinct_onset_count=len(times), note_bearing_channel_count=len({n["channel"] for n in notes}),
        cc64_message_count_note_channels=sum(len(pedals.get(ch,[])) for ch in {n["channel"] for n in notes}),
        analysis_start_s=start, analysis_end_s=end, analysis_duration_s=duration)
    if any(math.isinf(v) for v in values.values()):
        raise ArithmeticError("infinite output feature")
    return values, quality


def self_check():
    """Checks seconds conversion, merged ordering, zero-velocity off and FIFO."""
    import mido
    midi = mido.MidiFile(ticks_per_beat=480)
    tr = mido.MidiTrack(); midi.tracks.append(tr)
    tr.extend([mido.Message("note_on",note=60,velocity=80,time=0),
        mido.Message("control_change",control=64,value=127,time=240),
        mido.MetaMessage("set_tempo",tempo=1000000,time=240),
        mido.Message("control_change",control=64,value=0,time=240),
        mido.Message("note_on",note=60,velocity=0,time=240)])
    buf=io.BytesIO(); midi.save(file=buf); buf.seek(0)
    f,q = extract(mido.MidiFile(file=buf))
    assert abs(f["duration_mean_s"]-1.5)<1e-12
    assert abs(f["pedal_down_fraction"]-.5)<1e-12
    assert abs(f["pedal_down_mean_duration_s"]-.75)<1e-12
    assert q["paired_positive_note_count"]==1 and q["raw_note_off_count"]==1
    midi2=mido.MidiFile(ticks_per_beat=480); tr2=mido.MidiTrack();midi2.tracks.append(tr2)
    tr2.extend([mido.Message("note_on",note=60,velocity=70,time=0),
        mido.Message("note_on",note=60,velocity=90,time=120),
        mido.Message("note_off",note=60,time=120),
        mido.Message("note_off",note=60,time=120),
        mido.Message("note_off",note=61,time=0),
        mido.Message("note_on",note=62,velocity=80,time=0)])
    notes,_,q2=parse_midi(midi2)
    assert len(notes)==2 and all(abs(n["duration"]-.25)<1e-12 for n in notes)
    assert q2["same_pitch_retrigger_count"]==1 and q2["unmatched_note_off_count"]==1 and q2["unmatched_note_on_count"]==1
    return dict(tempo_seconds=True, zero_velocity_note_off=True, cc64_integration=True,
                fifo_note_pairing=True, orphan_event_accounting=True)


def sample_paths(paths):
    selected=[]
    for work in ("Beethoven_WoO80","Schubert_D935","Schubert_D960"):
        for control in (False,True):
            match=next((p for p in paths if p.stem.strip().startswith(work) and ("_Score" in p.stem)==control),None)
            if match:
                selected.append(match)
    return selected


def json_dump(path,obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",type=Path,required=True)
    parser.add_argument("--output",type=Path,default=Path(__file__).parent/"results_percepiano")
    parser.add_argument("--dependency-dir",type=Path)
    parser.add_argument("--check-only",action="store_true",help="Read six work/control-stratified files and print diagnostics; write no output files")
    args=parser.parse_args()
    if args.dependency_dir:
        sys.path.insert(0,str(args.dependency_dir.resolve()))
    import importlib.metadata
    import mido
    checks=self_check()
    paths=sorted(args.input.glob("*.mid"),key=lambda p:p.name)
    if not paths:
        raise FileNotFoundError(f"No .mid inputs: {args.input}")
    chosen=sample_paths(paths) if args.check_only else paths
    rows,metadata=[],[]
    for path in chosen:
        meta=parse_metadata(path)
        try:
            features,quality=extract(mido.MidiFile(filename=str(path),clip=False))
        except Exception as exc:
            features=dict.fromkeys(FEATURE_NAMES,NAN)
            quality=dict(parse_error=f"{type(exc).__name__}: {exc}")
        rows.append(dict(filename=path.name,**features))
        metadata.append(dict(**meta,**quality))
    missing={name:sum(not math.isfinite(r[name]) for r in rows) for name in FEATURE_NAMES}
    canonical_groups=collections.defaultdict(list)
    for meta in metadata:
        canonical_groups[meta.get("segment_id",meta["canonical_stem"])].append(meta["filename"])
    canonical_duplicates={k:v for k,v in canonical_groups.items() if len(v)>1}
    summary=dict(schema_version="1.0", feature_count=len(FEATURE_NAMES),
        group_dimensions={g:len(v) for g,v in GROUPS.items()}, row_count=len(rows),
        discovered_input_count=len(paths), mido_version=importlib.metadata.version("mido"),
        python_version=sys.version.split()[0], self_checks=checks,
        parse_error_count=sum(bool(m.get("parse_error")) for m in metadata),
        metadata_parse_error_count=sum(bool(m.get("metadata_parse_error")) for m in metadata),
        work_counts=dict(collections.Counter(m.get("work","") for m in metadata)),
        control_counts=dict(collections.Counter(str(m.get("is_control","")) for m in metadata)),
        missing_feature_cells=sum(missing.values()), missing_by_feature=missing,
        files_with_no_cc64_on_note_channels=sum(m.get("cc64_message_count_note_channels",0)==0 for m in metadata),
        quality_totals={k:sum(m.get(k,0) for m in metadata) for k in
            ("raw_note_on_count","raw_note_off_count","paired_positive_note_count",
             "unmatched_note_on_count","unmatched_note_off_count","nonpositive_duration_count","same_pitch_retrigger_count")},
        filenames_with_outer_whitespace=[m["filename"] for m in metadata if m["filename_whitespace_trimmed"]],
        canonical_stem_duplicate_count=len(metadata)-len({m["canonical_stem"] for m in metadata}),
        canonical_segment_id_duplicate_groups=canonical_duplicates,
        feature_inputs=["paired MIDI note-on/note-off events", "MIDI tempo messages", "MIDI CC64 messages"],
        excluded_inputs=["ratings", "labels", "performer identifiers", "composition identifiers", "filename bars and segment", "scores", "audio"],
        interpretation="New independent MIDI-only representation; not a reconstruction of the legacy five-group IS features. Dynamics uses note velocity. Pedal replaces the unrecoverable audio-timbre group. Phrasing denotes time-window/trend proxies, not identified musical phrases.")
    if args.check_only:
        summary["sample_metadata"]=metadata
        print(json.dumps(summary,indent=2,ensure_ascii=False,allow_nan=False))
        return
    if len(rows)!=len(paths) or len({r["filename"] for r in rows})!=len(paths):
        raise AssertionError("Input row preservation failed")
    args.output.mkdir(parents=True,exist_ok=True)
    with (args.output/"features.csv").open("w",newline="",encoding="utf-8") as out:
        writer=csv.DictWriter(out,fieldnames=["filename"]+FEATURE_NAMES)
        writer.writeheader()
        for row in rows:
            writer.writerow({k:("NaN" if isinstance(v,float) and math.isnan(v) else format(v,".17g") if isinstance(v,float) else v) for k,v in row.items()})
    meta_keys=list(dict.fromkeys(k for m in metadata for k in m))
    with (args.output/"feature_metadata.csv").open("w",newline="",encoding="utf-8") as out:
        writer=csv.DictWriter(out,fieldnames=meta_keys);writer.writeheader();writer.writerows(metadata)
    specification=dict(schema_version="1.0",groups=GROUPS,feature_count=len(FEATURE_NAMES),
        definitions=DEFINITIONS,
        shared_conventions=dict(a="first onset among paired positive-duration notes",b="last note-off among paired positive-duration notes",D="b-a in seconds",N="paired positive-duration note count",K="distinct absolute-tick onset count",quantiles="linear interpolation at (n-1)*p",SD="population standard deviation ddof=0",NaN="Explicit undefined value; no imputation or fitting is performed by this extractor",MIDI_time="merge tracks with mido, default tempo 500000 microseconds/beat, apply each set_tempo from its event onward",note_pairing="FIFO queue per channel/pitch; note_on velocity=0 is note_off; unmatched on/off and nonpositive duration pairs are counted and excluded; no synthetic EOF closure; note duration ignores CC64 sustain",pedal="Initial CC64 value=0 separately per channel; duration integrals use only note-bearing channels with equal channel weights; changes before a establish initial state; no CC64 event implies observed default off; same-tick ordering preserved",phrasing="Fixed normalized time windows and trends; no score alignment or phrase-boundary inference",metadata="Filename parsing strips outer whitespace for canonical_stem; original filename and file SHA256 retained. segment_id additionally normalizes numeric performer/segment tokens by removing leading zeros; Score and Score2 in actual MIDI names are preserved without rating-CSV remapping. Penultimate token is performer/control, final token segment. Human group is Beethoven:token or Schubert:token; D960 movements share work Schubert_D960. Metadata never enters features."))
    json_dump(args.output/"feature_groups.json",specification)
    summary["output_sha256"]={name:hashlib.sha256((args.output/name).read_bytes()).hexdigest() for name in
        ("features.csv","feature_metadata.csv","feature_groups.json")}
    summary["source_script_sha256"]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    summary["source_collection_sha256"]=hashlib.sha256("\n".join(m["filename"]+"\t"+m["source_sha256"] for m in metadata).encode("utf-8")).hexdigest()
    json_dump(args.output/"feature_extraction_audit.json",summary)
    print(json.dumps(summary,indent=2,ensure_ascii=False,allow_nan=False))


if __name__=="__main__":
    main()
