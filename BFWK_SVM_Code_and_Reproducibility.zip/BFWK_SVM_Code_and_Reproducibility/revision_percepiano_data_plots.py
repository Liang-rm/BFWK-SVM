#!/usr/bin/env python3
"""Read-only human-cohort target audit and descriptive plots; no model fits.

Produces a two-page vector PDF (rank-correlation heatmap; sensitivity panels)
and one vertically combined PNG preview. No target CSV is modified.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import os
import re
import statistics
from collections import defaultdict
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.image import imsave

HERE=Path(__file__).resolve().parent
OUT=HERE/'results_percepiano'
RAW=HERE/'source_data/PercePiano/labels/total_2rounds.csv'
COLS=['single13','single15','single18','interpretation','composite_equal',
      'composite_ivw_1e_6','composite_ivw_1e_4','composite_ivw_1e_2','composite_ivw_released_rows']
MAIN='composite_ivw_1e_4'
SHORT=['13 Spacious','15 Dramatic','18 Imaginative','19 Convincing','Equal four',
       r'IVW $10^{-6}$',r'IVW $10^{-4}$',r'IVW $10^{-2}$','All valid rows']
SOURCE_FILES=[OUT/'target_continuous.csv',OUT/'target_basis.csv',OUT/'ratings_audit.json',
              OUT/'ratings_segment_metadata.csv',RAW]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,
    'axes.titlesize':13.5,'axes.labelsize':12.5,'xtick.labelsize':12,
    'ytick.labelsize':12,'legend.fontsize':12,'figure.titlesize':15,
    'pdf.fonttype':42,'ps.fonttype':42,'axes.linewidth':.8})


def checksum():
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in SOURCE_FILES}


def canonical_human(filename):
    """Independent human-only identity parsing; Score corrections irrelevant."""
    name=filename.strip().replace('\\','/').rsplit('/',1)[-1]
    name=re.sub(r'\.(wav|mid|midi)$','',name,flags=re.I)
    m=re.fullmatch(r'(.*)_(\d+)bars_(\d+)_(\d+)',name)
    if not m:return None
    prefix,bars,performer,segment=m.groups()
    return f'{prefix}_{int(bars)}bars_{int(performer)}_{int(segment)}'


def independent_spot_checks(meta,basis,raw):
    """Recompute two source families without importing the cleaning code."""
    human=meta[meta.is_score_control==0].copy()
    human['extra_rows']=human.n_valid_rating_rows-human.n_distinct_raters
    selected=[]
    for family_test in [human.segment_id.str.startswith('Beethoven'),human.segment_id.str.startswith('Schubert')]:
        one=human[family_test].sort_values(['extra_rows','segment_id'],ascending=[False,True])
        selected.append(one.iloc[0].segment_id)
    raw_by=defaultdict(list)
    with raw.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.reader(f);next(reader)
        for row in reader:
            segment=canonical_human(row[2])
            if segment not in selected:continue
            vector=[];valid=True
            for text in row[3:-2]:
                text=text.strip()
                if not text:vector.append(None);continue
                try:v=float(text)
                except ValueError:valid=False;break
                if v==0:vector.append(None)
                elif not math.isfinite(v) or v<1 or v>7:valid=False;break
                else:vector.append(v)
            if valid:raw_by[segment].append((row[0].strip(),tuple(vector)))
    basis=basis.set_index('segment_id')
    checks=[];tables=[]
    for segment in selected:
        vectors=defaultdict(set)
        for rater,vector in raw_by[segment]:vectors[rater].add(vector)
        rater_rows=[];values={j:[] for j in (13,15,18,19)}
        for rater,distinct in sorted(vectors.items()):
            record={'rater':rater,'distinct_vectors':len(distinct)}
            for j in values:
                raw_values=[v[j-1] for v in distinct if v[j-1] is not None]
                z=(sum(raw_values)/len(raw_values)-1)/6 if raw_values else None
                record[f'z{j}']=z
                if z is not None:values[j].append(z)
            rater_rows.append(record)
        for j,z in values.items():
            n=len(z);total=sum(z);total_sq=sum(v*v for v in z)
            mu=total/n;var=(total_sq-total*total/n)/(n-1)
            actual_mu=float(basis.loc[segment,f'mean{j}']);actual_var=float(basis.loc[segment,f'var{j}'])
            error=max(abs(mu-actual_mu),abs(var-actual_var))
            if error>1e-12:raise AssertionError(f'Independent rating check failed: {segment},label{j},error={error}')
            checks.append(dict(segment_id=segment,label=j,n=n,sum_z=total,sum_z_squared=total_sq,
                               recomputed_mean=mu,recomputed_sample_variance=var,max_error=error))
        tables.append((segment,len(raw_by[segment]),sum(map(len,vectors.values())),rater_rows))
    return checks,tables


def agreement_metrics(x,y):
    x=np.asarray(x,float);y=np.asarray(y,float);valid=np.isfinite(x)&np.isfinite(y)
    x=x[valid];y=y[valid];delta=y-x
    return dict(n=len(x),Spearman_rho=float(spearmanr(x,y).statistic),
        mean_difference_b_minus_a=float(delta.mean()),median_difference_b_minus_a=float(np.median(delta)),
        minimum_difference=float(delta.min()),q05_difference=float(np.quantile(delta,.05)),
        q25_difference=float(np.quantile(delta,.25)),q75_difference=float(np.quantile(delta,.75)),
        q95_difference=float(np.quantile(delta,.95)),maximum_difference=float(delta.max()),
        mean_absolute_difference=float(np.abs(delta).mean()),maximum_absolute_difference=float(np.abs(delta).max()),
        n_positive=int((delta>0).sum()),n_negative=int((delta<0).sum()),n_exact_zero=int((delta==0).sum()))


def heatmap(human):
    fig,ax=plt.subplots(figsize=(9.5,9.5))
    fig.subplots_adjust(left=.21,right=.88,top=.83,bottom=.25)
    corr=human[COLS].corr(method='spearman').to_numpy()
    image=ax.imshow(corr,vmin=-1,vmax=1,cmap='RdBu_r',aspect='equal')
    ax.set_xticks(range(len(COLS)),SHORT,rotation=45,ha='right',rotation_mode='anchor')
    ax.set_yticks(range(len(COLS)),SHORT)
    ax.tick_params(axis='both',labelsize=12)
    for i in range(len(COLS)):
        for j in range(len(COLS)):
            ax.text(j,i,f'{corr[i,j]:.2f}',ha='center',va='center',fontsize=12,
                    color='white' if abs(corr[i,j])>.66 else 'black')
    cax=fig.add_axes([.90,.305,.018,.45]);cbar=fig.colorbar(image,cax=cax)
    cbar.ax.yaxis.set_label_position('left')
    cbar.set_label('Spearman rho',fontsize=12,labelpad=8);cbar.ax.tick_params(labelsize=12)
    fig.suptitle('Human performances (n = 1,073): target rank associations',y=.965)
    fig.text(.5,.90,'New named expression poles: Spacious, Dramatic/expressive,\nImaginative, Convincing',ha='center',fontsize=13,linespacing=1.4)
    fig.text(.5,.065,'Higher values point toward named poles, not a common musical-quality scale.\nAll valid rows: comparison before rating-record deduplication.\nDescriptive associations only; no significance test or classifier performance is implied.',
             ha='center',fontsize=12,linespacing=1.45)
    return fig


def decorate_pair(ax,title,xlabel,ylabel):
    ax.plot([0,1],[0,1],color='.45',lw=.9,linestyle='--')
    ax.set(xlim=(0,1),ylim=(0,1),xlabel=xlabel,ylabel=ylabel,title=title)
    ax.set_xticks([0,.25,.5,.75,1]);ax.set_yticks([0,.25,.5,.75,1]);ax.grid(alpha=.18)


def panels(human):
    fig,axes=plt.subplots(2,2,figsize=(9.5,9.0))
    fig.subplots_adjust(left=.13,right=.98,top=.83,bottom=.255,wspace=.41,hspace=.43)
    x=human[MAIN].to_numpy();y=human.composite_equal.to_numpy()
    ax=axes[0,0];ax.scatter(x,y,s=11,alpha=.32,color='#2166ac',edgecolors='none')
    decorate_pair(ax,'A. Equal-weight comparison',r'IVW ($\varepsilon_a=10^{-4}$)','Equal-weight four-label mean')
    met=agreement_metrics(x,y)
    ax.text(.04,.96,f"rho = {met['Spearman_rho']:.3f}\nMean |difference| = {met['mean_absolute_difference']:.4f}",
            transform=ax.transAxes,ha='left',va='top',fontsize=12)
    ax=axes[0,1]
    for col,color,marker,label in [('composite_ivw_1e_6','#762a83','o',r'$\varepsilon_a=10^{-6}$'),
                                   ('composite_ivw_1e_2','#1b7837','x',r'$\varepsilon_a=10^{-2}$')]:
        ax.scatter(x,human[col],s=12,alpha=.33,color=color,marker=marker,label=label,linewidths=.6)
    decorate_pair(ax,r'B. Target stabilizer $\varepsilon_a$',r'IVW ($\varepsilon_a=10^{-4}$)','Alternative IVW target')
    ax.legend(loc='upper left',frameon=False,markerscale=1.3,fontsize=12)
    ax=axes[1,0]
    cols=['composite_equal','composite_ivw_1e_6','composite_ivw_1e_2','single13','single15','single18','interpretation','composite_ivw_released_rows']
    labels=['Equal',r'$10^{-6}$',r'$10^{-2}$','13 Spacious','15 Dramatic','18 Imagin.','19 Convinc.','All rows']
    differences=[human[c].to_numpy()-x for c in cols]
    ax.boxplot(differences,orientation='horizontal',tick_labels=labels,showfliers=True,
        flierprops=dict(marker='.',markersize=2,alpha=.25),medianprops=dict(color='#b2182b',lw=1.2),
        boxprops=dict(linewidth=.8),whiskerprops=dict(linewidth=.8),capprops=dict(linewidth=.8))
    ax.axvline(0,color='.45',linestyle='--',lw=.8);ax.invert_yaxis()
    ax.set(title='C. Signed target differences',xlabel=r'Comparator minus IVW ($10^{-4}$)')
    ax.tick_params(axis='y',labelsize=12);ax.tick_params(axis='x',labelsize=12)
    ax.grid(axis='x',alpha=.2)
    ax=axes[1,1];y=human.composite_ivw_released_rows.to_numpy()
    ax.scatter(x,y,s=11,alpha=.32,color='#b2182b',edgecolors='none')
    decorate_pair(ax,'D. Repeated-record sensitivity','One contribution per rater','All valid released records')
    met=agreement_metrics(x,y)
    ax.text(.04,.96,f"rho = {met['Spearman_rho']:.3f}\nMean |difference| = {met['mean_absolute_difference']:.4f}",
            transform=ax.transAxes,ha='left',va='top',fontsize=12)
    fig.suptitle('New continuous targets: sensitivity on 1,073 human segments',y=.97)
    fig.text(.5,.90,'Expression-pole comparisons; no classifier is fitted.',ha='center',fontsize=13)
    fig.text(.5,.055,'A, B, D: each point is one human performance segment; dashed lines show equality.\nC: all signed differences are retained, including negative and exact-zero values.\nNo global standardization or musical-quality ordering is used.',ha='center',fontsize=12,linespacing=1.45)
    return fig


def main():
    before=checksum();targets=pd.read_csv(OUT/'target_continuous.csv')
    basis=pd.read_csv(OUT/'target_basis.csv');meta=pd.read_csv(OUT/'ratings_segment_metadata.csv')
    audit=json.loads((OUT/'ratings_audit.json').read_text())
    human=targets[targets.is_score_control==0].copy()
    if len(human)!=1073 or human.segment_id.nunique()!=1073:raise AssertionError('Expected1,073unique human segments')
    if human[COLS].isna().any().any():raise AssertionError('Unexpected missing human target')
    rows=[]
    for i,a in enumerate(COLS):
        for b in COLS[i+1:]:rows.append(dict(cohort='human-only',target_a=a,target_b=b,**agreement_metrics(human[a],human[b])))
    pd.DataFrame(rows).to_csv(OUT/'target_human_correlations.csv',index=False)
    checks,tables=independent_spot_checks(meta,basis,RAW)
    quality=[]
    def q(metric,value,cohort='all released data',note=''):
        quality.append(dict(metric=metric,cohort=cohort,value=value,note=note))
    for key in ['raw_rows','canonical_segments','valid_records_before_deduplication',
                'unique_rating_vectors_after_exact_deduplication','independent_rater_segment_contributions','rater_ids']:
        q(key,audit[key])
    q('invalid_rows_excluded',audit['row_dispositions']['excluded_invalid_row'])
    q('exact_duplicate_rows_excluded',audit['row_dispositions']['excluded_exact_rating_duplicate'])
    q('segments',1073,'human-only');q('excluded_control_segments',129,'control-only')
    q('selected_labels_min_valid_raters',int(human[[f'n{j}' for j in (13,15,18,19)]].min().min()),'human-only')
    q('selected_labels_max_valid_raters',int(human[[f'n{j}' for j in (13,15,18,19)]].max().max()),'human-only')
    q('independent_arithmetic_spot_checks',len(tables),'two human segments')
    q('spot_check_max_abs_error',max(c['max_error'] for c in checks),'two human segments','Means and ddof1 variances for all four selected labels')
    for c in COLS:
        met=agreement_metrics(human[MAIN],human[c])
        for field in ['Spearman_rho','mean_difference_b_minus_a','mean_absolute_difference','maximum_absolute_difference','n_positive','n_negative','n_exact_zero']:
            q(f'{c}::{field}',met[field],'human-only',f'Comparator minus {MAIN}; no significance test')
    pd.DataFrame(quality).to_csv(OUT/'data_quality_summary.csv',index=False)
    f1=heatmap(human);f2=panels(human)
    with PdfPages(OUT/'target_human_sensitivity.pdf') as pdf:pdf.savefig(f1);pdf.savefig(f2)
    previews=[]
    for fig in (f1,f2):
        fig.set_dpi(200);fig.canvas.draw();previews.append(np.asarray(fig.canvas.buffer_rgba()).copy())
    imsave(OUT/'target_human_sensitivity.png',np.vstack(previews))
    plt.close(f1);plt.close(f2)
    notes=['# Human-cohort data and target audit','',
        'No classifier is fitted here. The analysis is restricted to 1,073 human source segments; 129 Score/Score2 controls are excluded. All target comparisons are descriptive. Correlations are Spearman rank associations, without significance tests. No global standardization is used.',
        '',f"Actual release counts: {audit['raw_rows']} raw rows; 208 invalid rows; 2,200 exact duplicate records removed; 12,526 distinct rating vectors; 11,118 rater-by-segment contributions after averaging distinct repeat ratings. The release contains 63 distinct anonymized rater codes, which is a code count rather than a verified count of experts. The paper's 12,652 annotations/53 experts are not forced onto these data.",
        '', 'The new composite uses official ordinal labels 13 (Spacious), 15 (Dramatic/expressive), 18 (Imaginative), 19 (Convincing). Higher values point toward these named poles; they do not define a common musical-quality scale. Label 14 is excluded because the official README and paper disagree on its direction. The old manuscript four-attribute mapping and historical 0.812 are not reconstructed.',
        '', 'Primary statistical unit: one rater per segment. A full 19-dimensional vector is the exact-duplicate key; repeated equal values in one attribute are retained if the other attributes make the complete vectors distinct. Distinct vectors from the same rater/segment are averaged attribute by attribute, then z=(rating-1)/6. Means and sample variances use these rater contributions, with ddof=1. The all-valid-row comparator instead aggregates valid released records before duplicate removal.',
        '', 'All four chosen labels have at least two valid rater contributions in every human segment. Single-label targets use their own n>=2 eligibility; IVW and equal-weight composites require all four labels. Training-fold standardized composites and train-only median thresholds belong to the separate modeling analysis and are not calculated from full-cohort moments here.',
        '', 'The official mapper would merge 13 pairs of Score and Score2 controls, whereas the released JSON/MIDI source IDs retain them. The primary tables preserve all 1,202 source IDs, and all 1,202 match unique normalized MIDI IDs. This ambiguity does not alter the 1,073 human cohort.',
        '', '## Independent arithmetic spot checks','',
        'Two human segments from different source families, including one with repeated-record content, were recomputed directly from the raw CSV without importing revision_percepiano_ratings.py. For each segment, first remove invalid rows and exact full-vector duplicates; average distinct vectors within rater; then compute mean=sum(z)/n and sample variance=[sum(z^2)-sum(z)^2/n]/(n-1).',
        '']
    for segment,nraw,nunique,records in tables:
        notes += [f'### {segment}','',f'{nraw} valid source rows; {nunique} unique full rating vectors; {len(records)} rater contributions.','',
            '| Rater code | Distinct full vectors | z13 | z15 | z18 | z19 |','|---|---:|---:|---:|---:|---:|']
        for r in records:
            notes.append('| '+str(r['rater'])+' | '+str(r['distinct_vectors'])+' | '+' | '.join('NA' if r[f'z{j}'] is None else f"{r[f'z{j}']:.9f}" for j in (13,15,18,19))+' |')
        notes += ['','| Label | n | sum(z) | sum(z²) | mean | sample variance | max table difference |',
                  '|---|---:|---:|---:|---:|---:|---:|']
        for c in checks:
            if c['segment_id']==segment:
                notes.append(f"| {c['label']} | {c['n']} | {c['sum_z']:.12g} | {c['sum_z_squared']:.12g} | {c['recomputed_mean']:.12g} | {c['recomputed_sample_variance']:.12g} | {c['max_error']:.3g} |")
        notes.append('')
    notes += ['## Plot specification','',
        'target_human_sensitivity.pdf has two vector pages: page 1 rank-correlation heatmap (9.5 x 9.5 in); page 2 four-panel sensitivity comparison (9.5 x 9 in). The PNG is a vertical combined preview (1,900 x 3,700 px at 200 dpi). Main text/tick fonts are 12–15 pt before reduction. Difference summaries retain negative, positive and exactly-zero values. Figure C includes all observed differences; no outliers are removed.',
        '', '## Input integrity','', 'All source/target input hashes were checked before and after plotting; the inputs are unchanged.','']
    if before!=checksum():raise AssertionError('A scientific input changed while plotting')
    notes += ['```json',json.dumps(before,indent=2),'```','']
    (OUT/'data_quality_notes.md').write_text('\n'.join(notes),encoding='utf-8')
    print(json.dumps(dict(human_segments=len(human),correlation_pairs=len(rows),pdf_pages=2,
        independent_checks=len(checks),maximum_arithmetic_error=max(c['max_error'] for c in checks),
        inputs_unchanged=True),indent=2))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=RAW)
    args=parser.parse_args()
    RAW=args.source
    SOURCE_FILES[-1]=RAW
    main()
