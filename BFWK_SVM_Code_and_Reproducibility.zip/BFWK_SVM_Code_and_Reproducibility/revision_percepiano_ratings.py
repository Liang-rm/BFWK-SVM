#!/usr/bin/env python3
"""Clean official PercePiano ratings and define new continuous targets.

No classifier is fitted. No historical BFWK-SVM score or target is reproduced.
Only the Python standard library is required. Run from the supplied workspace:
  python revision_percepiano_ratings.py --source path/to/total_2rounds.csv

The new four-label composite points toward Spacious, Dramatic/expressive,
Imaginative, and Convincing. It is not a universal musical-quality scale and
does not reconstruct the manuscript's unavailable four-attribute target.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import statistics
import sys
from collections import Counter, defaultdict

HERE=Path(__file__).resolve().parent
SELECTED=(13,15,18,19)
EPSILONS=((1e-6,'e1m6'),(1e-4,'e1m4'),(1e-2,'e1m2'))
OFFICIAL_REPO='https://github.com/JonghoKimSNU/PercePiano'
OFFICIAL_COMMIT='e672299b8661f63802cd5cd73bb3c76218a13029'
LABELS=[
 ('Timing_Stable_Unstable','Stable beat','Unstable beat'),
 ('Articulation_Short_Long','Short','Long'),
 ('Articulation_Soft_cushioned_Hard_solid','Soft/cushioned','Hard/solid'),
 ('Pedal_Sparse/dry_Saturated/wet','Sparse/dry','Saturated/wet'),
 ('Pedal_Clean_Blurred','Clean','Blurred'),
 ('Timbre_Even_Colorful','Even','Colorful'),
 ('Timbre_Shallow_Rich','Shallow','Rich'),
 ('Timbre_Bright_Dark','Bright','Dark'),
 ('Timbre_Soft_Loud','Soft','Loud'),
 ('Dynamic_Sophisticated/mellow_Raw/crude','Sophisticated/mellow','Raw/crude'),
 ('Dynamic_Little_dynamic_range_Large_dynamic_range','Little dynamic range','Large dynamic range'),
 ('Music_Making_Fast_paced_Slow_paced','Fast paced','Slow paced'),
 ('Music_Making_Flat_Spacious','Flat','Spacious'),
 ('Music_Making_Disproportioned_Balanced','Disproportioned','Balanced'),
 ('Music_Making_Pure_Dramatic/expressive','Pure','Dramatic/expressive'),
 ('Emotion_&_Mood_Optimistic/pleasant_Dark','Optimistic/pleasant','Dark'),
 ('Emotion_&_Mood_Low_Energy_High_Energy','Low Energy','High Energy'),
 ('Emotion_&_Mood_Honest_Imaginative','Honest','Imaginative'),
 ('Interpretation_Unsatisfactory/doubtful_Convincing','Unsatisfactory/doubtful','Convincing'),
]


def canonical_segment(filename,apply_score_alias=False):
    name=str(filename).strip().replace('\\','/').rsplit('/',1)[-1]
    name=re.sub(r'\.(wav|mid|midi|mp3|musicxml)$','',name,flags=re.I).strip()
    name=re.sub(r'(?<=_)score2(?=_)','Score2',name,flags=re.I)
    name=re.sub(r'(?<=_)score(?=_)','Score',name,flags=re.I)
    m=re.fullmatch(r'(.+)_(\d+)bars_([^_]+)_(\d+)',name)
    if not m:
        raise ValueError(f'Unrecognized segment filename: {filename!r}')
    prefix,bars,player,segment=m.groups(); bars=int(bars); segment=int(segment)
    if player.isdigit(): player=str(int(player))
    if apply_score_alias and player=='Score' and (
        ('Beethoven_WoO80' in prefix and segment in range(5,17)) or
        ('Schubert_' in prefix and '_no.3' in prefix and bars==4 and segment==1)):
        player='Score2'
    return f'{prefix}_{bars}bars_{player}_{segment}'


def segment_metadata(segment):
    m=re.fullmatch(r'(.+)_(\d+)bars_([^_]+)_(\d+)',segment)
    prefix,bars,player,number=m.groups()
    family='Beethoven_WoO80' if prefix.startswith('Beethoven_WoO80') else prefix
    return dict(segment_id=segment,piece_id=prefix,work_family=family,bars=int(bars),
        performer_token=player,segment_number=int(number),
        score_passage_id=f'{prefix}_{int(bars)}bars_{int(number)}',
        performer_code_group=player,performer_within_work_group=f'{family}::{player}',
        is_score_control=int(player in ('Score','Score2')))


def write_csv(path,rows,fields=None):
    rows=list(rows)
    if fields is None:
        fields=list(rows[0]) if rows else []
    with path.open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k:('' if v is None or (isinstance(v,float) and not math.isfinite(v)) else v)
                             for k,v in row.items()})


def stats(values):
    a=[float(v) for v in values if v is not None]
    return len(a),(statistics.fmean(a) if a else None),(statistics.variance(a) if len(a)>=2 else None)


def ranks(values):
    order=sorted(range(len(values)),key=lambda i:values[i]); out=[0.]*len(values)
    j=0
    while j<len(order):
        k=j+1
        while k<len(order) and values[order[k]]==values[order[j]]: k+=1
        rank=(j+k-1)/2+1
        for q in order[j:k]: out[q]=rank
        j=k
    return out


def correlation(a,b,rank=False):
    if len(a)<3 or len(set(a))<2 or len(set(b))<2: return None
    if rank: a,b=ranks(a),ranks(b)
    return statistics.correlation(a,b)


def targets_for_segment(segment,aggregate,metadata):
    row=dict(metadata[segment])
    for j in SELECTED:
        n,mean,var=aggregate[(segment,j)]
        row[f'n{j}']=n;row[f'mu{j}']=mean;row[f'var{j}']=var
        row[f'eligible_single{j}']=int(n>=2)
        row[f'target_single{j}']=mean if n>=2 else None
    eligible=all(row[f'n{j}']>=2 for j in SELECTED)
    row['eligible_four']=int(eligible)
    row['target_primary_interpretation']=row['target_single19']
    row['target_equal4']=statistics.fmean(row[f'mu{j}'] for j in SELECTED) if eligible else None
    for epsilon,suffix in EPSILONS:
        if eligible:
            weights=[1/(row[f'var{j}']+epsilon) for j in SELECTED]
            row[f'target_ivw4_{suffix}']=sum(w*row[f'mu{j}'] for w,j in zip(weights,SELECTED))/sum(weights)
        else:
            row[f'target_ivw4_{suffix}']=None
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=HERE/'source_data/PercePiano/labels/total_2rounds.csv')
    parser.add_argument('--output',type=Path,default=HERE/'results_percepiano')
    args=parser.parse_args(); out=args.output;out.mkdir(parents=True,exist_ok=True)
    source=args.source.resolve(); input_sha=hashlib.sha256(source.read_bytes()).hexdigest()
    with source.open(encoding='utf-8-sig',newline='') as f:
        reader=csv.reader(f);header=next(reader); raw=list(reader)
    if len(header)!=24 or len(header[3:-2])!=19:
        raise ValueError('Expected 24 columns with 19 ratings at columns3:-2')
    segments=set(); filenames=defaultdict(set); metadata={}; valid_records=[]; unique_records=[]
    official_alias_sources=defaultdict(set)
    seen=set();dispositions=[];status_count=Counter(); raw_count=Counter(); valid_count=Counter()
    for line_no,row in enumerate(raw,2):
        if len(row)!=len(header):
            raise ValueError(f'Row length mismatch at source line {line_no}')
        segment=canonical_segment(row[2]);segments.add(segment);filenames[segment].add(row[2].strip())
        metadata[segment]=segment_metadata(segment);raw_count[segment]+=1
        alias=canonical_segment(row[2],apply_score_alias=True)
        metadata[segment]['official_script_segment_id']=alias
        official_alias_sources[alias].add(segment)
        user=row[0].strip(); values=[];invalid=[]
        for j,text in enumerate(row[3:-2],1):
            text=text.strip()
            if not text:
                values.append(None);continue
            try: value=float(text)
            except ValueError:
                value=None;invalid.append(f'{j}:non_numeric')
            if value==0: value=None
            elif value is not None and (not math.isfinite(value) or not 1<=value<=7):
                invalid.append(f'{j}:outside_1_to_7')
            values.append(value)
        if not user: invalid.append('missing_user_id')
        key=(user,segment,tuple(values))
        if invalid:
            state='excluded_invalid_row'
        else:
            valid_records.append(key);valid_count[segment]+=1
            if key in seen:
                state='excluded_exact_rating_duplicate'
            else:
                state='retained_unique_rating_vector';seen.add(key);unique_records.append(key)
        status_count[state]+=1
        dispositions.append(dict(source_line=line_no,source_filename=row[2].strip(),segment_id=segment,
            rater_id=user,disposition=state,invalid_fields=';'.join(invalid)))
    # Equal contribution per rater/segment: average distinct rating vectors
    # attribute by attribute, after collapsing exact duplicate rating records.
    rater_vectors=defaultdict(list)
    for user,segment,vector in unique_records:rater_vectors[(user,segment)].append(vector)
    rater_rows=[];rater_norm=defaultdict(list);rater_count=Counter();different_pairs=0
    for (user,segment),vectors in sorted(rater_vectors.items()):
        if len(vectors)>1:different_pairs+=1
        vals=[];record=dict(segment_id=segment,rater_id=user,n_distinct_rating_vectors=len(vectors))
        for j in range(19):
            a=[v[j] for v in vectors if v[j] is not None]
            raw_mean=statistics.fmean(a) if a else None
            z=(raw_mean-1)/6 if raw_mean is not None else None
            vals.append(z);record[f'label{j+1:02d}_mean_01']=z
            record[f'label{j+1:02d}_n_distinct_valid_vectors']=len(a)
        rater_rows.append(record);rater_norm[segment].append(vals);rater_count[segment]+=1
    published_norm=defaultdict(list)
    for user,segment,vector in valid_records:
        published_norm[segment].append([None if v is None else (v-1)/6 for v in vector])
    aggregate={};published_aggregate={};summary=[]
    for segment in sorted(segments):
        for j in range(1,20):
            core=stats(v[j-1] for v in rater_norm.get(segment,[]))
            pub=stats(v[j-1] for v in published_norm.get(segment,[]))
            aggregate[(segment,j)]=core;published_aggregate[(segment,j)]=pub
            summary.append(dict(segment_id=segment,label_index=j,raw_csv_column=header[2+j],
                label_name=LABELS[j-1][0],n_valid_raters=core[0],mean_01=core[1],sample_variance_01=core[2],
                n_published_valid_records=pub[0],published_record_mean_01=pub[1],
                published_record_sample_variance_01=pub[2]))
        metadata[segment].update(n_raw_rating_rows=raw_count[segment],n_valid_rating_rows=valid_count[segment],
            n_unique_rating_vectors=sum(1 for u,s,v in unique_records if s==segment),
            n_distinct_raters=rater_count[segment],source_filenames='|'.join(sorted(filenames[segment])))
    target_rows=[targets_for_segment(s,aggregate,metadata) for s in sorted(segments)]
    published_targets=[targets_for_segment(s,published_aggregate,metadata) for s in sorted(segments)]
    for main,pub in zip(target_rows,published_targets):
        for row in (main,pub):
            row['interpretation']=row['target_single19']
            row['composite_equal']=row['target_equal4']
            for j in (13,15,18):row[f'single{j}']=row[f'target_single{j}']
            for eps,suffix in EPSILONS:
                row[f'composite_ivw_1e_{int(-math.log10(eps))}']=row[f'target_ivw4_{suffix}']
            for j in SELECTED:row[f'mean{j}']=row[f'mu{j}']
        main['composite_ivw_released_rows']=pub['target_ivw4_e1m4']
        for j in SELECTED:
            main[f'raw_mean{j}']=pub[f'mu{j}'];main[f'raw_var{j}']=pub[f'var{j}'];main[f'raw_n{j}']=pub[f'n{j}']
    target_columns=[f'target_single{j}' for j in SELECTED]+['target_equal4']+[f'target_ivw4_{s}' for e,s in EPSILONS]
    pairs=[]
    for a,b in itertools.combinations(target_columns,2):
        both=[(r[a],r[b]) for r in target_rows if r[a] is not None and r[b] is not None]
        x=[p[0] for p in both];y=[p[1] for p in both]
        pairs.append(dict(target_a=a,target_b=b,n_segments=len(both),Pearson_r=correlation(x,y),
                         Spearman_rho=correlation(x,y,rank=True),mean_absolute_difference=statistics.fmean(abs(u-v) for u,v in both) if both else None))
    duplicate_comparison=[];target_description=[]
    for column in target_columns:
        both=[(r[column],p[column]) for r,p in zip(target_rows,published_targets)
              if r[column] is not None and p[column] is not None]
        x=[v[0] for v in both];y=[v[1] for v in both];diff=[u-v for u,v in both]
        duplicate_comparison.append(dict(target=column,n_paired_segments=len(both),
            Pearson_r=correlation(x,y),Spearman_rho=correlation(x,y,rank=True),
            mean_rater_balanced_minus_published_record=statistics.fmean(diff) if diff else None,
            mean_absolute_difference=statistics.fmean(abs(v) for v in diff) if diff else None,
            maximum_absolute_difference=max(map(abs,diff)) if diff else None,
            n_absolute_difference_above_0p01=sum(abs(v)>.01 for v in diff)))
        values=[r[column] for r in target_rows if r[column] is not None]
        target_description.append(dict(target=column,n_eligible_segments=len(values),n_missing_segments=len(target_rows)-len(values),
            mean=statistics.fmean(values) if values else None,sample_sd=statistics.stdev(values) if len(values)>1 else None,
            minimum=min(values) if values else None,maximum=max(values) if values else None))
    basis_columns=list(segment_metadata(next(iter(segments))))+['official_script_segment_id']
    basis_columns += [c for j in SELECTED for c in (f'n{j}',f'mu{j}',f'var{j}',f'eligible_single{j}')]+['eligible_four']
    basis_columns += [c for j in SELECTED for c in (f'mean{j}',f'raw_mean{j}',f'raw_var{j}',f'raw_n{j}')]
    source_mapping=[]
    for segment in sorted(segments):
        alias=metadata[segment]['official_script_segment_id']
        for source_filename in sorted(filenames[segment]):
            source_mapping.append(dict(source_filename=source_filename,segment_id=segment,
                official_script_segment_id=alias,script_alias_source_id_count=len(official_alias_sources[alias]),
                score_alias_collision=int(len(official_alias_sources[alias])>1)))
    collisions=[dict(official_script_segment_id=a,n_source_ids=len(ids),source_ids='|'.join(sorted(ids)))
                for a,ids in sorted(official_alias_sources.items()) if len(ids)>1]
    write_csv(out/'ratings_row_dispositions.csv',dispositions)
    write_csv(out/'ratings_rater_segment.csv',rater_rows)
    write_csv(out/'ratings_segment_label_summary.csv',summary)
    write_csv(out/'ratings_segment_metadata.csv',[metadata[s] for s in sorted(segments)])
    write_csv(out/'ratings_source_segment_mapping.csv',source_mapping)
    write_csv(out/'ratings_score_alias_collisions.csv',collisions)
    write_csv(out/'target_continuous.csv',target_rows)
    write_csv(out/'target_published_record_aggregation.csv',published_targets)
    write_csv(out/'target_basis.csv',({k:r[k] for k in basis_columns} for r in target_rows))
    write_csv(out/'target_correlations.csv',pairs)
    write_csv(out/'target_duplicate_sensitivity.csv',duplicate_comparison)
    write_csv(out/'target_summary.csv',target_description)
    mapping=dict(source_repository=OFFICIAL_REPO,source_commit=OFFICIAL_COMMIT,
        reference_readme=OFFICIAL_REPO+'/blob/'+OFFICIAL_COMMIT+'/README.md',
        official_mapper=OFFICIAL_REPO+'/blob/'+OFFICIAL_COMMIT+'/labels/map_midi_to_label.py',
        raw_column_order='csv row[3:-2]; first column index3;19 ratings',
        normalization='z=(s-1)/6; no reversal; higher means toward the named Option2 pole, not higher universal quality',
        segment_identity='Primary segment_id preserves distinct released Score and Score2 source IDs after extension/whitespace/numeric-token normalization. official_script_segment_id applies the stale mapper Score->Score2 corrections only as an auxiliary identifier;13 resulting alias collisions are not merged.',
        labels=[dict(index=j,zero_based_index=j-1,csv_column=header[j+2],repository_name=label[0],
            option1_repository=label[1],option2_repository=label[2],selected_in_new_composite=j in SELECTED,
            note=('Direction conflict: README Disproportioned->Balanced; paper Table2 Balanced->Unbalanced. Excluded from new targets.' if j==14 else
                  'README categorizes Soft/Loud under Timbre; paper Table2 places it under Dynamic.' if j==9 else ''))
            for j,label in enumerate(LABELS,1)],
        new_primary_target=dict(column='target_primary_interpretation',alias='target_single19',index=19,name=LABELS[18][0]),
        new_four_label_composite=dict(indices=list(SELECTED),pole_names=['Spacious','Dramatic/expressive','Imaginative','Convincing'],
            construct='new four-label perceptual composite; not the unavailable historical four-attribute target and not a validated musical-quality construct'),
        historical_mapping_status='No official independent phrase shaping or emotional communication label exists in the19-column release; no one-to-one historical mapping is asserted',
        target_rules=dict(minimum_valid_raters_per_single=2,composite_requires_all_four_labels_with_at_least_2_raters=True,
            equal='arithmetic mean of mu13,mu15,mu18,mu19',
            ivw='sum(mu_j/(sample_variance_j+epsilon_a))/sum(1/(sample_variance_j+epsilon_a)); variances are on z scale',
            epsilon_a_values=[e for e,s in EPSILONS],main_epsilon_a=1e-4,
            standardized='NOT computed globally. On each model training fold estimate mu_train_j and sd_train_j across segment means; standardized composite is mean_j((mu_ij-mu_train_j)/sd_train_j). Reuse training moments on held-out data; handle zero sd using train-only flag.',
            binary_threshold='NOT computed in this script. Estimate each target median on each model training fold only; apply to train/test. All target comparisons must share predetermined group partitions.'))
    (out/'label_mapping.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
    audit=dict(source_path=str(source),source_sha256=input_sha,source_commit=OFFICIAL_COMMIT,
        python=sys.version,cleaning_version='percepiano-ratings-20261020-v1',raw_rows=len(raw),
        raw_unique_filenames=len(set(r[2].strip() for r in raw)),canonical_segments=len(segments),
        row_dispositions=dict(status_count),valid_records_before_deduplication=len(valid_records),
        unique_rating_vectors_after_exact_deduplication=len(unique_records),
        independent_rater_segment_contributions=len(rater_rows),
        rater_segment_pairs_with_different_rating_vectors=different_pairs,
        rater_ids=len(set(u for u,s in rater_vectors)),
        human_segments=sum(not m['is_score_control'] for m in metadata.values()),
        score_control_segments=sum(m['is_score_control'] for m in metadata.values()),
        cleaning_rules=['strip extension/path/outer whitespace; normalize numeric performer and segment tokens; preserve distinct Score/Score2 source IDs; expose official mapper Score->Score2 corrections only in auxiliary column because they cause13 collisions',
            '19 ratings are row[3:-2]; empty/0 missing; any nonmissing nonnumeric/nonfinite/outside[1,7] value excludes the entire row',
            'exact duplicate key=(rater_id,canonical_segment,normalized19-vector); dataID/message do not affect duplicate status',
            'distinct ratings from the same rater/segment are averaged separately for each attribute, giving each rater one contribution',
            'per-segment mean and ddof1 sample variance are computed across those independent rater contributions on(s-1)/6 scale',
            'published_record_aggregation is a comparison over all valid source records before duplicate removal, using valid-cell ddof1 variance; it is not a claim to reproduce the official std JSON'],
        minimum_two_raters_rule='means remain in rating/basis tables if n=1; sample variance and single/composite target eligibility require n>=2; all four must qualify for composite targets; missing targets saved as empty CSV cells',
        missing_or_low_count={str(j):sum(r[f'n{j}']<2 for r in target_rows) for j in SELECTED},
        eligible_single19=sum(r['eligible_single19'] for r in target_rows),
        eligible_four=sum(r['eligible_four'] for r in target_rows),
        official_json_caveat='Official mean mapper removes0 then divides by7, whereas its std code includes0 and uses population ddof0. New calculations recompute valid-rater statistics directly from raw CSV.',
        paper_count='Paper reports12652 annotations; this release has14934 raw rows. Counts are reported from the actual source and are not forced to match the paper.',
        identity_scope='performer_token and work-local code groups are released filename identifiers, not a verified cross-work human identity map; exclude Score/Score2 from human-only analyses',
        scientific_scope='New continuous targets only; no classifier fits, no prediction results, and no reconstruction of historical0.812 or its original four-attribute target',
        official_script_alias_count=len(official_alias_sources),score_alias_collisions=collisions,
        score_alias_resolution='Primary source-ID table preserves1202distinct source segments including distinct Score/Score2 controls; the official mapper would collapse13pairs to1189 IDs, whereas the released mean JSON retains1202. Human-only cohort is unaffected.',
        input_unchanged_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    midi_dir=source.parents[1]/'virtuoso/data/all_2rounds'
    if midi_dir.is_dir():
        midi_by_id=defaultdict(list)
        for p in midi_dir.glob('*.mid'):
            try:midi_by_id[canonical_segment(p.name)].append(p.name)
            except ValueError:pass
        audit['midi_identity_coverage']=dict(n_midi_files=sum(map(len,midi_by_id.values())),
            n_midi_normalized_ids=len(midi_by_id),n_rating_ids_matched=len(segments & set(midi_by_id)),
            rating_ids_without_midi=sorted(segments-set(midi_by_id)),
            duplicated_midi_ids={k:v for k,v in midi_by_id.items() if len(v)>1})
    if audit['source_sha256']!=audit['input_unchanged_sha256']:raise RuntimeError('Source changed during read-only aggregation')
    (out/'ratings_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:audit[k] for k in ('raw_rows','canonical_segments','row_dispositions','independent_rater_segment_contributions','human_segments','score_control_segments','eligible_single19','eligible_four')},indent=2))


if __name__=='__main__':main()
