# Actual results: bounded six-task stress protocol

The paired experiment completed 432 stress model fits (216 BFWK-N and 216 RBF) and 144 training-size learning-curve fits. All results are descriptive three-fold means with n capped at 360; they do not establish a universal advantage or threshold.

| Dataset | Clean BFWK-N BA | Clean RBF BA | Clean gain (pp) | Severe BFWK-N BA | Severe RBF BA | Severe gain (pp) |
|---|---:|---:|---:|---:|---:|---:|
| WDBC | 96.42 | 97.08 | -0.66 | 94.76 | 96.18 | -1.42 |
| Wine-01 | 99.31 | 100.00 | -0.69 | 99.31 | 98.43 | +0.88 |
| Iris-12 | 93.01 | 93.01 | +0.00 | 94.00 | 96.02 | -2.02 |
| Digits-35 | 99.44 | 99.44 | +0.00 | 98.89 | 99.17 | -0.28 |
| Spector | 65.87 | 74.21 | -8.33 | 54.76 | 67.66 | -12.90 |
| ANES96 | 82.08 | 78.54 | +3.54 | 82.67 | 80.43 | +2.24 |

Severe = appended noisy-copy count/base d=2 and independent-noise count/base d=1. See the full profiles for all twelve crossed cells; those conditions must not be selected post hoc to imply a general win.

BFWK-N outer termination counts in the 216 stress fits: {"line_search_failed": 10, "outer_iteration_cap": 8, "relative_objective_tolerance": 198}.
Final projected-gradient residual median=0.00471922, maximum=1.22683. Nonzero inner SVC fit-status count among all stress models=0.
An outer iteration cap and a relative-objective stopping test do not certify stationarity. Final projected-gradient residuals and all fold termination/status columns are saved.

The original 13-task property correlations are exploratory and remain nonsignificant after the four-test Holm adjustment (minimum adjusted p=0.4392). The original Friedman p=0.402 remains the appropriate limitation on benchmark-wide superiority.
