
###############################################################
# BFWK-SVM: self-contained reproducibility demo (base R only)
#
# Model:
# Bilevel Feature-Weighted Kernel SVM for Artistic-Nuance
# Assessment of Musical Performance
#
# No external R package and no external dataset are required.
###############################################################

rm(list = ls())
set.seed(2026)

############################
# 0. Configuration
############################

FAST_DEMO <- TRUE
OUTPUT_DIR <- "BFWK_SVM_output"

if (!dir.exists(OUTPUT_DIR)) {
  dir.create(OUTPUT_DIR, recursive = TRUE)
}

if (FAST_DEMO) {
  CFG <- list(
    seed = 2026,
    n_performers = 8,
    n_pieces = 6,
    n_raters = 5,
    outer_folds = 3,
    inner_folds = 2,
    max_outer_iter = 5,
    max_inner_iter = 300,
    inner_tol = 1e-7,
    bootstrap_B = 3,
    eps_alpha = 1e-5,
    eps_J = 1e-6,
    eta = 1,
    armijo_sigma = 1e-4,
    armijo_zeta = 0.5,
    armijo_min_step = 1e-4,
    confidence_kappa = 4,
    hyper_grid = expand.grid(
      C = c(2, 8),
      gamma = 0.10,
      lambda = 0.08,
      rho = 0.18,
      tau = 0.35
    )
  )
} else {
  CFG <- list(
    seed = 2026,
    n_performers = 16,
    n_pieces = 10,
    n_raters = 8,
    outer_folds = 5,
    inner_folds = 3,
    max_outer_iter = 25,
    max_inner_iter = 1500,
    inner_tol = 1e-8,
    bootstrap_B = 30,
    eps_alpha = 1e-5,
    eps_J = 1e-7,
    eta = 1,
    armijo_sigma = 1e-4,
    armijo_zeta = 0.5,
    armijo_min_step = 1e-6,
    confidence_kappa = 4,
    hyper_grid = expand.grid(
      C = c(1, 4, 16),
      gamma = c(0.04, 0.10, 0.25),
      lambda = c(0.04, 0.10),
      rho = c(0.10, 0.30),
      tau = c(0.20, 0.50)
    )
  )
}

############################
# 1. Basic utilities
############################

clamp <- function(x, lower, upper) {
  pmin(pmax(x, lower), upper)
}

sigmoid <- function(x) {
  1 / (1 + exp(-x))
}

norm2 <- function(x) {
  sqrt(sum(x * x))
}

safe_sd <- function(x, eps = 1e-12) {
  s <- stats::sd(x)
  if (!is.finite(s) || s < eps) 1 else s
}

project_simplex <- function(v) {
  u <- sort(v, decreasing = TRUE)
  cssv <- cumsum(u) - 1
  idx <- which(u - cssv / seq_along(u) > 0)

  if (length(idx) == 0) {
    return(rep(1 / length(v), length(v)))
  }

  rho <- max(idx)
  theta <- cssv[rho] / rho
  w <- pmax(v - theta, 0)

  if (sum(w) <= 0) {
    rep(1 / length(v), length(v))
  } else {
    w / sum(w)
  }
}

make_group_folds <- function(groups, y, k, seed, max_attempts = 200) {
  groups <- as.character(groups)
  y <- as.integer(y)
  unique_groups <- unique(groups)

  if (length(unique_groups) < k) {
    stop("The number of unique groups is smaller than the number of folds.")
  }

  group_mean <- tapply(y, groups, mean)
  strata <- ifelse(group_mean >= 0, 1L, -1L)

  for (attempt in seq_len(max_attempts)) {
    set.seed(seed + attempt - 1)
    group_fold <- integer(length(unique_groups))
    names(group_fold) <- unique_groups

    for (stratum in unique(strata)) {
      stratum_groups <- names(strata)[strata == stratum]
      stratum_groups <- sample(stratum_groups)
      assignment <- rep(seq_len(k), length.out = length(stratum_groups))
      group_fold[stratum_groups] <- assignment
    }

    fold <- as.integer(group_fold[groups])

    valid <- TRUE
    for (f in seq_len(k)) {
      train_y <- y[fold != f]
      valid_y <- y[fold == f]
      if (length(unique(train_y)) < 2 || length(unique(valid_y)) < 2) {
        valid <- FALSE
        break
      }
    }

    if (valid) return(fold)
  }

  stop(
    "Unable to construct grouped folds containing both classes. ",
    "Increase the number of performers/pieces or reduce the number of folds."
  )
}

auc_rank <- function(y, score) {
  pos <- y == 1
  neg <- y == -1
  n_pos <- sum(pos)
  n_neg <- sum(neg)

  if (n_pos == 0 || n_neg == 0) {
    return(NA_real_)
  }

  r <- rank(score, ties.method = "average")
  (sum(r[pos]) - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)
}

classification_metrics <- function(y, decision, probability = NULL) {
  prediction <- ifelse(decision >= 0, 1L, -1L)

  TP <- sum(y == 1 & prediction == 1)
  FN <- sum(y == 1 & prediction == -1)
  TN <- sum(y == -1 & prediction == -1)
  FP <- sum(y == -1 & prediction == 1)

  sensitivity <- if (TP + FN > 0) TP / (TP + FN) else NA_real_
  specificity <- if (TN + FP > 0) TN / (TN + FP) else NA_real_
  balanced_accuracy <- mean(c(sensitivity, specificity), na.rm = TRUE)

  precision_pos <- if (TP + FP > 0) TP / (TP + FP) else 0
  recall_pos <- if (TP + FN > 0) TP / (TP + FN) else 0
  f1_pos <- if (precision_pos + recall_pos > 0) {
    2 * precision_pos * recall_pos / (precision_pos + recall_pos)
  } else 0

  precision_neg <- if (TN + FN > 0) TN / (TN + FN) else 0
  recall_neg <- if (TN + FP > 0) TN / (TN + FP) else 0
  f1_neg <- if (precision_neg + recall_neg > 0) {
    2 * precision_neg * recall_neg / (precision_neg + recall_neg)
  } else 0

  macro_f1 <- mean(c(f1_pos, f1_neg))

  mcc_den <- sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))
  mcc <- if (mcc_den > 0) {
    (TP * TN - FP * FN) / mcc_den
  } else 0

  if (is.null(probability)) {
    probability <- sigmoid(decision)
  }

  c(
    BalancedAccuracy = balanced_accuracy,
    MacroF1 = macro_f1,
    AUROC = auc_rank(y, decision),
    MCC = mcc,
    Brier = mean((as.integer(y == 1) - probability)^2)
  )
}

cosine_similarity <- function(a, b) {
  denominator <- norm2(a) * norm2(b)
  if (denominator <= 0) return(NA_real_)
  sum(a * b) / denominator
}

weight_stability <- function(W) {
  W <- as.matrix(W)
  if (nrow(W) < 2) return(1)

  values <- numeric(0)
  for (i in seq_len(nrow(W) - 1)) {
    for (j in (i + 1):nrow(W)) {
      values <- c(values, cosine_similarity(W[i, ], W[j, ]))
    }
  }
  mean(values, na.rm = TRUE)
}

############################
# 2. Simulated data
############################

simulate_music_data <- function(cfg) {
  set.seed(cfg$seed)

  design <- expand.grid(
    performer_id = paste0("P", seq_len(cfg$n_performers)),
    piece_id = paste0("W", seq_len(cfg$n_pieces)),
    KEEP.OUT.ATTRS = FALSE,
    stringsAsFactors = FALSE
  )

  n <- nrow(design)

  performer_effect <- setNames(
    rnorm(cfg$n_performers, 0, 0.45),
    paste0("P", seq_len(cfg$n_performers))
  )
  piece_effect <- setNames(
    rnorm(cfg$n_pieces, 0, 0.35),
    paste0("W", seq_len(cfg$n_pieces))
  )

  base_quality <- (
    performer_effect[design$performer_id] +
    0.55 * piece_effect[design$piece_id] +
    rnorm(n, 0, 0.65)
  )

  timing <- 0.85 * base_quality + rnorm(n, 0, 0.45)
  phrasing <- 0.75 * base_quality + 0.20 * timing + rnorm(n, 0, 0.50)
  dynamics <- 0.63 * base_quality + 0.18 * phrasing + rnorm(n, 0, 0.55)
  articulation <- 0.55 * base_quality + 0.15 * timing + rnorm(n, 0, 0.60)
  timbre <- 0.38 * base_quality + rnorm(n, 0, 0.75)

  X <- data.frame(
    Timing_onset = timing + rnorm(n, 0, 0.30),
    Timing_tempo = 0.85 * timing + rnorm(n, 0, 0.35),
    Timing_slowing = 0.65 * timing + 0.25 * phrasing + rnorm(n, 0, 0.38),

    Dynamics_loudness = dynamics + rnorm(n, 0, 0.32),
    Dynamics_range = 0.82 * dynamics + rnorm(n, 0, 0.38),
    Dynamics_accent = 0.65 * dynamics + 0.20 * articulation + rnorm(n, 0, 0.40),

    Articulation_duration = articulation + rnorm(n, 0, 0.35),
    Articulation_overlap = 0.80 * articulation + rnorm(n, 0, 0.40),
    Articulation_gap = -0.65 * articulation + rnorm(n, 0, 0.45),

    Timbre_centroid = timbre + rnorm(n, 0, 0.50),
    Timbre_flux = 0.70 * timbre + rnorm(n, 0, 0.55),
    Timbre_harmonicity = -0.60 * timbre + rnorm(n, 0, 0.58),

    Phrasing_shape = phrasing + rnorm(n, 0, 0.30),
    Phrasing_contour = 0.88 * phrasing + rnorm(n, 0, 0.35),
    Phrasing_emphasis = 0.68 * phrasing + 0.20 * dynamics + rnorm(n, 0, 0.38)
  )

  feature_names <- names(X)
  groups <- c(
    rep("Timing", 3),
    rep("Dynamics", 3),
    rep("Articulation", 3),
    rep("Timbre", 3),
    rep("Phrasing", 3)
  )
  names(groups) <- feature_names

  latent_artistry <- (
    0.30 * timing +
    0.24 * phrasing +
    0.20 * dynamics +
    0.16 * articulation +
    0.10 * timbre
  )

  criterion_names <- c(
    "PhraseShaping",
    "MusicMaking",
    "Expression",
    "Interpretation"
  )

  criterion_mean <- matrix(NA_real_, n, length(criterion_names))
  criterion_var <- matrix(NA_real_, n, length(criterion_names))
  colnames(criterion_mean) <- criterion_names
  colnames(criterion_var) <- criterion_names

  rater_bias <- rnorm(cfg$n_raters, 0, 0.16)
  ratings_list <- vector("list", length(criterion_names))

  for (ell in seq_along(criterion_names)) {
    rating_matrix <- matrix(
      NA_real_,
      nrow = n,
      ncol = cfg$n_raters
    )

    for (j in seq_len(cfg$n_raters)) {
      raw_rating <- 1 + 6 * sigmoid(
        latent_artistry +
        c(0.10, 0.02, -0.03, 0.06)[ell] +
        rater_bias[j] +
        rnorm(n, 0, c(0.40, 0.44, 0.48, 0.45)[ell])
      )
      rating_matrix[, j] <- clamp(round(raw_rating), 1, 7)
    }

    normalized <- (rating_matrix - 1) / 6
    criterion_mean[, ell] <- rowMeans(normalized)
    criterion_var[, ell] <- apply(normalized, 1, stats::var)

    ratings_list[[ell]] <- data.frame(
      sample_id = rep(seq_len(n), each = cfg$n_raters),
      criterion = criterion_names[ell],
      rater_id = rep(paste0("R", seq_len(cfg$n_raters)), times = n),
      rating = as.vector(t(rating_matrix))
    )
  }

  reliability <- 1 / (criterion_var + 0.02)
  artistic_score <- rowSums(reliability * criterion_mean) / rowSums(reliability)
  annotation_uncertainty <- rowMeans(criterion_var)
  label <- ifelse(
    artistic_score >= stats::median(artistic_score),
    1L,
    -1L
  )

  data <- cbind(
    data.frame(
      sample_id = seq_len(n),
      performer_id = design$performer_id,
      piece_id = design$piece_id,
      artistic_score = artistic_score,
      annotation_uncertainty = annotation_uncertainty,
      label = label
    ),
    X
  )

  list(
    data = data,
    ratings = do.call(rbind, ratings_list),
    feature_names = feature_names,
    feature_groups = groups
  )
}

############################
# 3. Standardization, q, M
############################

fit_standardizer <- function(X) {
  list(
    center = colMeans(X),
    scale = apply(X, 2, safe_sd)
  )
}

apply_standardizer <- function(X, scaler) {
  sweep(
    sweep(as.matrix(X), 2, scaler$center, FUN = "-"),
    2,
    scaler$scale,
    FUN = "/"
  )
}

compute_q_M <- function(X, y, eps = 1e-10) {
  Xc <- scale(X, center = TRUE, scale = FALSE)
  yc <- y - mean(y)

  x_energy <- colSums(Xc * Xc)
  y_energy <- sum(yc * yc)

  q <- as.numeric(crossprod(Xc, yc))^2 /
    (x_energy * y_energy + eps)
  q <- pmax(q, 0)

  if (sum(q) <= eps) {
    q <- rep(1 / ncol(X), ncol(X))
  } else {
    q <- q / sum(q)
  }

  Xn <- sweep(Xc, 2, sqrt(x_energy + eps), FUN = "/")
  M <- crossprod(Xn)
  M <- M * M
  M <- (M + t(M)) / 2

  # Squared-correlation matrix is PSD up to numerical error.
  eig_min <- min(eigen(M, symmetric = TRUE, only.values = TRUE)$values)
  if (eig_min < 0) {
    M <- M + (abs(eig_min) + 1e-10) * diag(ncol(M))
  }

  list(q = q, M = M)
}

############################
# 4. Weighted Gaussian kernel
############################

weighted_kernel <- function(X1, X2, alpha, gamma) {
  scale_weight <- sqrt(pmax(alpha, 0))
  A <- sweep(as.matrix(X1), 2, scale_weight, FUN = "*")
  B <- sweep(as.matrix(X2), 2, scale_weight, FUN = "*")

  D2 <- outer(rowSums(A * A), rowSums(B * B), FUN = "+") -
    2 * tcrossprod(A, B)
  D2 <- pmax(D2, 0)

  exp(-gamma * D2)
}

make_C_vector <- function(y, C, uncertainty = NULL, kappa = 4) {
  n <- length(y)
  n_pos <- sum(y == 1)
  n_neg <- sum(y == -1)

  if (n_pos == 0 || n_neg == 0) {
    stop("A training partition contains only one class.")
  }

  class_weight <- ifelse(
    y == 1,
    n / (2 * n_pos),
    n / (2 * n_neg)
  )

  if (is.null(uncertainty)) {
    confidence <- rep(1, n)
  } else {
    confidence <- 1 / (1 + kappa * uncertainty)
    confidence <- confidence / mean(confidence)
  }

  C * class_weight * confidence
}

############################
# 5. Base-R SVM dual solver
############################

project_svm_dual <- function(v, y, C_vec, tol = 1e-10) {
  h <- function(lambda) {
    beta <- pmin(pmax(v - lambda * y, 0), C_vec)
    sum(y * beta)
  }

  lower <- -1
  upper <- 1

  while (h(lower) < 0) {
    lower <- lower * 2
    if (!is.finite(lower)) stop("Dual projection failed.")
  }

  while (h(upper) > 0) {
    upper <- upper * 2
    if (!is.finite(upper)) stop("Dual projection failed.")
  }

  for (iter in seq_len(100)) {
    middle <- 0.5 * (lower + upper)
    value <- h(middle)

    if (abs(value) <= tol) {
      lower <- middle
      upper <- middle
      break
    }

    if (value > 0) {
      lower <- middle
    } else {
      upper <- middle
    }
  }

  lambda <- 0.5 * (lower + upper)
  pmin(pmax(v - lambda * y, 0), C_vec)
}

solve_svm_dual <- function(
    K,
    y,
    C_vec,
    max_iter = 1000,
    tol = 1e-8,
    beta_start = NULL) {

  n <- length(y)
  Q <- (y %o% y) * K
  Q <- (Q + t(Q)) / 2
  Q <- Q + 1e-10 * diag(n)

  largest_eigenvalue <- max(
    eigen(Q, symmetric = TRUE, only.values = TRUE)$values
  )
  L <- max(largest_eigenvalue, 1e-8)

  if (is.null(beta_start) || length(beta_start) != n) {
    beta <- rep(0, n)
  } else {
    beta <- project_svm_dual(beta_start, y, C_vec)
  }

  z <- beta
  momentum <- 1

  for (iter in seq_len(max_iter)) {
    gradient <- as.vector(Q %*% z) - 1
    beta_new <- project_svm_dual(
      z - gradient / L,
      y,
      C_vec
    )

    if (norm2(beta_new - beta) <= tol * (1 + norm2(beta))) {
      beta <- beta_new
      break
    }

    momentum_new <- (1 + sqrt(1 + 4 * momentum^2)) / 2
    z <- beta_new +
      ((momentum - 1) / momentum_new) * (beta_new - beta)

    # Keep the extrapolated point feasible enough for numerical stability.
    z <- project_svm_dual(z, y, C_vec)

    beta <- beta_new
    momentum <- momentum_new
  }

  objective <- sum(beta) -
    0.5 * as.numeric(t(beta) %*% Q %*% beta)

  list(
    beta = beta,
    value = objective,
    iterations = iter,
    Q = Q
  )
}

compute_bias <- function(K, y, beta, C_vec, tol = 1e-5) {
  no_bias <- as.vector(K %*% (beta * y))
  free <- which(beta > tol & beta < C_vec - tol)

  if (length(free) > 0) {
    mean(y[free] - no_bias[free])
  } else {
    support <- which(beta > tol)
    if (length(support) == 0) {
      0
    } else {
      stats::median(y[support] - no_bias[support])
    }
  }
}

############################
# 6. Bilevel objective
############################

regularizer <- function(alpha, q, M, lambda, rho, tau) {
  0.5 * lambda * sum(alpha^2) +
    0.5 * rho * as.numeric(t(alpha) %*% M %*% alpha) -
    tau * sum(q * alpha)
}

regularizer_gradient <- function(alpha, q, M, lambda, rho, tau) {
  lambda * alpha + rho * as.vector(M %*% alpha) - tau * q
}

evaluate_objective <- function(
    alpha,
    X,
    y,
    C_vec,
    gamma,
    lambda,
    rho,
    tau,
    q,
    M,
    cfg,
    beta_start = NULL) {

  K <- weighted_kernel(X, X, alpha, gamma)
  inner <- solve_svm_dual(
    K,
    y,
    C_vec,
    max_iter = cfg$max_inner_iter,
    tol = cfg$inner_tol,
    beta_start = beta_start
  )

  list(
    objective = inner$value +
      regularizer(alpha, q, M, lambda, rho, tau),
    svm_value = inner$value,
    beta = inner$beta,
    K = K
  )
}

outer_gradient <- function(
    alpha,
    X,
    y,
    beta,
    K,
    gamma,
    lambda,
    rho,
    tau,
    q,
    M) {

  u <- beta * y
  coefficient <- (u %o% u) * K
  d <- ncol(X)
  kernel_gradient <- numeric(d)

  for (r in seq_len(d)) {
    delta <- outer(X[, r], X[, r], FUN = "-")^2
    kernel_gradient[r] <- 0.5 * gamma * sum(coefficient * delta)
  }

  kernel_gradient +
    regularizer_gradient(alpha, q, M, lambda, rho, tau)
}

############################
# 7. Fit and predict BFWK-SVM
############################

fit_bfwk_svm <- function(
    X_raw,
    y,
    uncertainty = NULL,
    feature_groups = NULL,
    C = 8,
    gamma = 0.10,
    lambda = 0.08,
    rho = 0.18,
    tau = 0.35,
    cfg = CFG,
    verbose = FALSE) {

  X_raw <- as.matrix(X_raw)
  y <- as.integer(y)

  if (!all(y %in% c(-1L, 1L))) {
    stop("Labels must be coded as -1 and 1.")
  }

  scaler <- fit_standardizer(X_raw)
  X <- apply_standardizer(X_raw, scaler)

  qM <- compute_q_M(X, y)
  q <- qM$q
  M <- qM$M

  C_vec <- make_C_vector(
    y,
    C,
    uncertainty,
    cfg$confidence_kappa
  )

  d <- ncol(X)
  alpha <- rep(1 / d, d)
  previous_objective <- NA_real_
  beta_warm <- NULL

  log_table <- data.frame(
    iteration = integer(0),
    objective = numeric(0),
    normalized_objective = numeric(0),
    projected_step_norm = numeric(0),
    stationarity_residual = numeric(0),
    armijo_step = numeric(0),
    relative_change = numeric(0)
  )

  first_objective <- NA_real_

  for (t in 0:(cfg$max_outer_iter - 1)) {
    current <- evaluate_objective(
      alpha, X, y, C_vec,
      gamma, lambda, rho, tau,
      q, M, cfg,
      beta_start = beta_warm
    )

    if (!is.finite(first_objective)) {
      first_objective <- current$objective
    }

    gradient <- outer_gradient(
      alpha, X, y,
      current$beta, current$K,
      gamma, lambda, rho, tau,
      q, M
    )

    projected <- project_simplex(
      alpha - cfg$eta * gradient
    )
    direction <- projected - alpha
    direction_norm <- norm2(direction)
    stationarity <- norm2(
      alpha - project_simplex(alpha - gradient)
    )

    if (direction_norm <= cfg$eps_alpha) {
      log_table <- rbind(
        log_table,
        data.frame(
          iteration = t,
          objective = current$objective,
          normalized_objective = current$objective / first_objective,
          projected_step_norm = direction_norm,
          stationarity_residual = stationarity,
          armijo_step = 0,
          relative_change = 0
        )
      )
      if (verbose) message("Stopped: projected-step tolerance.")
      beta_warm <- current$beta
      break
    }

    directional_derivative <- sum(gradient * direction)
    step <- 1
    accepted <- FALSE
    trial <- NULL

    while (step >= cfg$armijo_min_step) {
      alpha_trial <- alpha + step * direction

      trial <- evaluate_objective(
        alpha_trial, X, y, C_vec,
        gamma, lambda, rho, tau,
        q, M, cfg,
        beta_start = current$beta
      )

      if (
        trial$objective <=
          current$objective +
          cfg$armijo_sigma * step * directional_derivative +
          1e-8
      ) {
        accepted <- TRUE
        break
      }

      step <- step * cfg$armijo_zeta
    }

    if (!accepted) {
      # Keep the current iterate when no sufficient-decrease step is found.
      step <- 0
      alpha_trial <- alpha
      trial <- current
    }

    relative_change <- abs(trial$objective - current$objective) /
      (1 + abs(current$objective))

    log_table <- rbind(
      log_table,
      data.frame(
        iteration = t,
        objective = current$objective,
        normalized_objective = current$objective / first_objective,
        projected_step_norm = direction_norm,
        stationarity_residual = stationarity,
        armijo_step = step,
        relative_change = relative_change
      )
    )

    if (verbose) {
      message(sprintf(
        "iter=%02d J=%.6f residual=%.3e step=%.4f",
        t,
        current$objective,
        stationarity,
        step
      ))
    }

    alpha <- alpha_trial
    beta_warm <- trial$beta

    objective_stop <- is.finite(previous_objective) &&
      abs(current$objective - previous_objective) /
        (1 + abs(previous_objective)) <= cfg$eps_J

    if (relative_change <= cfg$eps_J || objective_stop || step == 0) {
      if (verbose) message("Stopped: objective/line-search criterion.")
      break
    }

    previous_objective <- current$objective
  }

  final <- evaluate_objective(
    alpha, X, y, C_vec,
    gamma, lambda, rho, tau,
    q, M, cfg,
    beta_start = beta_warm
  )

  bias <- compute_bias(
    final$K,
    y,
    final$beta,
    C_vec
  )

  list(
    alpha = alpha,
    beta = final$beta,
    bias = bias,
    X_train = X,
    y_train = y,
    scaler = scaler,
    q = q,
    M = M,
    C_vec = C_vec,
    gamma = gamma,
    feature_names = colnames(X_raw),
    feature_groups = feature_groups,
    convergence = log_table,
    objective = final$objective
  )
}

predict_bfwk <- function(model, X_new_raw) {
  X_new <- apply_standardizer(
    as.matrix(X_new_raw),
    model$scaler
  )

  K_new <- weighted_kernel(
    model$X_train,
    X_new,
    model$alpha,
    model$gamma
  )

  decision <- as.vector(
    t(K_new) %*% (model$beta * model$y_train) +
      model$bias
  )

  list(
    decision = decision,
    probability = sigmoid(decision),
    class = ifelse(decision >= 0, 1L, -1L)
  )
}

############################
# 8. Fixed-weight baselines
############################

fit_fixed_svm <- function(
    X_raw,
    y,
    alpha,
    uncertainty,
    C,
    gamma,
    cfg) {

  X_raw <- as.matrix(X_raw)
  scaler <- fit_standardizer(X_raw)
  X <- apply_standardizer(X_raw, scaler)

  alpha <- project_simplex(alpha)
  C_vec <- make_C_vector(
    y,
    C,
    uncertainty,
    cfg$confidence_kappa
  )

  K <- weighted_kernel(X, X, alpha, gamma)
  inner <- solve_svm_dual(
    K,
    y,
    C_vec,
    max_iter = cfg$max_inner_iter,
    tol = cfg$inner_tol
  )

  list(
    X_train = X,
    y_train = y,
    alpha = alpha,
    gamma = gamma,
    beta = inner$beta,
    bias = compute_bias(K, y, inner$beta, C_vec),
    scaler = scaler
  )
}

predict_fixed_svm <- function(model, X_new_raw) {
  X_new <- apply_standardizer(
    as.matrix(X_new_raw),
    model$scaler
  )

  K_new <- weighted_kernel(
    model$X_train,
    X_new,
    model$alpha,
    model$gamma
  )

  decision <- as.vector(
    t(K_new) %*% (model$beta * model$y_train) +
      model$bias
  )

  list(
    decision = decision,
    probability = sigmoid(decision),
    class = ifelse(decision >= 0, 1L, -1L)
  )
}

two_stage_alpha <- function(q, M, lambda, rho, tau) {
  alpha <- rep(1 / length(q), length(q))

  for (iter in seq_len(300)) {
    gradient <- regularizer_gradient(
      alpha, q, M, lambda, rho, tau
    )
    next_alpha <- project_simplex(alpha - 0.5 * gradient)

    if (norm2(next_alpha - alpha) <= 1e-9) {
      alpha <- next_alpha
      break
    }

    alpha <- next_alpha
  }

  alpha
}

mrmr_alpha <- function(X, y, keep_fraction = 0.5) {
  qM <- compute_q_M(X, y)
  score <- qM$q - 0.25 * rowMeans(qM$M)
  keep <- max(1, ceiling(ncol(X) * keep_fraction))
  selected <- order(score, decreasing = TRUE)[seq_len(keep)]

  alpha <- rep(0, ncol(X))
  alpha[selected] <- 1 / keep
  alpha
}

############################
# 9. Hyperparameter tuning
############################

tune_bfwk <- function(
    train_data,
    feature_names,
    feature_groups,
    group_column,
    cfg,
    seed) {

  fold <- make_group_folds(
    train_data[[group_column]],
    train_data$label,
    cfg$inner_folds,
    seed
  )

  grid <- cfg$hyper_grid
  score <- rep(NA_real_, nrow(grid))

  for (g in seq_len(nrow(grid))) {
    fold_score <- numeric(0)

    for (f in seq_len(cfg$inner_folds)) {
      tr <- which(fold != f)
      va <- which(fold == f)

      model <- fit_bfwk_svm(
        train_data[tr, feature_names, drop = FALSE],
        train_data$label[tr],
        train_data$annotation_uncertainty[tr],
        feature_groups,
        C = grid$C[g],
        gamma = grid$gamma[g],
        lambda = grid$lambda[g],
        rho = grid$rho[g],
        tau = grid$tau[g],
        cfg = cfg
      )

      prediction <- predict_bfwk(
        model,
        train_data[va, feature_names, drop = FALSE]
      )

      fold_score <- c(
        fold_score,
        classification_metrics(
          train_data$label[va],
          prediction$decision,
          prediction$probability
        )["BalancedAccuracy"]
      )
    }

    score[g] <- mean(fold_score, na.rm = TRUE)
  }

  best <- which.max(score)

  list(
    C = grid$C[best],
    gamma = grid$gamma[best],
    lambda = grid$lambda[best],
    rho = grid$rho[best],
    tau = grid$tau[best],
    inner_score = score[best]
  )
}

############################
# 10. Grouped evaluation
############################

evaluate_protocol <- function(
    data,
    feature_names,
    feature_groups,
    group_column,
    protocol_name,
    cfg) {

  outer_fold <- make_group_folds(
    data[[group_column]],
    data$label,
    cfg$outer_folds,
    cfg$seed + nchar(protocol_name)
  )

  metric_rows <- list()
  prediction_rows <- list()
  weight_rows <- list()
  convergence_rows <- list()

  for (f in seq_len(cfg$outer_folds)) {
    message(protocol_name, ": fold ", f, "/", cfg$outer_folds)

    tr <- which(outer_fold != f)
    te <- which(outer_fold == f)

    train_data <- data[tr, , drop = FALSE]
    test_data <- data[te, , drop = FALSE]

    best <- tune_bfwk(
      train_data,
      feature_names,
      feature_groups,
      group_column,
      cfg,
      seed = cfg$seed + 100 * f
    )

    full_model <- fit_bfwk_svm(
      train_data[, feature_names, drop = FALSE],
      train_data$label,
      train_data$annotation_uncertainty,
      feature_groups,
      C = best$C,
      gamma = best$gamma,
      lambda = best$lambda,
      rho = best$rho,
      tau = best$tau,
      cfg = cfg
    )

    full_prediction <- predict_bfwk(
      full_model,
      test_data[, feature_names, drop = FALSE]
    )

    scaler <- fit_standardizer(
      as.matrix(train_data[, feature_names, drop = FALSE])
    )
    X_train_standardized <- apply_standardizer(
      train_data[, feature_names, drop = FALSE],
      scaler
    )
    qM <- compute_q_M(
      X_train_standardized,
      train_data$label
    )

    baseline_alpha <- list(
      "Uniform RBF-SVM" =
        rep(1 / length(feature_names), length(feature_names)),
      "Two-stage weighted SVM" =
        two_stage_alpha(
          qM$q,
          qM$M,
          best$lambda,
          best$rho,
          best$tau
        ),
      "mRMR-SVM" =
        mrmr_alpha(
          X_train_standardized,
          train_data$label
        )
    )

    method_predictions <- list(
      "BFWK-SVM" = full_prediction
    )

    for (method_name in names(baseline_alpha)) {
      baseline_model <- fit_fixed_svm(
        train_data[, feature_names, drop = FALSE],
        train_data$label,
        baseline_alpha[[method_name]],
        train_data$annotation_uncertainty,
        best$C,
        best$gamma,
        cfg
      )

      method_predictions[[method_name]] <- predict_fixed_svm(
        baseline_model,
        test_data[, feature_names, drop = FALSE]
      )
    }

    for (method_name in names(method_predictions)) {
      pr <- method_predictions[[method_name]]
      met <- classification_metrics(
        test_data$label,
        pr$decision,
        pr$probability
      )

      metric_rows[[length(metric_rows) + 1]] <- data.frame(
        protocol = protocol_name,
        fold = f,
        method = method_name,
        BalancedAccuracy = unname(met["BalancedAccuracy"]),
        MacroF1 = unname(met["MacroF1"]),
        AUROC = unname(met["AUROC"]),
        MCC = unname(met["MCC"]),
        Brier = unname(met["Brier"])
      )

      prediction_rows[[length(prediction_rows) + 1]] <- data.frame(
        protocol = protocol_name,
        fold = f,
        method = method_name,
        sample_id = test_data$sample_id,
        truth = test_data$label,
        decision = pr$decision,
        probability = pr$probability,
        prediction = pr$class
      )
    }

    weight_rows[[length(weight_rows) + 1]] <- data.frame(
      protocol = protocol_name,
      fold = f,
      feature = feature_names,
      group = unname(feature_groups[feature_names]),
      weight = full_model$alpha
    )

    conv <- full_model$convergence
    conv$protocol <- protocol_name
    conv$fold <- f
    convergence_rows[[length(convergence_rows) + 1]] <- conv
  }

  list(
    metrics = do.call(rbind, metric_rows),
    predictions = do.call(rbind, prediction_rows),
    weights = do.call(rbind, weight_rows),
    convergence = do.call(rbind, convergence_rows)
  )
}

############################
# 11. Ablation
############################

run_ablation <- function(
    data,
    feature_names,
    feature_groups,
    cfg) {

  fold <- make_group_folds(
    data$performer_id,
    data$label,
    cfg$outer_folds,
    cfg$seed + 900
  )

  variants <- list(
    "No relevance" = c(lambda = 0.08, rho = 0.18, tau = 0),
    "No redundancy" = c(lambda = 0.08, rho = 0, tau = 0.35),
    "No stabilization" = c(lambda = 0, rho = 0.18, tau = 0.35),
    "Full BFWK-SVM" = c(lambda = 0.08, rho = 0.18, tau = 0.35)
  )

  raw_rows <- list()
  alpha_by_variant <- setNames(
    lapply(names(variants), function(x) list()),
    names(variants)
  )

  for (variant_name in names(variants)) {
    pars <- variants[[variant_name]]

    for (f in seq_len(cfg$outer_folds)) {
      tr <- which(fold != f)
      te <- which(fold == f)

      model <- fit_bfwk_svm(
        data[tr, feature_names, drop = FALSE],
        data$label[tr],
        data$annotation_uncertainty[tr],
        feature_groups,
        C = 8,
        gamma = 0.10,
        lambda = pars["lambda"],
        rho = pars["rho"],
        tau = pars["tau"],
        cfg = cfg
      )

      pr <- predict_bfwk(
        model,
        data[te, feature_names, drop = FALSE]
      )

      met <- classification_metrics(
        data$label[te],
        pr$decision,
        pr$probability
      )

      raw_rows[[length(raw_rows) + 1]] <- data.frame(
        Variant = variant_name,
        Fold = f,
        BalancedAccuracy = unname(met["BalancedAccuracy"]),
        MacroF1 = unname(met["MacroF1"]),
        OuterIterations = nrow(model$convergence)
      )

      alpha_by_variant[[variant_name]][[f]] <- model$alpha
    }
  }

  raw <- do.call(rbind, raw_rows)
  summaries <- list()

  for (variant_name in names(variants)) {
    sub <- raw[raw$Variant == variant_name, , drop = FALSE]
    W <- do.call(rbind, alpha_by_variant[[variant_name]])

    summaries[[length(summaries) + 1]] <- data.frame(
      Variant = variant_name,
      BalancedAccuracyMean = mean(sub$BalancedAccuracy),
      BalancedAccuracySD = stats::sd(sub$BalancedAccuracy),
      MacroF1Mean = mean(sub$MacroF1),
      MacroF1SD = stats::sd(sub$MacroF1),
      WeightStability = weight_stability(W),
      OuterIterationsMean = mean(sub$OuterIterations)
    )
  }

  list(
    raw = raw,
    summary = do.call(rbind, summaries)
  )
}

############################
# 12. Bootstrap weights
############################

bootstrap_group_weights <- function(
    data,
    feature_names,
    feature_groups,
    cfg) {

  set.seed(cfg$seed + 5000)
  performers <- unique(data$performer_id)
  group_names <- unique(unname(feature_groups))

  feature_W <- matrix(
    NA_real_,
    nrow = cfg$bootstrap_B,
    ncol = length(feature_names),
    dimnames = list(NULL, feature_names)
  )

  group_W <- matrix(
    NA_real_,
    nrow = cfg$bootstrap_B,
    ncol = length(group_names),
    dimnames = list(NULL, group_names)
  )

  completed <- 0
  attempts <- 0

  while (completed < cfg$bootstrap_B && attempts < 10 * cfg$bootstrap_B) {
    attempts <- attempts + 1

    sampled <- sample(
      performers,
      length(performers),
      replace = TRUE
    )
    idx <- unlist(
      lapply(sampled, function(p) {
        which(data$performer_id == p)
      }),
      use.names = FALSE
    )
    boot <- data[idx, , drop = FALSE]

    if (length(unique(boot$label)) < 2) next

    model <- fit_bfwk_svm(
      boot[, feature_names, drop = FALSE],
      boot$label,
      boot$annotation_uncertainty,
      feature_groups,
      C = 8,
      gamma = 0.10,
      lambda = 0.08,
      rho = 0.18,
      tau = 0.35,
      cfg = cfg
    )

    completed <- completed + 1
    feature_W[completed, ] <- model$alpha

    for (g in group_names) {
      group_W[completed, g] <- sum(
        model$alpha[feature_groups[feature_names] == g]
      )
    }
  }

  if (completed == 0) {
    stop("No valid bootstrap sample was generated.")
  }

  feature_W <- feature_W[seq_len(completed), , drop = FALSE]
  group_W <- group_W[seq_len(completed), , drop = FALSE]

  summary <- data.frame(
    FeatureGroup = colnames(group_W),
    MeanWeight = colMeans(group_W),
    Lower95 = apply(group_W, 2, stats::quantile, probs = 0.025),
    Upper95 = apply(group_W, 2, stats::quantile, probs = 0.975)
  )
  summary <- summary[
    order(summary$MeanWeight, decreasing = TRUE),
    ,
    drop = FALSE
  ]

  list(
    feature_weights = feature_W,
    group_weights = group_W,
    summary = summary,
    stability = weight_stability(feature_W)
  )
}

############################
# 13. Robustness
############################

run_robustness <- function(
    data,
    feature_names,
    feature_groups,
    cfg) {

  fold <- make_group_folds(
    data$performer_id,
    data$label,
    cfg$outer_folds,
    cfg$seed + 700
  )

  tr <- which(fold != 1)
  te <- which(fold == 1)

  model <- fit_bfwk_svm(
    data[tr, feature_names, drop = FALSE],
    data$label[tr],
    data$annotation_uncertainty[tr],
    feature_groups,
    C = 8,
    gamma = 0.10,
    lambda = 0.08,
    rho = 0.18,
    tau = 0.35,
    cfg = cfg
  )

  X_test <- data[te, feature_names, drop = FALSE]
  y_test <- data$label[te]

  conditions <- list(
    Original = integer(0),
    TimingNoise = grep("^Timing_", feature_names),
    DynamicsNoise = grep("^Dynamics_", feature_names),
    ArticulationNoise = grep("^Articulation_", feature_names)
  )

  set.seed(cfg$seed + 701)
  rows <- list()

  for (condition_name in names(conditions)) {
    Xp <- X_test
    columns <- conditions[[condition_name]]

    if (length(columns) > 0) {
      for (j in columns) {
        Xp[, j] <- Xp[, j] +
          rnorm(
            nrow(Xp),
            0,
            0.20 * safe_sd(Xp[, j])
          )
      }
    }

    pr <- predict_bfwk(model, Xp)
    met <- classification_metrics(
      y_test,
      pr$decision,
      pr$probability
    )

    rows[[length(rows) + 1]] <- data.frame(
      Condition = condition_name,
      BalancedAccuracy = unname(met["BalancedAccuracy"])
    )
  }

  # Rank-based quartiles avoid duplicated quantile breakpoints.
  uncertainty_rank <- rank(
    data$annotation_uncertainty[te],
    ties.method = "first"
  )
  quartile <- cut(
    uncertainty_rank,
    breaks = c(
      0,
      stats::quantile(
        uncertainty_rank,
        c(0.25, 0.50, 0.75),
        names = FALSE
      ),
      Inf
    ),
    include.lowest = TRUE,
    labels = paste0("Q", 1:4)
  )

  original_prediction <- predict_bfwk(model, X_test)
  quartile_rows <- list()

  for (q in levels(quartile)) {
    idx <- which(quartile == q)
    met <- classification_metrics(
      y_test[idx],
      original_prediction$decision[idx],
      original_prediction$probability[idx]
    )

    quartile_rows[[length(quartile_rows) + 1]] <- data.frame(
      UncertaintyQuartile = q,
      N = length(idx),
      BalancedAccuracy = unname(met["BalancedAccuracy"])
    )
  }

  list(
    perturbation = do.call(rbind, rows),
    uncertainty = do.call(rbind, quartile_rows)
  )
}

############################
# 14. Plots
############################

plot_group_weights <- function(summary, file) {
  order_id <- order(summary$MeanWeight)
  s <- summary[order_id, , drop = FALSE]

  grDevices::png(file, width = 1600, height = 950, res = 180)
  graphics::par(mar = c(5, 8, 1.5, 2))

  middle <- graphics::barplot(
    s$MeanWeight,
    names.arg = s$FeatureGroup,
    horiz = TRUE,
    las = 1,
    xlim = c(0, max(s$Upper95) * 1.25),
    xlab = "Mean group weight",
    border = NA
  )

  graphics::arrows(
    s$Lower95,
    middle,
    s$Upper95,
    middle,
    angle = 90,
    code = 3,
    length = 0.04,
    lwd = 2
  )

  graphics::text(
    s$Upper95 + 0.01,
    middle,
    labels = sprintf("%.3f", s$MeanWeight),
    pos = 4,
    font = 2
  )

  grDevices::dev.off()
}

plot_convergence <- function(log_table, output_dir) {
  if (nrow(log_table) == 0) return(invisible(NULL))

  grDevices::png(
    file.path(output_dir, "objective_convergence.png"),
    width = 1500,
    height = 900,
    res = 180
  )
  graphics::plot(
    log_table$iteration,
    log_table$normalized_objective,
    type = "o",
    pch = 16,
    xlab = "Outer iteration",
    ylab = "Normalized objective"
  )
  graphics::grid()
  grDevices::dev.off()

  grDevices::png(
    file.path(output_dir, "stationarity_residual.png"),
    width = 1500,
    height = 900,
    res = 180
  )
  graphics::plot(
    log_table$iteration,
    pmax(log_table$stationarity_residual, 1e-12),
    type = "o",
    pch = 16,
    log = "y",
    xlab = "Outer iteration",
    ylab = "Projected-gradient residual"
  )
  graphics::grid()
  grDevices::dev.off()
}

plot_method_comparison <- function(summary, file) {
  s <- summary[
    summary$Metric == "BalancedAccuracy",
    ,
    drop = FALSE
  ]
  s <- s[order(s$Mean), , drop = FALSE]

  grDevices::png(file, width = 1750, height = 1050, res = 180)
  graphics::par(mar = c(5, 12, 1.5, 2))

  middle <- graphics::barplot(
    s$Mean,
    names.arg = paste(s$Protocol, s$Method, sep = ": "),
    horiz = TRUE,
    las = 1,
    xlim = c(0, 1),
    xlab = "Balanced accuracy",
    border = NA
  )

  graphics::arrows(
    pmax(s$Mean - s$SD, 0),
    middle,
    pmin(s$Mean + s$SD, 1),
    middle,
    angle = 90,
    code = 3,
    length = 0.035
  )

  graphics::text(
    pmin(s$Mean + 0.02, 0.98),
    middle,
    sprintf("%.3f", s$Mean),
    pos = 4,
    font = 2
  )

  grDevices::dev.off()
}

############################
# 15. Main program
############################

cat("\n=== BFWK-SVM reproducibility demo ===\n")
cat("FAST_DEMO:", FAST_DEMO, "\n")

sim <- simulate_music_data(CFG)
music_data <- sim$data
feature_names <- sim$feature_names
feature_groups <- sim$feature_groups

utils::write.csv(
  music_data,
  file.path(OUTPUT_DIR, "simulated_music_data.csv"),
  row.names = FALSE
)
utils::write.csv(
  sim$ratings,
  file.path(OUTPUT_DIR, "simulated_expert_ratings.csv"),
  row.names = FALSE
)

performer_result <- evaluate_protocol(
  music_data,
  feature_names,
  feature_groups,
  "performer_id",
  "Performer-independent",
  CFG
)

piece_result <- evaluate_protocol(
  music_data,
  feature_names,
  feature_groups,
  "piece_id",
  "Piece-independent",
  CFG
)

all_metrics <- rbind(
  performer_result$metrics,
  piece_result$metrics
)
all_predictions <- rbind(
  performer_result$predictions,
  piece_result$predictions
)
all_weights <- rbind(
  performer_result$weights,
  piece_result$weights
)
all_convergence <- rbind(
  performer_result$convergence,
  piece_result$convergence
)

utils::write.csv(
  all_metrics,
  file.path(OUTPUT_DIR, "fold_metrics.csv"),
  row.names = FALSE
)
utils::write.csv(
  all_predictions,
  file.path(OUTPUT_DIR, "out_of_fold_predictions.csv"),
  row.names = FALSE
)
utils::write.csv(
  all_weights,
  file.path(OUTPUT_DIR, "outer_fold_feature_weights.csv"),
  row.names = FALSE
)
utils::write.csv(
  all_convergence,
  file.path(OUTPUT_DIR, "outer_fold_convergence.csv"),
  row.names = FALSE
)

metric_names <- c(
  "BalancedAccuracy",
  "MacroF1",
  "AUROC",
  "MCC",
  "Brier"
)

summary_rows <- list()

for (protocol_name in unique(all_metrics$protocol)) {
  for (method_name in unique(all_metrics$method)) {
    sub <- all_metrics[
      all_metrics$protocol == protocol_name &
        all_metrics$method == method_name,
      ,
      drop = FALSE
    ]

    for (metric_name in metric_names) {
      summary_rows[[length(summary_rows) + 1]] <- data.frame(
        Protocol = protocol_name,
        Method = method_name,
        Metric = metric_name,
        Mean = mean(sub[[metric_name]], na.rm = TRUE),
        SD = stats::sd(sub[[metric_name]], na.rm = TRUE)
      )
    }
  }
}

main_summary <- do.call(rbind, summary_rows)
utils::write.csv(
  main_summary,
  file.path(OUTPUT_DIR, "main_results_summary.csv"),
  row.names = FALSE
)

# Paired fold-wise significance tests against the proposed method.
test_rows <- list()
for (protocol_name in unique(all_metrics$protocol)) {
  proposed <- all_metrics[
    all_metrics$protocol == protocol_name &
      all_metrics$method == "BFWK-SVM",
    ,
    drop = FALSE
  ]

  baseline_names <- setdiff(
    unique(all_metrics$method),
    "BFWK-SVM"
  )

  for (baseline_name in baseline_names) {
    baseline <- all_metrics[
      all_metrics$protocol == protocol_name &
        all_metrics$method == baseline_name,
      ,
      drop = FALSE
    ]

    paired <- merge(
      proposed,
      baseline,
      by = "fold",
      suffixes = c("_BFWK", "_Baseline")
    )

    for (metric_name in c("BalancedAccuracy", "MacroF1")) {
      x <- paired[[paste0(metric_name, "_BFWK")]]
      y <- paired[[paste0(metric_name, "_Baseline")]]

      p_value <- tryCatch(
        stats::wilcox.test(
          x,
          y,
          paired = TRUE,
          exact = FALSE
        )$p.value,
        error = function(e) NA_real_
      )

      test_rows[[length(test_rows) + 1]] <- data.frame(
        Protocol = protocol_name,
        Baseline = baseline_name,
        Metric = metric_name,
        MedianImprovement = stats::median(x - y),
        PValue = p_value
      )
    }
  }
}

significance_tests <- do.call(rbind, test_rows)
significance_tests$HolmP <- stats::p.adjust(
  significance_tests$PValue,
  method = "holm"
)
utils::write.csv(
  significance_tests,
  file.path(OUTPUT_DIR, "paired_significance_tests.csv"),
  row.names = FALSE
)

cat("\nMain results:\n")
print(
  main_summary[
    main_summary$Metric %in% c("BalancedAccuracy", "MacroF1"),
    ,
    drop = FALSE
  ],
  row.names = FALSE
)

cat("\nRunning ablation study...\n")
ablation <- run_ablation(
  music_data,
  feature_names,
  feature_groups,
  CFG
)
utils::write.csv(
  ablation$raw,
  file.path(OUTPUT_DIR, "ablation_fold_results.csv"),
  row.names = FALSE
)
utils::write.csv(
  ablation$summary,
  file.path(OUTPUT_DIR, "ablation_summary.csv"),
  row.names = FALSE
)

cat("\nRunning grouped bootstrap...\n")
bootstrap <- bootstrap_group_weights(
  music_data,
  feature_names,
  feature_groups,
  CFG
)
utils::write.csv(
  bootstrap$summary,
  file.path(OUTPUT_DIR, "group_weight_summary.csv"),
  row.names = FALSE
)
utils::write.csv(
  bootstrap$feature_weights,
  file.path(OUTPUT_DIR, "bootstrap_feature_weights.csv"),
  row.names = FALSE
)
writeLines(
  sprintf(
    "Average cosine stability: %.6f",
    bootstrap$stability
  ),
  file.path(OUTPUT_DIR, "weight_stability.txt")
)

cat("\nRunning robustness analysis...\n")
robustness <- run_robustness(
  music_data,
  feature_names,
  feature_groups,
  CFG
)
utils::write.csv(
  robustness$perturbation,
  file.path(OUTPUT_DIR, "perturbation_robustness.csv"),
  row.names = FALSE
)
utils::write.csv(
  robustness$uncertainty,
  file.path(OUTPUT_DIR, "uncertainty_quartile_results.csv"),
  row.names = FALSE
)

cat("\nFitting final model...\n")
final_model <- fit_bfwk_svm(
  music_data[, feature_names, drop = FALSE],
  music_data$label,
  music_data$annotation_uncertainty,
  feature_groups,
  C = 8,
  gamma = 0.10,
  lambda = 0.08,
  rho = 0.18,
  tau = 0.35,
  cfg = CFG,
  verbose = TRUE
)

final_weights <- data.frame(
  Feature = feature_names,
  Group = unname(feature_groups[feature_names]),
  Weight = final_model$alpha,
  Relevance = final_model$q
)

utils::write.csv(
  final_weights,
  file.path(OUTPUT_DIR, "final_feature_weights.csv"),
  row.names = FALSE
)
utils::write.csv(
  final_model$convergence,
  file.path(OUTPUT_DIR, "final_convergence_log.csv"),
  row.names = FALSE
)

saveRDS(
  final_model,
  file.path(OUTPUT_DIR, "final_bfwk_svm_model.rds")
)

plot_group_weights(
  bootstrap$summary,
  file.path(OUTPUT_DIR, "group_weights.png")
)
plot_convergence(
  final_model$convergence,
  OUTPUT_DIR
)
plot_method_comparison(
  main_summary,
  file.path(OUTPUT_DIR, "balanced_accuracy_comparison.png")
)

cat("\n=== Finished successfully ===\n")
cat("Output folder:", normalizePath(OUTPUT_DIR), "\n")
